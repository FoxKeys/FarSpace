-- ������ ������������ Devart dbForge Studio for MySQL, ������ 5.0.97.1
-- �������� �������� ��������: http://www.devart.com/ru/dbforge/mysql/studio
-- ���� �������: 22.02.2013 22:59:34
-- ������ �������: 5.5.9
-- ������ �������: 4.1

-- 
-- ���������� ������� ������
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- ��������� ���� ������ �� ���������
--
USE fox_ospace;

--
-- �������� ��� ������� diseases
--
DROP TABLE IF EXISTS diseases;
CREATE TABLE diseases (
  idDisease INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(32) NOT NULL,
  PRIMARY KEY (idDisease),
  UNIQUE INDEX name (name)
)
ENGINE = INNODB
AUTO_INCREMENT = 9
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� planettypes
--
DROP TABLE IF EXISTS planettypes;
CREATE TABLE planettypes (
  idPlanetType CHAR(1) NOT NULL,
  namePlanetType VARCHAR(32) NOT NULL,
  PRIMARY KEY (idPlanetType),
  UNIQUE INDEX namePlanetType (namePlanetType)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1820
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� race
--
DROP TABLE IF EXISTS race;
CREATE TABLE race (
  idRace INT(11) NOT NULL AUTO_INCREMENT,
  nameRace VARCHAR(64) NOT NULL,
  PRIMARY KEY (idRace),
  UNIQUE INDEX nameRace (nameRace)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� starclasses
--
DROP TABLE IF EXISTS starclasses;
CREATE TABLE starclasses (
  idStarClass CHAR(2) NOT NULL,
  starType CHAR(1) NOT NULL,
  starClass CHAR(1) NOT NULL,
  chance INT(11) UNSIGNED NOT NULL DEFAULT 0,
  subclassChanceMin INT(11) UNSIGNED NOT NULL DEFAULT 0,
  subclassChanceMax INT(11) UNSIGNED NOT NULL DEFAULT 10,
  nameStarClass VARCHAR(255) NOT NULL,
  PRIMARY KEY (idStarClass),
  UNIQUE INDEX nameStarClass (nameStarClass)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 682
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� strat_res
--
DROP TABLE IF EXISTS strat_res;
CREATE TABLE strat_res (
  idStratRes INT(11) NOT NULL AUTO_INCREMENT,
  nameStratRes VARCHAR(255) NOT NULL,
  PRIMARY KEY (idStratRes),
  UNIQUE INDEX nameStratRes (nameStratRes)
)
ENGINE = INNODB
AUTO_INCREMENT = 1001
AVG_ROW_LENGTH = 1638
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� techs
--
DROP TABLE IF EXISTS techs;
CREATE TABLE techs (
  idTech INT(11) NOT NULL AUTO_INCREMENT,
  TL TINYINT(1) UNSIGNED NOT NULL,
  symbol VARCHAR(32) NOT NULL,
  name VARCHAR(64) NOT NULL,
  startingLevel TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  shieldPerc DECIMAL(10, 4) UNSIGNED DEFAULT NULL,
  storEn INT(11) UNSIGNED DEFAULT NULL,
  startingAvailable TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  maxHP INT(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (idTech),
  UNIQUE INDEX name (name),
  UNIQUE INDEX symbol (symbol)
)
ENGINE = INNODB
AUTO_INCREMENT = 1804
AVG_ROW_LENGTH = 862
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  idUser INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(32) NOT NULL,
  salt VARCHAR(64) NOT NULL,
  `hash` CHAR(32) NOT NULL,
  lastLogin TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  galaxyCreateLimit INT(11) UNSIGNED NOT NULL DEFAULT 1,
  fullName VARCHAR(64) NOT NULL,
  PRIMARY KEY (idUser),
  UNIQUE INDEX login (login),
  UNIQUE INDEX salt (salt)
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� galaxy_templates
--
DROP TABLE IF EXISTS galaxy_templates;
CREATE TABLE galaxy_templates (
  idGalaxyTemplate INT(11) NOT NULL AUTO_INCREMENT,
  idUserOwner INT(11) DEFAULT NULL,
  nameGalaxyTemplate VARCHAR(64) NOT NULL,
  centerX INT(11) NOT NULL DEFAULT 500,
  centerY INT(11) NOT NULL DEFAULT 500,
  radius INT(11) UNSIGNED NOT NULL DEFAULT 500,
  galaxyMinR INT(11) UNSIGNED NOT NULL DEFAULT 75,
  galaxyPlayers INT(11) UNSIGNED NOT NULL DEFAULT 42,
  startRMin INT(11) UNSIGNED NOT NULL DEFAULT 320,
  startRMax INT(11) UNSIGNED NOT NULL DEFAULT 360,
  galaxyPlayerGroup INT(11) UNSIGNED NOT NULL DEFAULT 3,
  galaxyGroupDist INT(11) UNSIGNED NOT NULL DEFAULT 40,
  PRIMARY KEY (idGalaxyTemplate),
  UNIQUE INDEX UK_galaxyTemplates (idUserOwner, nameGalaxyTemplate),
  CONSTRAINT FK_galaxyTemplates_users FOREIGN KEY (idUserOwner)
    REFERENCES users(idUser) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� universes
--
DROP TABLE IF EXISTS universes;
CREATE TABLE universes (
  idUniverse INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  turn INT(11) UNSIGNED NOT NULL DEFAULT 0,
  idUserOwner INT(11) NOT NULL,
  PRIMARY KEY (idUniverse),
  UNIQUE INDEX name (name),
  CONSTRAINT FK_universes_users FOREIGN KEY (idUserOwner)
    REFERENCES users(idUser) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� users_sessions
--
DROP TABLE IF EXISTS users_sessions;
CREATE TABLE users_sessions (
  idUserSession INT(11) NOT NULL AUTO_INCREMENT,
  idUser INT(11) NOT NULL,
  ssid VARCHAR(32) NOT NULL,
  startTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  endTime DATETIME NOT NULL,
  PRIMARY KEY (idUserSession),
  UNIQUE INDEX cookie (ssid),
  CONSTRAINT FK_users_sessions_users FOREIGN KEY (idUser)
    REFERENCES users(idUser) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� galaxy_templates_density
--
DROP TABLE IF EXISTS galaxy_templates_density;
CREATE TABLE galaxy_templates_density (
  idGalaxyTemplatesDensity INT(11) NOT NULL AUTO_INCREMENT,
  idGalaxyTemplate INT(11) NOT NULL,
  radius INT(11) UNSIGNED NOT NULL DEFAULT 0,
  density INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (idGalaxyTemplatesDensity),
  CONSTRAINT FK_galaxyTemplatesDensity_galaxyTemplates FOREIGN KEY (idGalaxyTemplate)
    REFERENCES galaxy_templates(idGalaxyTemplate) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 7
AVG_ROW_LENGTH = 2730
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� galaxy_templates_diseases
--
DROP TABLE IF EXISTS galaxy_templates_diseases;
CREATE TABLE galaxy_templates_diseases (
  idGalaxyTemplateDecease INT(11) NOT NULL AUTO_INCREMENT,
  idGalaxyTemplate INT(11) NOT NULL,
  idDisease INT(11) NOT NULL,
  minR INT(11) UNSIGNED NOT NULL,
  maxR INT(11) NOT NULL,
  count INT(11) UNSIGNED NOT NULL,
  `comment` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (idGalaxyTemplateDecease),
  CONSTRAINT FK_galaxy_templates_diseases_diseases FOREIGN KEY (idDisease)
    REFERENCES diseases(idDisease) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT FK_galaxy_templates_diseases_galaxy_templates FOREIGN KEY (idGalaxyTemplate)
    REFERENCES galaxy_templates(idGalaxyTemplate) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 9
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� galaxy_templates_strat_res
--
DROP TABLE IF EXISTS galaxy_templates_strat_res;
CREATE TABLE galaxy_templates_strat_res (
  idGalaxyTemplateStratResource INT(11) NOT NULL AUTO_INCREMENT,
  idGalaxyTemplate INT(11) NOT NULL,
  idStratRes INT(11) NOT NULL,
  minR INT(11) UNSIGNED NOT NULL,
  maxR INT(11) NOT NULL,
  count INT(11) UNSIGNED NOT NULL,
  `comment` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (idGalaxyTemplateStratResource),
  CONSTRAINT FK_galaxy_templates_strat_res_strat_res FOREIGN KEY (idStratRes)
    REFERENCES strat_res(idStratRes) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT FK_galaxy_templates_strat_resources_galaxy_templates FOREIGN KEY (idGalaxyTemplate)
    REFERENCES galaxy_templates(idGalaxyTemplate) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 9
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� buoys
--
DROP TABLE IF EXISTS buoys;
CREATE TABLE buoys (
  idBuoy INT(11) NOT NULL AUTO_INCREMENT,
  idPlayerOwner INT(11) NOT NULL,
  PRIMARY KEY (idBuoy)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� diplomacyrels
--
DROP TABLE IF EXISTS diplomacyrels;
CREATE TABLE diplomacyrels (
  idDiplomacyRels INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer1 INT(11) NOT NULL,
  idPlayer2 INT(11) NOT NULL,
  PRIMARY KEY (idDiplomacyRels)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� fleets
--
DROP TABLE IF EXISTS fleets;
CREATE TABLE fleets (
  idFleet INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer INT(11) NOT NULL,
  idSystem INT(11) DEFAULT NULL,
  storEn DECIMAL(10, 4) UNSIGNED NOT NULL DEFAULT 0.0000,
  PRIMARY KEY (idFleet)
)
ENGINE = INNODB
AUTO_INCREMENT = 15
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� galaxies
--
DROP TABLE IF EXISTS galaxies;
CREATE TABLE galaxies (
  idGalaxy INT(11) NOT NULL AUTO_INCREMENT,
  idUniverse INT(11) NOT NULL,
  idUser INT(11) NOT NULL COMMENT 'Galaxy owner',
  name VARCHAR(64) NOT NULL,
  description TEXT NOT NULL,
  centerX INT(11) NOT NULL DEFAULT 500,
  centerY INT(11) NOT NULL DEFAULT 500,
  radius INT(11) UNSIGNED NOT NULL DEFAULT 500,
  timeEnabled TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  timeStopped TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  creationTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  idPlayerImperator INT(11) DEFAULT NULL,
  emrLevel FLOAT NOT NULL DEFAULT 1,
  emrTrend FLOAT NOT NULL DEFAULT 1,
  emrTime INT(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (idGalaxy),
  UNIQUE INDEX UK_galaxies (idUniverse, name)
)
ENGINE = INNODB
AUTO_INCREMENT = 52
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� minefields
--
DROP TABLE IF EXISTS minefields;
CREATE TABLE minefields (
  idMinefield INT(11) NOT NULL AUTO_INCREMENT,
  idSystem INT(11) NOT NULL,
  PRIMARY KEY (idMinefield)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� planets
--
DROP TABLE IF EXISTS planets;
CREATE TABLE planets (
  idPlanet INT(11) NOT NULL AUTO_INCREMENT,
  idSystem INT(11) NOT NULL,
  idPlayer INT(11) DEFAULT NULL,
  ownerSince INT(11) UNSIGNED NOT NULL DEFAULT 0,
  idPlanetType CHAR(1) NOT NULL,
  plDiameter INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plMin INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plBio INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plEn INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plEnv INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plSlots INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plMaxSlots INT(11) UNSIGNED NOT NULL DEFAULT 0,
  plStarting TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  idStratRes INT(11) DEFAULT NULL,
  idDisease INT(11) DEFAULT NULL,
  storPop INT(11) UNSIGNED NOT NULL DEFAULT 0,
  storBio INT(11) UNSIGNED NOT NULL DEFAULT 0,
  storEn INT(11) UNSIGNED NOT NULL DEFAULT 0,
  minBio INT(11) UNSIGNED NOT NULL DEFAULT 0,
  minEn INT(11) UNSIGNED NOT NULL DEFAULT 0,
  maxBio INT(11) UNSIGNED NOT NULL DEFAULT 0,
  maxEn INT(11) UNSIGNED NOT NULL DEFAULT 0,
  changeBio INT(11) NOT NULL DEFAULT 0,
  changeEn INT(11) NOT NULL DEFAULT 0,
  changePop INT(11) NOT NULL DEFAULT 0,
  changeEnv INT(11) NOT NULL DEFAULT 0,
  prodProd INT(11) NOT NULL DEFAULT 0,
  lastPirCapture INT(11) UNSIGNED DEFAULT NULL,
  effProdProd INT(11) NOT NULL DEFAULT 0,
  prodSci INT(11) NOT NULL DEFAULT 0,
  effProdSci INT(11) NOT NULL DEFAULT 0,
  unemployedPop INT(11) NOT NULL DEFAULT 0,
  popEatBio INT(11) UNSIGNED NOT NULL DEFAULT 10,
  popEatEn INT(11) NOT NULL DEFAULT 0,
  maxPop INT(11) NOT NULL DEFAULT 0,
  solarmod INT(11) UNSIGNED NOT NULL DEFAULT 0,
  scannerPwr INT(11) UNSIGNED NOT NULL DEFAULT 0,
  signature INT(11) UNSIGNED NOT NULL DEFAULT 75,
  autoMinStor TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  morale DECIMAL(5, 2) NOT NULL DEFAULT 100.00,
  changeMorale DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
  moraleTrgt DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
  revoltLen INT(11) NOT NULL DEFAULT 0,
  isMilitary TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  refuelMax INT(11) UNSIGNED NOT NULL DEFAULT 0,
  refuelInc INT(11) UNSIGNED NOT NULL DEFAULT 0,
  repairShip DECIMAL(5, 2) UNSIGNED NOT NULL DEFAULT 0.00,
  upgradeShip DECIMAL(10, 2) UNSIGNED NOT NULL DEFAULT 0.00,
  trainShipInc INT(11) UNSIGNED NOT NULL DEFAULT 0,
  trainShipMax INT(11) UNSIGNED NOT NULL DEFAULT 0,
  fleetSpeedBoost DECIMAL(10, 2) UNSIGNED NOT NULL DEFAULT 1.00,
  shield INT(11) UNSIGNED NOT NULL DEFAULT 0,
  maxShield INT(11) UNSIGNED NOT NULL DEFAULT 0,
  prevShield INT(11) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (idPlanet),
  INDEX IX_planets (idSystem, plEn)
)
ENGINE = INNODB
AUTO_INCREMENT = 103056
AVG_ROW_LENGTH = 235
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� players
--
DROP TABLE IF EXISTS players;
CREATE TABLE players (
  idPlayer INT(11) NOT NULL AUTO_INCREMENT,
  idUser INT(11) NOT NULL,
  idGalaxy INT(11) NOT NULL,
  sciPoints INT(11) UNSIGNED NOT NULL DEFAULT 0,
  effSciPoints INT(11) UNSIGNED NOT NULL DEFAULT 0,
  techLevel TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  idRace INT(11) DEFAULT NULL,
  prodEff DECIMAL(5, 2) NOT NULL DEFAULT 1.00,
  sciEff DECIMAL(5, 2) NOT NULL DEFAULT 1.00,
  govPwr INT(11) UNSIGNED NOT NULL DEFAULT 0,
  govPwrCtrlRange INT(11) NOT NULL DEFAULT 1,
  fleetUpgradePool DECIMAL(12, 2) UNSIGNED NOT NULL DEFAULT 0.00,
  fleetUpgradeInProgress TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  prodIncreasePool DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  idPlayerVoteFor INT(11) DEFAULT NULL,
  PRIMARY KEY (idPlayer)
)
ENGINE = INNODB
AUTO_INCREMENT = 43
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� playerstratres
--
DROP TABLE IF EXISTS playerstratres;
CREATE TABLE playerstratres (
  idPlayerStratRes INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer INT(11) NOT NULL,
  idStratRes INT(11) NOT NULL,
  PRIMARY KEY (idPlayerStratRes)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� players_techs
--
DROP TABLE IF EXISTS players_techs;
CREATE TABLE players_techs (
  idPlayerTech INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer INT(11) NOT NULL,
  idTech INT(11) NOT NULL,
  level INT(11) UNSIGNED NOT NULL DEFAULT 1,
  available TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (idPlayerTech)
)
ENGINE = INNODB
AUTO_INCREMENT = 658
AVG_ROW_LENGTH = 862
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� prodqueue
--
DROP TABLE IF EXISTS prodqueue;
CREATE TABLE prodqueue (
  idProdQueue INT(11) NOT NULL AUTO_INCREMENT,
  idPlanet INT(11) NOT NULL,
  PRIMARY KEY (idProdQueue)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� rsrchqueue
--
DROP TABLE IF EXISTS rsrchqueue;
CREATE TABLE rsrchqueue (
  idRsrchQueue INT(11) NOT NULL AUTO_INCREMENT,
  idPlayerOwner INT(11) NOT NULL,
  PRIMARY KEY (idRsrchQueue)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� shipredirections
--
DROP TABLE IF EXISTS shipredirections;
CREATE TABLE shipredirections (
  idShipredirection INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer INT(11) NOT NULL,
  PRIMARY KEY (idShipredirection)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� ships
--
DROP TABLE IF EXISTS ships;
CREATE TABLE ships (
  idShip INT(11) NOT NULL AUTO_INCREMENT,
  idFleet INT(11) NOT NULL,
  idShipDesign INT(11) NOT NULL,
  HP DECIMAL(10, 4) UNSIGNED NOT NULL,
  shield DECIMAL(10, 4) NOT NULL,
  experience DECIMAL(10, 4) UNSIGNED NOT NULL,
  PRIMARY KEY (idShip)
)
ENGINE = INNODB
AUTO_INCREMENT = 24
AVG_ROW_LENGTH = 3276
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� ship_designs
--
DROP TABLE IF EXISTS ship_designs;
CREATE TABLE ship_designs (
  idShipDesign INT(11) NOT NULL AUTO_INCREMENT,
  idPlayer INT(11) NOT NULL,
  name VARCHAR(64) NOT NULL,
  PRIMARY KEY (idShipDesign),
  UNIQUE INDEX UK_ship_designs (idPlayer, name)
)
ENGINE = INNODB
AUTO_INCREMENT = 73
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� ship_designs_equipment
--
DROP TABLE IF EXISTS ship_designs_equipment;
CREATE TABLE ship_designs_equipment (
  idShipDesign INT(11) NOT NULL,
  idPlayerTech INT(11) NOT NULL,
  qty INT(11) UNSIGNED NOT NULL DEFAULT 0,
  hull TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  control TINYINT(1) UNSIGNED NOT NULL DEFAULT 0
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1024
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� startingpos
--
DROP TABLE IF EXISTS startingpos;
CREATE TABLE startingpos (
  idStartingPos INT(11) NOT NULL AUTO_INCREMENT,
  idPlanet INT(11) NOT NULL,
  PRIMARY KEY (idStartingPos)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� structures
--
DROP TABLE IF EXISTS structures;
CREATE TABLE structures (
  idStructure INT(11) NOT NULL AUTO_INCREMENT,
  idTech INT(11) NOT NULL,
  idPlanet INT(11) NOT NULL,
  slot INT(11) UNSIGNED NOT NULL,
  idPlayer INT(11) NOT NULL,
  hitPoints INT(11) UNSIGNED NOT NULL,
  statusOn TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  statusNew TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (idStructure)
)
ENGINE = INNODB
AUTO_INCREMENT = 196
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- �������� ��� ������� systems
--
DROP TABLE IF EXISTS systems;
CREATE TABLE systems (
  idSystem INT(11) NOT NULL AUTO_INCREMENT,
  idGalaxy INT(11) NOT NULL,
  x INT(11) NOT NULL DEFAULT 0,
  y INT(11) NOT NULL,
  idStarClass CHAR(2) NOT NULL,
  starSubclass INT(11) NOT NULL DEFAULT 0,
  signature INT(11) UNSIGNED NOT NULL DEFAULT 100,
  lastNameChng INT(11) UNSIGNED NOT NULL DEFAULT 0,
  combatCounter INT(11) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (idSystem)
)
ENGINE = INNODB
AUTO_INCREMENT = 18714
AVG_ROW_LENGTH = 117
CHARACTER SET utf8
COLLATE utf8_general_ci;

ALTER TABLE buoys
          ADD CONSTRAINT FK_buoys_players FOREIGN KEY (idPlayerOwner)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE diplomacyrels
          ADD CONSTRAINT FK_diplomacyRels_players_idPlayer1 FOREIGN KEY (idPlayer1)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE diplomacyrels
          ADD CONSTRAINT FK_diplomacyRels_players_idPlayer2 FOREIGN KEY (idPlayer2)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE fleets
          ADD CONSTRAINT FK_fleets_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE fleets
          ADD CONSTRAINT FK_fleets_systems FOREIGN KEY (idSystem)
          REFERENCES systems (idSystem) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE galaxies
          ADD CONSTRAINT FK_galaxies_players_idPlayerImpeator FOREIGN KEY (idPlayerImperator)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE galaxies
          ADD CONSTRAINT FK_galaxies_universes FOREIGN KEY (idUniverse)
          REFERENCES universes (idUniverse) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE galaxies
          ADD CONSTRAINT FK_galaxies_users FOREIGN KEY (idUser)
          REFERENCES users (idUser) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE minefields
          ADD CONSTRAINT FK_minefields_systems FOREIGN KEY (idSystem)
          REFERENCES systems (idSystem) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE planets
          ADD CONSTRAINT FK_planets_planettypes FOREIGN KEY (idPlanetType)
          REFERENCES planettypes (idPlanetType) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE planets
          ADD CONSTRAINT FK_planets_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE SET NULL ON UPDATE RESTRICT;

ALTER TABLE planets
          ADD CONSTRAINT FK_planets_stratRes FOREIGN KEY (idStratRes)
          REFERENCES strat_res (idStratRes) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE planets
          ADD CONSTRAINT FK_planets_systems FOREIGN KEY (idSystem)
          REFERENCES systems (idSystem) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE players
          ADD CONSTRAINT FK_players_galaxies FOREIGN KEY (idGalaxy)
          REFERENCES galaxies (idGalaxy) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE players
          ADD CONSTRAINT FK_players_players_idPlayerVoteFor FOREIGN KEY (idPlayerVoteFor)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE players
          ADD CONSTRAINT FK_players_race FOREIGN KEY (idRace)
          REFERENCES race (idRace) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE players
          ADD CONSTRAINT FK_players_users FOREIGN KEY (idUser)
          REFERENCES users (idUser) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE playerstratres
          ADD CONSTRAINT FK_playerStratRes_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE playerstratres
          ADD CONSTRAINT FK_playerStratRes_stratRes FOREIGN KEY (idStratRes)
          REFERENCES strat_res (idStratRes) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE players_techs
          ADD CONSTRAINT FK_players_techs_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE players_techs
          ADD CONSTRAINT FK_players_techs_techs FOREIGN KEY (idTech)
          REFERENCES techs (idTech) ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE prodqueue
          ADD CONSTRAINT FK_prodQueue_planets FOREIGN KEY (idPlanet)
          REFERENCES planets (idPlanet) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE rsrchqueue
          ADD CONSTRAINT FK_rsrchQueue_players FOREIGN KEY (idPlayerOwner)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE shipredirections
          ADD CONSTRAINT FK_shipRedirections_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE ships
          ADD CONSTRAINT FK_ships_fleets FOREIGN KEY (idFleet)
          REFERENCES fleets (idFleet) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE ship_designs
          ADD CONSTRAINT FK_ship_designs_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE ship_designs_equipment
          ADD CONSTRAINT FK_ship_designs_equipment_players_techs FOREIGN KEY (idPlayerTech)
          REFERENCES players_techs (idPlayerTech) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE startingpos
          ADD CONSTRAINT FK_startingPos_planets FOREIGN KEY (idPlanet)
          REFERENCES planets (idPlanet) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE structures
          ADD CONSTRAINT FK_structures_planets FOREIGN KEY (idPlanet)
          REFERENCES planets (idPlanet) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE structures
          ADD CONSTRAINT FK_structures_players FOREIGN KEY (idPlayer)
          REFERENCES players (idPlayer) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE structures
          ADD CONSTRAINT FK_structures_techs FOREIGN KEY (idTech)
          REFERENCES techs (idTech) ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE systems
          ADD CONSTRAINT FK_systems_galaxies FOREIGN KEY (idGalaxy)
          REFERENCES galaxies (idGalaxy) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE systems
          ADD CONSTRAINT FK_systems_starClasses FOREIGN KEY (idStarClass)
          REFERENCES starclasses (idStarClass) ON DELETE RESTRICT ON UPDATE RESTRICT;

DELIMITER $$

--
-- �������� ��� ������� techEff
--
DROP FUNCTION IF EXISTS techEff$$
CREATE DEFINER = 'root'@'localhost'
FUNCTION techEff(
    $level INT
)
  RETURNS decimal(10,4)
BEGIN
    RETURN (SELECT CASE $level WHEN 1 THEN 0.750 WHEN 2 THEN 0.875 WHEN 3 THEN 1.000 WHEN 4 THEN 1.125 WHEN 5 THEN 1.250 ELSE NULL END);
END
$$

DELIMITER ;

-- 
-- ����� ������ ��� ������� diseases
--
INSERT INTO diseases VALUES 
  (1, '1'),
  (2, '2'),
  (3, '3'),
  (4, '4'),
  (5, '5'),
  (6, '6'),
  (7, '7'),
  (8, '8');

-- 
-- ����� ������ ��� ������� planettypes
--
INSERT INTO planettypes VALUES 
  ('A', 'Asteroid'),
  ('C', 'Cold'),
  ('D', 'Desert'),
  ('I', 'Gaia'),
  ('G', 'Gas Giant'),
  ('H', 'Hostile'),
  ('M', 'Marginal'),
  ('R', 'Rock'),
  ('E', 'Terrestrial');

-- 
-- ����� ������ ��� ������� race
--
-- ������� fox_ospace.race �� �������� ������

-- 
-- ����� ������ ��� ������� starclasses
--
INSERT INTO starclasses VALUES 
  ('b-', 'b', '-', 5, 0, 10, 'b-'),
  ('cA', 'c', 'A', 10, 0, 10, 'cA'),
  ('cB', 'c', 'B', 10, 0, 10, 'cB'),
  ('cF', 'c', 'F', 20, 0, 10, 'cF'),
  ('cG', 'c', 'G', 20, 0, 10, 'cG'),
  ('cK', 'c', 'K', 20, 0, 10, 'cK'),
  ('cM', 'c', 'M', 20, 0, 10, 'cM'),
  ('dA', 'd', 'A', 20000, 0, 10, 'dA'),
  ('dB', 'd', 'B', 10000, 0, 10, 'dB'),
  ('dF', 'd', 'F', 20000, 0, 10, 'dF'),
  ('dG', 'd', 'G', 10000, 0, 10, 'dG'),
  ('dK', 'd', 'K', 9500, 0, 10, 'dK'),
  ('gF', 'g', 'F', 400, 0, 10, 'gF'),
  ('gG', 'g', 'G', 500, 0, 10, 'gG'),
  ('gK', 'g', 'K', 4500, 0, 10, 'gK'),
  ('gM', 'g', 'M', 4500, 0, 10, 'gM'),
  ('mA', 'm', 'A', 10000, 0, 10, 'mA'),
  ('mB', 'm', 'B', 10000, 0, 10, 'mB'),
  ('mF', 'm', 'F', 80000, 0, 10, 'mF'),
  ('mG', 'm', 'G', 105000, 0, 10, 'mG'),
  ('mK', 'm', 'K', 240000, 0, 10, 'mK'),
  ('mM', 'm', 'M', 465000, 0, 10, 'mM'),
  ('mO', 'm', 'O', 10000, 5, 10, 'mO'),
  ('n-', 'n', '-', 495, 0, 10, 'n-');

-- 
-- ����� ������ ��� ������� strat_res
--
INSERT INTO strat_res VALUES 
  (6, 'Antimatter'),
  (5, 'Carboneum'),
  (3, 'Chromium'),
  (100, 'Mutagen'),
  (7, 'Plutonium'),
  (4, 'Silicium'),
  (2, 'Titanium'),
  (1000, 'Unnilseptium'),
  (1, 'Uranium'),
  (8, 'Wolframium');

-- 
-- ����� ������ ��� ������� techs
--
INSERT INTO techs VALUES 
  (1000, 1, 'GOVCENTER1', 'Government Center', 3, NULL, NULL, 0, 600),
  (1100, 1, 'OUTPOST1', 'Outpost', 3, NULL, NULL, 1, 400),
  (1101, 1, 'FACTORY1', 'Factory', 3, NULL, NULL, 1, 200),
  (1102, 1, 'PWRPLANTOIL1', 'Oil Power Plant', 3, NULL, 900, 1, 200),
  (1104, 1, 'FARM1', 'Farm', 3, NULL, NULL, 1, 200),
  (1105, 2, 'REPAIR1', 'Space Docks', 1, NULL, NULL, 0, 200),
  (1106, 1, 'RESCENTRE1', 'Research Laboratory', 3, NULL, NULL, 1, 200),
  (1111, 2, 'PWRPLANTNUK1', 'Nuclear Power Plant', 1, NULL, NULL, 0, 800),
  (1400, 1, 'SMALLHULL1', 'Small Hull', 1, NULL, 384, 0, 16),
  (1401, 1, 'FTLENG1', 'FTL Engine', 1, NULL, 96, 0, NULL),
  (1402, 1, 'SCOCKPIT1', 'Cockpit', 1, NULL, NULL, 0, 4),
  (1403, 1, 'SCANNERMOD1', 'Active Scanner Module', 1, NULL, NULL, 0, NULL),
  (1500, 1, 'CANNON1', 'Cannon', 1, NULL, NULL, 0, NULL),
  (1510, 1, 'CONBOMB1', 'Conventional Bomb', 1, NULL, NULL, 0, NULL),
  (1803, 1, 'IDLETASK', 'Idle task', 3, NULL, NULL, 1, NULL),
  (2400, 2, 'COLONYMOD2', 'Colony Module', 1, NULL, 960, 0, NULL),
  (2401, 2, 'MEDIUMHULL2', 'Medium Hull', 1, NULL, 768, 0, 64),
  (9004, 99, 'ANCFACTORY', 'Ancient Factory', 1, NULL, NULL, 0, 600),
  (9005, 99, 'ANCRESLAB', 'Ancient ResLab', 1, NULL, NULL, 0, 600);

-- 
-- ����� ������ ��� ������� users
--
INSERT INTO users VALUES 
  (1, 'root', 'YjB6F6t77eQygEwBwLkjB6E2bMoD3kusQQLfW1ghA8Ucey7Ta9eK44bGUvOAvNsT', '99deda9f3df70e894e371b4c58b74fb0', '2013-02-07 20:43:49', 9999980, 'root');

-- 
-- ����� ������ ��� ������� galaxy_templates
--
INSERT INTO galaxy_templates VALUES 
  (1, NULL, 'Default galaxy template', 500, 500, 500, 75, 42, 320, 360, 3, 40);

-- 
-- ����� ������ ��� ������� universes
--
INSERT INTO universes VALUES 
  (1, 'Universe', 0, 1);

-- 
-- ����� ������ ��� ������� users_sessions
--
INSERT INTO users_sessions VALUES 
  (1, 1, 'e6493dbcd275848688b2b0b14b32950b', '2013-02-13 22:21:33', '2013-02-13 23:21:33'),
  (2, 1, 'cdb03156ccd6c54e37cc65170e72b59e', '2013-02-13 22:21:44', '2013-02-13 23:21:44');

-- 
-- ����� ������ ��� ������� galaxy_templates_density
--
INSERT INTO galaxy_templates_density VALUES 
  (1, 1, 75, 30),
  (2, 1, 100, 40),
  (3, 1, 200, 50),
  (4, 1, 300, 55),
  (5, 1, 600, 60),
  (6, 1, 750, 60);

-- 
-- ����� ������ ��� ������� galaxy_templates_diseases
--
INSERT INTO galaxy_templates_diseases VALUES 
  (1, 1, 1, 200, 450, 8, 'TL 1 + 2'),
  (2, 1, 2, 200, 450, 8, 'TL 1 + 2'),
  (3, 1, 3, 50, 150, 4, 'TL 3 + 4'),
  (4, 1, 4, 50, 150, 4, 'TL 3 + 4'),
  (5, 1, 5, 50, 150, 4, 'TL 3 + 4'),
  (6, 1, 6, 0, 50, 1, 'TL 5'),
  (7, 1, 7, 0, 50, 1, 'TL 5'),
  (8, 1, 8, 0, 50, 1, 'TL 5');

-- 
-- ����� ������ ��� ������� galaxy_templates_strat_res
--
INSERT INTO galaxy_templates_strat_res VALUES 
  (1, 1, 1, 200, 450, 15, 'TL 1 + 2'),
  (2, 1, 2, 200, 450, 15, 'TL 1 + 2'),
  (3, 1, 3, 80, 150, 11, 'TL 3 + 4'),
  (4, 1, 4, 80, 150, 7, 'TL 3 + 4'),
  (5, 1, 5, 80, 150, 7, 'TL 3 + 4'),
  (6, 1, 6, 75, 90, 1, 'TL 5'),
  (7, 1, 7, 75, 90, 1, 'TL 5'),
  (8, 1, 8, 75, 90, 1, 'TL 5');

-- 
-- ����� ������ ��� ������� buoys
--
-- ������� fox_ospace.buoys �� �������� ������

-- 
-- ����� ������ ��� ������� diplomacyrels
--
-- ������� fox_ospace.diplomacyrels �� �������� ������

-- 
-- ����� ������ ��� ������� fleets
--
INSERT INTO fleets VALUES 
  (14, 42, 18675, 3600.0000);

-- 
-- ����� ������ ��� ������� galaxies
--
INSERT INTO galaxies VALUES 
  (51, 1, 1, 'New test galaxy', 'New galaxy "New test galaxy"', 0, 0, 100, 0, 0, '2013-02-10 01:44:43', NULL, 1, 1, 0);

-- 
-- ����� ������ ��� ������� minefields
--
-- ������� fox_ospace.minefields �� �������� ������

-- 
-- ����� ������ ��� ������� planets
--
INSERT INTO planets VALUES 
  (101053, 18199, NULL, 0, 'H', 10000, 100, 0, 84, 25, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101054, 18200, NULL, 0, 'H', 17000, 134, 0, 104, 20, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101055, 18200, NULL, 0, 'H', 20000, 134, 0, 98, 26, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101056, 18200, NULL, 0, 'A', 0, 55, 0, 33, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101057, 18200, NULL, 0, 'G', 90000, 182, 0, 28, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101058, 18200, NULL, 0, 'G', 180000, 68, 0, 22, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101059, 18201, NULL, 0, 'H', 17000, 88, 0, 50, 16, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101060, 18202, NULL, 0, 'R', 7000, 106, 0, 80, 3, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101061, 18203, NULL, 0, 'H', 19000, 86, 0, 92, 22, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101062, 18203, NULL, 0, 'C', 4000, 0, 0, 12, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101063, 18204, NULL, 0, 'R', 8000, 38, 0, 115, 2, 6, 8, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101064, 18204, NULL, 0, 'H', 12000, 162, 0, 84, 20, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101065, 18204, NULL, 0, 'M', 13000, 68, 0, 97, 25, 7, 13, 0, NULL, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101066, 18204, NULL, 0, 'G', 100000, 117, 0, 2, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101067, 18204, NULL, 0, 'C', 3000, 0, 0, 25, 4, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101068, 18204, NULL, 0, 'A', 0, 6, 0, 25, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101069, 18205, NULL, 0, 'R', 3000, 78, 0, 67, 2, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101070, 18205, NULL, 0, 'D', 6000, 56, 0, 0, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101071, 18205, NULL, 0, 'A', 0, 56, 0, 10, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101072, 18206, NULL, 0, 'H', 10000, 26, 0, 54, 16, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101073, 18207, NULL, 0, 'H', 17000, 116, 0, 86, 22, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101074, 18207, NULL, 0, 'C', 6000, 0, 0, 6, 0, 5, 6, 0, 6, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101075, 18207, NULL, 0, 'G', 150000, 183, 0, 24, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101076, 18208, NULL, 0, 'G', 140000, 110, 0, 60, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101077, 18208, NULL, 0, 'A', 0, 128, 0, 48, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101078, 18208, NULL, 0, 'C', 9000, 0, 0, 7, 0, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101079, 18209, NULL, 0, 'R', 7000, 94, 0, 113, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101080, 18209, NULL, 0, 'R', 3000, 116, 0, 107, 1, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101081, 18209, NULL, 0, 'G', 120000, 123, 0, 68, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101082, 18209, NULL, 0, 'M', 13000, 104, 0, 65, 33, 7, 13, 0, NULL, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101083, 18209, NULL, 0, 'G', 110000, 109, 0, 0, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101084, 18209, NULL, 0, 'A', 0, 94, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101085, 18209, NULL, 0, 'A', 0, 128, 0, 26, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101086, 18209, NULL, 0, 'G', 130000, 51, 0, 43, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101087, 18210, NULL, 0, 'H', 13000, 142, 0, 72, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101088, 18210, NULL, 0, 'R', 4000, 48, 0, 47, 2, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101089, 18211, NULL, 0, 'R', 1000, 114, 0, 122, 7, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101090, 18211, NULL, 0, 'M', 11000, 88, 0, 76, 31, 6, 11, 0, NULL, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101091, 18211, NULL, 0, 'D', 14000, 128, 0, 62, 8, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101092, 18211, NULL, 0, 'G', 90000, 98, 0, 7, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101093, 18211, NULL, 0, 'G', 180000, 149, 0, 38, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101094, 18211, NULL, 0, 'A', 0, 47, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101095, 18212, NULL, 0, 'D', 8000, 140, 0, 89, 9, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101096, 18212, NULL, 0, 'C', 2000, 0, 0, 19, 0, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101097, 18212, NULL, 0, 'D', 14000, 150, 0, 12, 13, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101098, 18213, NULL, 0, 'H', 15000, 80, 0, 50, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101099, 18213, NULL, 0, 'G', 110000, 154, 0, 19, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101100, 18213, NULL, 0, 'G', 110000, 95, 0, 37, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101101, 18214, NULL, 0, 'H', 20000, 130, 0, 56, 17, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101102, 18214, NULL, 0, 'G', 50000, 175, 0, 44, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101103, 18215, NULL, 0, 'R', 8000, 50, 0, 90, 7, 6, 8, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101104, 18216, NULL, 0, 'R', 4000, 102, 0, 143, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101105, 18216, NULL, 0, 'D', 6000, 120, 0, 58, 9, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101106, 18216, NULL, 0, 'G', 70000, 83, 0, 1, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101107, 18216, NULL, 0, 'G', 70000, 160, 0, 44, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101108, 18217, NULL, 0, 'H', 12000, 122, 0, 133, 21, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101109, 18217, NULL, 0, 'H', 11000, 98, 0, 92, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101110, 18217, NULL, 0, 'G', 140000, 175, 0, 0, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101111, 18217, NULL, 0, 'G', 130000, 146, 0, 3, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101112, 18217, NULL, 0, 'G', 170000, 119, 0, 49, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101113, 18218, NULL, 0, 'D', 9000, 72, 0, 84, 11, 7, 9, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101114, 18219, NULL, 0, 'G', 110000, 102, 0, 140, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101115, 18219, NULL, 0, 'D', 14000, 118, 0, 88, 7, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101116, 18219, NULL, 0, 'G', 90000, 111, 0, 12, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101117, 18219, NULL, 0, 'C', 3000, 0, 0, 29, 3, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101118, 18219, NULL, 0, 'G', 110000, 115, 0, 32, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101119, 18220, NULL, 0, 'R', 1000, 36, 0, 114, 2, 1, 1, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101120, 18220, NULL, 0, 'H', 10000, 150, 0, 94, 23, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101121, 18220, NULL, 0, 'G', 130000, 179, 0, 2, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101122, 18220, NULL, 0, 'D', 11000, 134, 0, 20, 8, 8, 11, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101123, 18221, NULL, 0, 'H', 14000, 66, 0, 53, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101124, 18221, NULL, 0, 'D', 7000, 64, 0, 43, 8, 5, 7, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101125, 18221, NULL, 0, 'A', 0, 111, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101126, 18222, NULL, 0, 'D', 8000, 86, 0, 65, 9, 6, 8, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101127, 18222, NULL, 0, 'G', 100000, 71, 0, 18, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101128, 18223, NULL, 0, 'H', 14000, 98, 0, 138, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101129, 18223, NULL, 0, 'H', 14000, 168, 0, 67, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101130, 18223, NULL, 0, 'A', 0, 112, 0, 99, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101131, 18223, NULL, 0, 'G', 100000, 94, 0, 16, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101132, 18223, NULL, 0, 'A', 0, 27, 0, 3, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101133, 18223, NULL, 0, 'A', 0, 89, 0, 18, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101134, 18223, NULL, 0, 'A', 0, 94, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101135, 18224, NULL, 0, 'H', 14000, 104, 0, 106, 25, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101136, 18224, NULL, 0, 'R', 11000, 26, 0, 82, 3, 8, 11, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101137, 18224, NULL, 0, 'D', 7000, 100, 0, 69, 6, 5, 7, 0, 7, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101138, 18224, NULL, 0, 'G', 180000, 33, 0, 43, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101139, 18224, NULL, 0, 'R', 11000, 46, 0, 26, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101140, 18224, NULL, 0, 'G', 190000, 100, 0, 47, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101141, 18225, NULL, 0, 'H', 11000, 110, 0, 82, 13, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101142, 18226, NULL, 0, 'H', 11000, 52, 0, 126, 18, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101143, 18226, NULL, 0, 'R', 4000, 92, 0, 92, 7, 3, 4, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101144, 18226, NULL, 0, 'D', 11000, 60, 0, 95, 9, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101145, 18226, NULL, 0, 'C', 1000, 0, 0, 5, 2, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101146, 18226, NULL, 0, 'D', 13000, 120, 0, 0, 7, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101147, 18226, NULL, 0, 'G', 170000, 148, 0, 48, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101148, 18227, NULL, 0, 'H', 15000, 112, 0, 118, 21, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101149, 18227, NULL, 0, 'D', 8000, 20, 0, 92, 10, 6, 8, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101150, 18227, NULL, 0, 'A', 0, 85, 0, 80, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101151, 18227, NULL, 0, 'D', 10000, 152, 0, 20, 9, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101152, 18227, NULL, 0, 'G', 160000, 132, 0, 48, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101153, 18227, NULL, 0, 'G', 90000, 166, 0, 18, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101154, 18228, NULL, 0, 'H', 14000, 96, 0, 67, 20, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101155, 18228, NULL, 0, 'D', 11000, 88, 0, 29, 7, 8, 11, 0, 8, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101156, 18228, NULL, 0, 'C', 1000, 0, 0, 39, 5, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101157, 18229, NULL, 0, 'H', 17000, 184, 0, 146, 16, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101158, 18229, NULL, 0, 'H', 8000, 108, 0, 52, 22, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101159, 18229, NULL, 0, 'A', 0, 156, 0, 86, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101160, 18229, NULL, 0, 'G', 70000, 146, 0, 38, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101161, 18229, NULL, 0, 'C', 4000, 0, 0, 28, 0, 3, 4, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101162, 18229, NULL, 0, 'D', 15000, 110, 0, 21, 12, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101163, 18230, NULL, 0, 'D', 10000, 118, 0, 96, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101164, 18230, NULL, 0, 'R', 1000, 76, 0, 40, 2, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101165, 18230, NULL, 0, 'G', 130000, 173, 0, 4, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101166, 18231, NULL, 0, 'R', 7000, 94, 0, 100, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101167, 18231, NULL, 0, 'D', 8000, 54, 0, 53, 12, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101168, 18231, NULL, 0, 'R', 2000, 56, 0, 48, 5, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101169, 18231, NULL, 0, 'G', 70000, 168, 0, 25, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101170, 18231, NULL, 0, 'G', 80000, 145, 0, 19, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101171, 18232, NULL, 0, 'H', 12000, 106, 0, 133, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101172, 18232, NULL, 0, 'A', 0, 80, 0, 96, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101173, 18232, NULL, 0, 'C', 10000, 0, 0, 43, 4, 8, 10, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101174, 18232, NULL, 0, 'H', 14000, 108, 0, 8, 14, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101175, 18233, NULL, 0, 'H', 8000, 58, 0, 75, 14, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101176, 18233, NULL, 0, 'H', 8000, 68, 0, 19, 15, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101177, 18234, NULL, 0, 'D', 10000, 66, 0, 52, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101178, 18234, NULL, 0, 'G', 100000, 51, 0, 7, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101179, 18235, NULL, 0, 'G', 70000, 132, 0, 105, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101180, 18235, NULL, 0, 'H', 11000, 144, 0, 63, 24, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101181, 18235, NULL, 0, 'G', 160000, 121, 0, 25, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101182, 18235, NULL, 0, 'A', 0, 86, 0, 36, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101183, 18235, NULL, 0, 'C', 6000, 0, 0, 48, 6, 5, 6, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101184, 18236, NULL, 0, 'H', 13000, 162, 0, 70, 16, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101185, 18236, NULL, 0, 'G', 120000, 106, 0, 19, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101186, 18236, NULL, 0, 'R', 2000, 42, 0, 46, 7, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101187, 18237, NULL, 0, 'R', 4000, 136, 0, 77, 1, 3, 4, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101188, 18237, NULL, 0, 'R', 2000, 46, 0, 12, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101189, 18238, NULL, 0, 'A', 0, 67, 0, 100, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101190, 18238, NULL, 0, 'M', 11000, 110, 0, 71, 28, 6, 11, 0, NULL, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101191, 18238, NULL, 0, 'C', 3000, 0, 0, 37, 6, 2, 3, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101192, 18238, NULL, 0, 'G', 120000, 141, 0, 39, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101193, 18239, NULL, 0, 'R', 4000, 98, 0, 63, 5, 3, 4, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101194, 18239, NULL, 0, 'G', 80000, 117, 0, 8, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101195, 18239, NULL, 0, 'G', 140000, 98, 0, 19, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101196, 18240, NULL, 0, 'H', 13000, 94, 0, 60, 16, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101197, 18241, NULL, 0, 'H', 16000, 60, 0, 85, 23, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101198, 18242, NULL, 0, 'E', 17000, 100, 0, 52, 100, 9, 17, 0, NULL, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101199, 18242, NULL, 0, 'G', 170000, 104, 0, 8, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101200, 18243, NULL, 0, 'G', 110000, 182, 0, 145, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101201, 18243, NULL, 0, 'E', 15000, 100, 0, 54, 100, 9, 15, 0, NULL, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101202, 18243, NULL, 0, 'R', 2000, 66, 0, 50, 5, 2, 2, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101203, 18243, NULL, 0, 'G', 110000, 51, 0, 27, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101204, 18243, NULL, 0, 'A', 0, 125, 0, 43, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101205, 18243, NULL, 0, 'C', 2000, 0, 0, 5, 3, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101206, 18244, NULL, 0, 'A', 0, 116, 0, 127, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101207, 18244, NULL, 0, 'H', 15000, 110, 0, 91, 22, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101208, 18244, NULL, 0, 'G', 70000, 87, 0, 15, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101209, 18244, NULL, 0, 'G', 110000, 136, 0, 49, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101210, 18245, NULL, 0, 'R', 9000, 136, 0, 148, 7, 7, 9, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101211, 18245, NULL, 0, 'G', 110000, 68, 0, 83, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101212, 18245, NULL, 0, 'G', 90000, 134, 0, 28, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101213, 18245, NULL, 0, 'A', 0, 165, 0, 21, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101214, 18246, NULL, 0, 'R', 10000, 46, 0, 143, 3, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101215, 18246, NULL, 0, 'H', 14000, 154, 0, 83, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101216, 18246, NULL, 0, 'A', 0, 43, 0, 50, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101217, 18246, NULL, 0, 'G', 60000, 100, 0, 1, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101218, 18246, NULL, 0, 'G', 140000, 114, 0, 9, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101219, 18247, NULL, 0, 'R', 8000, 44, 0, 143, 2, 6, 8, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101220, 18247, NULL, 0, 'D', 10000, 98, 0, 71, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101221, 18247, NULL, 0, 'H', 21000, 178, 0, 61, 20, 11, 21, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101222, 18247, NULL, 0, 'G', 160000, 91, 0, 14, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101223, 18247, NULL, 0, 'A', 0, 109, 0, 47, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101224, 18247, NULL, 0, 'A', 0, 95, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101225, 18248, NULL, 0, 'A', 0, 126, 0, 112, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101226, 18248, NULL, 0, 'H', 10000, 78, 0, 130, 15, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101227, 18248, NULL, 0, 'D', 12000, 80, 0, 92, 6, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101228, 18248, NULL, 0, 'E', 17000, 100, 0, 59, 100, 9, 17, 0, NULL, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101229, 18248, NULL, 0, 'G', 60000, 110, 0, 38, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101230, 18248, NULL, 0, 'H', 9000, 106, 0, 46, 25, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101231, 18248, NULL, 0, 'A', 0, 100, 0, 42, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101232, 18248, NULL, 0, 'G', 90000, 102, 0, 6, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101233, 18249, NULL, 0, 'G', 130000, 98, 0, 68, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101234, 18249, NULL, 0, 'C', 9000, 0, 0, 25, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101235, 18250, NULL, 0, 'H', 12000, 138, 0, 66, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101236, 18250, NULL, 0, 'G', 140000, 65, 0, 13, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101237, 18250, NULL, 0, 'G', 80000, 56, 0, 44, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101238, 18251, NULL, 0, 'H', 16000, 134, 0, 81, 22, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101239, 18251, NULL, 0, 'R', 4000, 76, 0, 14, 7, 3, 4, 0, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101240, 18252, NULL, 0, 'H', 10000, 168, 0, 69, 26, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101241, 18253, NULL, 0, 'R', 7000, 104, 0, 80, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101242, 18254, NULL, 0, 'H', 11000, 150, 0, 88, 18, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101243, 18254, NULL, 0, 'G', 130000, 115, 0, 49, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101244, 18255, NULL, 0, 'H', 17000, 80, 0, 78, 17, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101245, 18255, NULL, 0, 'G', 160000, 92, 0, 0, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101246, 18256, NULL, 0, 'R', 10000, 90, 0, 146, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101247, 18256, NULL, 0, 'R', 4000, 38, 0, 57, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101248, 18256, NULL, 0, 'G', 170000, 174, 0, 16, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101249, 18256, NULL, 0, 'C', 4000, 0, 0, 16, 0, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101250, 18257, NULL, 0, 'H', 14000, 150, 0, 129, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101251, 18257, NULL, 0, 'H', 10000, 72, 0, 135, 16, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101252, 18257, NULL, 0, 'H', 9000, 118, 0, 79, 13, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101253, 18257, NULL, 0, 'R', 6000, 50, 0, 69, 3, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101254, 18257, NULL, 0, 'R', 2000, 86, 0, 23, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101255, 18257, NULL, 0, 'G', 130000, 152, 0, 9, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101256, 18257, NULL, 0, 'G', 120000, 166, 0, 13, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101257, 18257, NULL, 0, 'R', 7000, 118, 0, 16, 4, 5, 7, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101258, 18258, NULL, 0, 'H', 10000, 102, 0, 115, 26, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101259, 18258, NULL, 0, 'M', 11000, 104, 0, 77, 30, 6, 11, 0, NULL, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101260, 18258, NULL, 0, 'G', 170000, 80, 0, 25, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101261, 18258, NULL, 0, 'G', 80000, 160, 0, 12, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101262, 18259, NULL, 0, 'D', 10000, 108, 0, 61, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101263, 18260, NULL, 0, 'H', 18000, 126, 0, 137, 16, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101264, 18260, NULL, 0, 'G', 160000, 96, 0, 58, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101265, 18260, NULL, 0, 'G', 150000, 88, 0, 13, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101266, 18260, NULL, 0, 'G', 120000, 111, 0, 15, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101267, 18260, NULL, 0, 'G', 140000, 114, 0, 20, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101268, 18261, NULL, 0, 'H', 7000, 128, 0, 88, 21, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101269, 18262, NULL, 0, 'H', 12000, 140, 0, 88, 25, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101270, 18262, NULL, 0, 'G', 170000, 117, 0, 40, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101271, 18263, NULL, 0, 'H', 17000, 112, 0, 142, 20, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101272, 18263, NULL, 0, 'G', 50000, 103, 0, 84, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101273, 18263, NULL, 0, 'A', 0, 110, 0, 37, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101274, 18263, NULL, 0, 'G', 130000, 124, 0, 47, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101275, 18264, NULL, 0, 'G', 80000, 37, 0, 107, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101276, 18264, NULL, 0, 'H', 13000, 108, 0, 79, 24, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101277, 18264, NULL, 0, 'G', 130000, 111, 0, 46, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101278, 18264, NULL, 0, 'C', 1000, 0, 0, 32, 2, 1, 1, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101279, 18265, NULL, 0, 'H', 7000, 62, 0, 150, 21, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101280, 18265, NULL, 0, 'R', 2000, 62, 0, 124, 0, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101281, 18265, NULL, 0, 'D', 7000, 98, 0, 76, 10, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101282, 18265, NULL, 0, 'E', 16000, 100, 0, 95, 100, 9, 16, 0, NULL, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101283, 18265, NULL, 0, 'G', 150000, 136, 0, 25, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101284, 18265, NULL, 0, 'C', 3000, 0, 0, 4, 2, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101285, 18265, NULL, 0, 'G', 130000, 59, 0, 17, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101286, 18265, NULL, 0, 'G', 120000, 126, 0, 15, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101287, 18266, NULL, 0, 'R', 9000, 38, 0, 118, 2, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101288, 18266, NULL, 0, 'A', 0, 57, 0, 91, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101289, 18266, NULL, 0, 'G', 190000, 133, 0, 23, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101290, 18266, NULL, 0, 'C', 5000, 0, 0, 30, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101291, 18267, NULL, 0, 'R', 11000, 92, 0, 116, 7, 8, 11, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101292, 18267, NULL, 0, 'H', 9000, 96, 0, 66, 15, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101293, 18267, NULL, 0, 'G', 100000, 118, 0, 13, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101294, 18267, NULL, 0, 'G', 130000, 79, 0, 4, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101295, 18268, NULL, 0, 'R', 3000, 48, 0, 121, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101296, 18268, NULL, 0, 'H', 14000, 74, 0, 70, 19, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101297, 18268, NULL, 0, 'G', 110000, 139, 0, 12, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101298, 18268, NULL, 0, 'C', 8000, 0, 0, 4, 2, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101299, 18269, NULL, 0, 'H', 8000, 56, 0, 64, 21, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101300, 18269, NULL, 0, 'G', 50000, 142, 0, 27, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101301, 18269, NULL, 0, 'G', 130000, 207, 0, 50, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101302, 18270, NULL, 0, 'H', 18000, 194, 0, 56, 17, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101303, 18271, NULL, 0, 'A', 0, 96, 0, 126, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101304, 18271, NULL, 0, 'M', 10000, 136, 0, 58, 42, 5, 10, 0, NULL, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101305, 18271, NULL, 0, 'D', 13000, 110, 0, 47, 13, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101306, 18271, NULL, 0, 'R', 9000, 96, 0, 14, 1, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101307, 18272, NULL, 0, 'H', 16000, 110, 0, 140, 24, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101308, 18272, NULL, 0, 'D', 13000, 140, 0, 53, 10, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101309, 18272, NULL, 0, 'A', 0, 66, 0, 8, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101310, 18272, NULL, 0, 'G', 170000, 105, 0, 34, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101311, 18273, NULL, 0, 'M', 8000, 106, 0, 64, 26, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101312, 18273, NULL, 0, 'G', 120000, 95, 0, 47, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101313, 18274, NULL, 0, 'R', 5000, 58, 0, 102, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101314, 18274, NULL, 0, 'R', 4000, 72, 0, 88, 0, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101315, 18274, NULL, 0, 'M', 16000, 100, 0, 53, 30, 8, 16, 0, NULL, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101316, 18274, NULL, 0, 'G', 90000, 116, 0, 40, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101317, 18274, NULL, 0, 'G', 170000, 156, 0, 29, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101318, 18274, NULL, 0, 'G', 110000, 55, 0, 31, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101319, 18275, NULL, 0, 'H', 8000, 68, 0, 73, 16, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101320, 18275, NULL, 0, 'G', 150000, 129, 0, 8, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101321, 18276, NULL, 0, 'D', 11000, 84, 0, 105, 9, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101322, 18276, NULL, 0, 'M', 11000, 144, 0, 77, 41, 6, 11, 0, NULL, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101323, 18276, NULL, 0, 'H', 16000, 180, 0, 13, 14, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101324, 18276, NULL, 0, 'G', 140000, 52, 0, 29, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101325, 18276, NULL, 0, 'G', 70000, 119, 0, 38, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101326, 18277, NULL, 0, 'H', 13000, 112, 0, 112, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101327, 18277, NULL, 0, 'H', 9000, 166, 0, 93, 13, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101328, 18277, NULL, 0, 'C', 11000, 0, 0, 42, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101329, 18277, NULL, 0, 'G', 80000, 121, 0, 23, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101330, 18278, NULL, 0, 'H', 13000, 88, 0, 123, 25, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101331, 18278, NULL, 0, 'E', 18000, 100, 0, 93, 100, 9, 18, 0, NULL, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101332, 18278, NULL, 0, 'D', 10000, 78, 0, 20, 11, 8, 10, 0, 5, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101333, 18278, NULL, 0, 'G', 110000, 183, 0, 23, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101334, 18279, NULL, 0, 'H', 16000, 110, 0, 147, 14, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101335, 18279, NULL, 0, 'M', 13000, 96, 0, 51, 48, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101336, 18279, NULL, 0, 'R', 9000, 80, 0, 68, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101337, 18279, NULL, 0, 'R', 2000, 42, 0, 9, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101338, 18279, NULL, 0, 'H', 14000, 38, 0, 29, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101339, 18279, NULL, 0, 'G', 110000, 25, 0, 14, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101340, 18279, NULL, 0, 'G', 70000, 163, 0, 23, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101341, 18280, NULL, 0, 'R', 4000, 92, 0, 139, 2, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101342, 18280, NULL, 0, 'H', 14000, 100, 0, 90, 24, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101343, 18280, NULL, 0, 'H', 12000, 130, 0, 6, 21, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101344, 18280, NULL, 0, 'G', 140000, 192, 0, 46, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101345, 18280, NULL, 0, 'G', 90000, 95, 0, 30, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101346, 18281, NULL, 0, 'D', 10000, 94, 0, 73, 10, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101347, 18282, NULL, 0, 'G', 100000, 89, 0, 109, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101348, 18282, NULL, 0, 'H', 13000, 126, 0, 73, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101349, 18282, NULL, 0, 'G', 110000, 66, 0, 22, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101350, 18282, NULL, 0, 'G', 120000, 166, 0, 41, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101351, 18283, NULL, 0, 'H', 7000, 68, 0, 68, 25, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101352, 18283, NULL, 0, 'G', 80000, 82, 0, 42, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101353, 18284, NULL, 0, 'H', 21000, 138, 0, 67, 18, 11, 21, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101354, 18284, NULL, 0, 'G', 170000, 49, 0, 7, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101355, 18284, NULL, 0, 'G', 110000, 74, 0, 43, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101356, 18285, NULL, 0, 'H', 7000, 82, 0, 54, 22, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101357, 18285, NULL, 0, 'A', 0, 63, 0, 45, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101358, 18285, NULL, 0, 'C', 7000, 0, 0, 47, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101359, 18286, NULL, 0, 'D', 9000, 70, 0, 58, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101360, 18286, NULL, 0, 'D', 7000, 130, 0, 30, 11, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101361, 18287, NULL, 0, 'D', 12000, 128, 0, 147, 7, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101362, 18287, NULL, 0, 'H', 13000, 168, 0, 116, 24, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101363, 18287, NULL, 0, 'H', 10000, 88, 0, 84, 16, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101364, 18287, NULL, 0, 'D', 10000, 130, 0, 98, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101365, 18287, NULL, 0, 'A', 0, 39, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101366, 18287, NULL, 0, 'G', 140000, 121, 0, 42, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101367, 18287, NULL, 0, 'G', 190000, 148, 0, 20, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101368, 18287, NULL, 0, 'G', 110000, 123, 0, 1, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101369, 18288, NULL, 0, 'R', 7000, 104, 0, 116, 1, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101370, 18288, NULL, 0, 'G', 160000, 201, 0, 69, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101371, 18288, NULL, 0, 'H', 16000, 98, 0, 31, 17, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101372, 18288, NULL, 0, 'G', 110000, 145, 0, 10, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101373, 18289, NULL, 0, 'R', 6000, 110, 0, 111, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101374, 18289, NULL, 0, 'H', 16000, 184, 0, 82, 22, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101375, 18289, NULL, 0, 'G', 150000, 187, 0, 18, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101376, 18289, NULL, 0, 'G', 80000, 161, 0, 36, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101377, 18290, NULL, 0, 'H', 9000, 118, 0, 89, 21, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101378, 18290, NULL, 0, 'G', 140000, 144, 0, 13, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101379, 18290, NULL, 0, 'H', 13000, 64, 0, 8, 16, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101380, 18291, NULL, 0, 'H', 8000, 114, 0, 107, 26, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101381, 18291, NULL, 0, 'D', 8000, 112, 0, 87, 11, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101382, 18291, NULL, 0, 'D', 14000, 144, 0, 74, 13, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101383, 18291, NULL, 0, 'C', 1000, 0, 0, 43, 3, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101384, 18291, NULL, 0, 'C', 9000, 0, 0, 20, 1, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101385, 18291, NULL, 0, 'G', 80000, 71, 0, 5, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101386, 18292, NULL, 0, 'R', 6000, 106, 0, 138, 0, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101387, 18292, NULL, 0, 'M', 15000, 134, 0, 86, 48, 8, 15, 0, NULL, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101388, 18292, NULL, 0, 'R', 7000, 112, 0, 66, 2, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101389, 18292, NULL, 0, 'G', 130000, 60, 0, 12, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101390, 18292, NULL, 0, 'C', 9000, 0, 0, 43, 0, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101391, 18292, NULL, 0, 'G', 100000, 137, 0, 4, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101392, 18292, NULL, 0, 'A', 0, 111, 0, 42, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101393, 18293, NULL, 0, 'D', 8000, 130, 0, 90, 8, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101394, 18294, NULL, 0, 'H', 14000, 124, 0, 50, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101395, 18294, NULL, 0, 'R', 10000, 126, 0, 49, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101396, 18295, NULL, 0, 'H', 11000, 38, 0, 96, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101397, 18295, NULL, 0, 'G', 130000, 106, 0, 44, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101398, 18296, NULL, 0, 'G', 70000, 114, 0, 136, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101399, 18296, NULL, 0, 'M', 9000, 132, 0, 55, 47, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101400, 18296, NULL, 0, 'H', 14000, 136, 0, 53, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101401, 18296, NULL, 0, 'D', 12000, 160, 0, 22, 11, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101402, 18296, NULL, 0, 'A', 0, 68, 0, 40, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101403, 18296, NULL, 0, 'G', 120000, 125, 0, 18, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101404, 18296, NULL, 0, 'A', 0, 90, 0, 22, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101405, 18297, NULL, 0, 'D', 6000, 22, 0, 100, 12, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101406, 18297, NULL, 0, 'G', 110000, 176, 0, 64, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101407, 18297, NULL, 0, 'A', 0, 154, 0, 33, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101408, 18297, NULL, 0, 'C', 10000, 0, 0, 11, 0, 8, 10, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101409, 18298, NULL, 0, 'R', 3000, 24, 0, 124, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101410, 18298, NULL, 0, 'D', 13000, 134, 0, 100, 9, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101411, 18298, NULL, 0, 'D', 6000, 72, 0, 98, 13, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101412, 18298, NULL, 0, 'G', 150000, 97, 0, 14, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101413, 18298, NULL, 0, 'G', 90000, 169, 0, 39, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101414, 18298, NULL, 0, 'G', 110000, 109, 0, 13, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101415, 18298, NULL, 0, 'G', 30000, 185, 0, 30, 0, 0, 30, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101416, 18299, NULL, 0, 'R', 2000, 106, 0, 71, 3, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101417, 18299, NULL, 0, 'G', 150000, 53, 0, 42, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101418, 18300, NULL, 0, 'D', 6000, 46, 0, 75, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101419, 18301, NULL, 0, 'R', 6000, 128, 0, 100, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101420, 18301, NULL, 0, 'M', 14000, 106, 0, 89, 47, 7, 14, 0, NULL, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101421, 18301, NULL, 0, 'G', 80000, 78, 0, 37, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101422, 18301, NULL, 0, 'G', 180000, 48, 0, 37, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101423, 18301, NULL, 0, 'A', 0, 126, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101424, 18302, NULL, 0, 'D', 11000, 84, 0, 108, 13, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101425, 18302, NULL, 0, 'M', 19000, 176, 0, 97, 34, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101426, 18302, NULL, 0, 'G', 110000, 156, 0, 34, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101427, 18302, NULL, 0, 'A', 0, 133, 0, 4, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101428, 18302, NULL, 0, 'G', 100000, 129, 0, 31, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101429, 18303, NULL, 0, 'H', 15000, 134, 0, 75, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101430, 18304, NULL, 0, 'H', 9000, 80, 0, 79, 16, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101431, 18305, NULL, 0, 'D', 4000, 60, 0, 85, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101432, 18305, NULL, 0, 'G', 90000, 95, 0, 27, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101433, 18305, NULL, 0, 'G', 170000, 120, 0, 49, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101434, 18306, NULL, 0, 'D', 11000, 134, 0, 111, 11, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101435, 18306, NULL, 0, 'H', 11000, 72, 0, 91, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101436, 18306, NULL, 0, 'R', 4000, 58, 0, 28, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101437, 18306, NULL, 0, 'D', 14000, 184, 0, 19, 6, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101438, 18307, NULL, 0, 'H', 18000, 146, 0, 105, 23, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101439, 18307, NULL, 0, 'M', 15000, 106, 0, 88, 34, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101440, 18307, NULL, 0, 'G', 100000, 165, 0, 8, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101441, 18307, NULL, 0, 'A', 0, 24, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101442, 18308, NULL, 0, 'H', 5000, 96, 0, 63, 15, 3, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101443, 18308, NULL, 0, 'G', 150000, 119, 0, 29, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101444, 18309, NULL, 0, 'H', 15000, 164, 0, 51, 23, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101445, 18309, NULL, 0, 'G', 130000, 160, 0, 6, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101446, 18310, NULL, 0, 'H', 15000, 120, 0, 65, 16, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101447, 18310, NULL, 0, 'G', 120000, 180, 0, 11, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101448, 18310, NULL, 0, 'G', 120000, 117, 0, 37, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101449, 18311, NULL, 0, 'R', 2000, 72, 0, 124, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101450, 18311, NULL, 0, 'R', 3000, 94, 0, 85, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101451, 18311, NULL, 0, 'A', 0, 13, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101452, 18311, NULL, 0, 'G', 120000, 76, 0, 33, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101453, 18311, NULL, 0, 'C', 10000, 0, 0, 16, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101454, 18312, NULL, 0, 'H', 15000, 80, 0, 97, 25, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101455, 18313, NULL, 0, 'H', 13000, 134, 0, 100, 22, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101456, 18313, NULL, 0, 'G', 130000, 96, 0, 29, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101457, 18314, NULL, 0, 'R', 10000, 82, 0, 136, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101458, 18314, NULL, 0, 'M', 14000, 170, 0, 81, 44, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101459, 18314, NULL, 0, 'C', 11000, 0, 0, 48, 2, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101460, 18314, NULL, 0, 'G', 50000, 167, 0, 4, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101461, 18315, NULL, 0, 'H', 12000, 44, 0, 59, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101462, 18315, NULL, 0, 'G', 60000, 89, 0, 46, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101463, 18316, NULL, 0, 'H', 9000, 50, 0, 145, 17, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101464, 18316, NULL, 0, 'R', 3000, 152, 0, 95, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101465, 18316, NULL, 0, 'C', 2000, 0, 0, 46, 5, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101466, 18316, NULL, 0, 'H', 12000, 92, 0, 43, 24, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101467, 18316, NULL, 0, 'G', 160000, 101, 0, 18, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101468, 18317, NULL, 0, 'H', 18000, 106, 0, 72, 12, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101469, 18317, NULL, 0, 'G', 70000, 100, 0, 10, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101470, 18318, NULL, 0, 'R', 5000, 86, 0, 134, 3, 4, 5, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101471, 18318, NULL, 0, 'A', 0, 90, 0, 80, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101472, 18318, NULL, 0, 'M', 12000, 60, 0, 86, 28, 6, 12, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101473, 18318, NULL, 0, 'A', 0, 105, 0, 45, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101474, 18318, NULL, 0, 'A', 0, 73, 0, 24, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101475, 18318, NULL, 0, 'C', 11000, 0, 0, 7, 1, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101476, 18319, NULL, 0, 'R', 11000, 58, 0, 66, 1, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101477, 18320, NULL, 0, 'R', 11000, 78, 0, 107, 4, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101478, 18320, NULL, 0, 'R', 6000, 92, 0, 71, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101479, 18320, NULL, 0, 'D', 4000, 40, 0, 36, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101480, 18320, NULL, 0, 'G', 60000, 98, 0, 11, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101481, 18321, NULL, 0, 'M', 18000, 126, 0, 70, 36, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101482, 18321, NULL, 0, 'A', 0, 108, 0, 10, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101483, 18322, NULL, 0, 'H', 9000, 54, 0, 146, 21, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101484, 18322, NULL, 0, 'R', 11000, 52, 0, 60, 1, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101485, 18322, NULL, 0, 'G', 110000, 132, 0, 0, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101486, 18322, NULL, 0, 'R', 11000, 128, 0, 33, 0, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101487, 18322, NULL, 0, 'G', 110000, 166, 0, 4, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101488, 18323, NULL, 0, 'D', 9000, 46, 0, 57, 8, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101489, 18323, NULL, 0, 'G', 180000, 121, 0, 3, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101490, 18323, NULL, 0, 'G', 100000, 96, 0, 37, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101491, 18324, NULL, 0, 'R', 5000, 136, 0, 51, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101492, 18325, NULL, 0, 'H', 10000, 80, 0, 101, 22, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101493, 18325, NULL, 0, 'H', 9000, 52, 0, 85, 13, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101494, 18325, NULL, 0, 'G', 130000, 92, 0, 26, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101495, 18325, NULL, 0, 'G', 130000, 142, 0, 47, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101496, 18325, NULL, 0, 'A', 0, 104, 0, 34, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101497, 18326, NULL, 0, 'H', 16000, 142, 0, 52, 20, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101498, 18326, NULL, 0, 'A', 0, 35, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101499, 18327, NULL, 0, 'H', 20000, 136, 0, 67, 19, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101500, 18328, NULL, 0, 'H', 16000, 184, 0, 135, 12, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101501, 18328, NULL, 0, 'H', 21000, 150, 0, 93, 24, 11, 21, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101502, 18328, NULL, 0, 'G', 160000, 105, 0, 2, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101503, 18328, NULL, 0, 'G', 120000, 12, 0, 49, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101504, 18328, NULL, 0, 'G', 120000, 108, 0, 30, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101505, 18329, NULL, 0, 'R', 8000, 88, 0, 111, 2, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101506, 18329, NULL, 0, 'R', 10000, 76, 0, 58, 3, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101507, 18329, NULL, 0, 'G', 150000, 116, 0, 38, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101508, 18329, NULL, 0, 'C', 5000, 0, 0, 43, 3, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101509, 18330, NULL, 0, 'H', 12000, 120, 0, 102, 13, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101510, 18330, NULL, 0, 'M', 13000, 94, 0, 51, 48, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101511, 18330, NULL, 0, 'D', 14000, 180, 0, 56, 12, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101512, 18330, NULL, 0, 'C', 9000, 0, 0, 30, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101513, 18330, NULL, 0, 'A', 0, 122, 0, 40, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101514, 18330, NULL, 0, 'G', 100000, 113, 0, 8, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101515, 18331, NULL, 0, 'H', 8000, 150, 0, 83, 20, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101516, 18331, NULL, 0, 'G', 110000, 168, 0, 44, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101517, 18331, NULL, 0, 'G', 140000, 162, 0, 9, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101518, 18332, NULL, 0, 'D', 6000, 114, 0, 69, 8, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101519, 18332, NULL, 0, 'G', 140000, 142, 0, 31, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101520, 18333, NULL, 0, 'R', 5000, 56, 0, 116, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101521, 18333, NULL, 0, 'M', 10000, 108, 0, 100, 43, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101522, 18333, NULL, 0, 'C', 6000, 0, 0, 39, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101523, 18333, NULL, 0, 'A', 0, 123, 0, 43, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101524, 18334, NULL, 0, 'R', 2000, 92, 0, 148, 7, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101525, 18334, NULL, 0, 'H', 12000, 108, 0, 87, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101526, 18334, NULL, 0, 'E', 16000, 100, 0, 76, 100, 9, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101527, 18334, NULL, 0, 'G', 50000, 39, 0, 13, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101528, 18334, NULL, 0, 'C', 1000, 0, 0, 4, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101529, 18334, NULL, 0, 'G', 120000, 125, 0, 30, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101530, 18335, NULL, 0, 'H', 14000, 146, 0, 92, 14, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101531, 18335, NULL, 0, 'G', 110000, 141, 0, 13, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101532, 18335, NULL, 0, 'G', 80000, 149, 0, 49, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101533, 18336, NULL, 0, 'H', 13000, 120, 0, 65, 15, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101534, 18337, NULL, 0, 'R', 5000, 84, 0, 110, 5, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101535, 18337, NULL, 0, 'H', 10000, 106, 0, 53, 16, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101536, 18337, NULL, 0, 'G', 160000, 127, 0, 18, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101537, 18337, NULL, 0, 'C', 10000, 0, 0, 3, 3, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101538, 18338, NULL, 0, 'H', 7000, 152, 0, 68, 26, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101539, 18338, NULL, 0, 'G', 90000, 93, 0, 10, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101540, 18339, NULL, 0, 'R', 7000, 102, 0, 105, 3, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101541, 18339, NULL, 0, 'D', 11000, 130, 0, 77, 7, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101542, 18339, NULL, 0, 'A', 0, 99, 0, 25, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101543, 18339, NULL, 0, 'D', 11000, 104, 0, 50, 10, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101544, 18340, NULL, 0, 'R', 3000, 122, 0, 80, 7, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101545, 18340, NULL, 0, 'A', 0, 90, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101546, 18340, NULL, 0, 'G', 110000, 111, 0, 45, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101547, 18341, NULL, 0, 'E', 16000, 100, 0, 94, 100, 9, 16, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101548, 18341, NULL, 0, 'G', 110000, 143, 0, 47, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101549, 18342, NULL, 0, 'D', 16000, 126, 0, 98, 10, 12, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101550, 18342, NULL, 0, 'G', 130000, 111, 0, 13, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101551, 18342, NULL, 0, 'R', 7000, 122, 0, 18, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101552, 18343, NULL, 0, 'H', 8000, 150, 0, 82, 15, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101553, 18343, NULL, 0, 'G', 90000, 55, 0, 44, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101554, 18343, NULL, 0, 'G', 150000, 55, 0, 0, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101555, 18344, NULL, 0, 'R', 10000, 146, 0, 128, 6, 8, 10, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101556, 18344, NULL, 0, 'H', 19000, 176, 0, 51, 24, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101557, 18344, NULL, 0, 'D', 14000, 174, 0, 71, 7, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101558, 18344, NULL, 0, 'G', 70000, 158, 0, 20, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101559, 18344, NULL, 0, 'A', 0, 93, 0, 49, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101560, 18344, NULL, 0, 'G', 200000, 139, 0, 33, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101561, 18345, NULL, 0, 'R', 4000, 96, 0, 141, 0, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101562, 18345, NULL, 0, 'H', 10000, 60, 0, 50, 17, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101563, 18345, NULL, 0, 'C', 8000, 0, 0, 19, 5, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101564, 18345, NULL, 0, 'R', 9000, 86, 0, 45, 2, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101565, 18346, NULL, 0, 'R', 5000, 110, 0, 142, 3, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101566, 18346, NULL, 0, 'H', 10000, 132, 0, 59, 12, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101567, 18346, NULL, 0, 'G', 30000, 104, 0, 35, 0, 0, 30, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101568, 18346, NULL, 0, 'G', 140000, 96, 0, 25, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101569, 18347, NULL, 0, 'M', 8000, 74, 0, 95, 35, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101570, 18348, NULL, 0, 'E', 16000, 100, 0, 58, 100, 9, 16, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101571, 18348, NULL, 0, 'G', 100000, 138, 0, 31, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101572, 18348, NULL, 0, 'G', 130000, 168, 0, 39, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101573, 18349, NULL, 0, 'H', 12000, 108, 0, 106, 17, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101574, 18349, NULL, 0, 'M', 16000, 48, 0, 54, 37, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101575, 18349, NULL, 0, 'H', 18000, 104, 0, 23, 18, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101576, 18349, NULL, 0, 'D', 5000, 90, 0, 10, 8, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101577, 18350, NULL, 0, 'D', 16000, 100, 0, 144, 9, 12, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101578, 18350, NULL, 0, 'M', 15000, 112, 0, 91, 32, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101579, 18350, NULL, 0, 'G', 130000, 135, 0, 44, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101580, 18350, NULL, 0, 'G', 100000, 50, 0, 36, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101581, 18350, NULL, 0, 'C', 3000, 0, 0, 2, 3, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101582, 18351, NULL, 0, 'G', 100000, 163, 0, 100, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101583, 18351, NULL, 0, 'H', 12000, 134, 0, 100, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101584, 18351, NULL, 0, 'H', 5000, 90, 0, 54, 18, 3, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101585, 18351, NULL, 0, 'G', 90000, 65, 0, 33, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101586, 18351, NULL, 0, 'C', 7000, 0, 0, 24, 3, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101587, 18351, NULL, 0, 'G', 100000, 77, 0, 35, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101588, 18351, NULL, 0, 'G', 100000, 127, 0, 43, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101589, 18352, NULL, 0, 'A', 0, 104, 0, 79, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101590, 18352, NULL, 0, 'G', 180000, 69, 0, 38, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101591, 18352, NULL, 0, 'H', 15000, 122, 0, 19, 26, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101592, 18353, NULL, 0, 'D', 9000, 74, 0, 73, 10, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101593, 18353, NULL, 0, 'C', 1000, 0, 0, 7, 7, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101594, 18353, NULL, 0, 'G', 140000, 96, 0, 17, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101595, 18354, NULL, 0, 'D', 10000, 84, 0, 112, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101596, 18354, NULL, 0, 'M', 13000, 136, 0, 93, 51, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101597, 18354, NULL, 0, 'G', 140000, 137, 0, 45, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101598, 18354, NULL, 0, 'D', 8000, 158, 0, 18, 12, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101599, 18354, NULL, 0, 'A', 0, 0, 0, 3, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101600, 18355, NULL, 0, 'H', 11000, 154, 0, 62, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101601, 18355, NULL, 0, 'G', 150000, 30, 0, 45, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101602, 18356, NULL, 0, 'H', 10000, 50, 0, 82, 19, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101603, 18357, NULL, 0, 'G', 140000, 135, 0, 81, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101604, 18357, NULL, 0, 'H', 4000, 16, 0, 44, 16, 2, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101605, 18358, NULL, 0, 'R', 9000, 150, 0, 122, 4, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101606, 18358, NULL, 0, 'D', 12000, 106, 0, 69, 9, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101607, 18358, NULL, 0, 'A', 0, 97, 0, 40, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101608, 18358, NULL, 0, 'G', 130000, 149, 0, 50, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101609, 18359, NULL, 0, 'H', 12000, 168, 0, 64, 16, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101610, 18359, NULL, 0, 'G', 170000, 33, 0, 6, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101611, 18359, NULL, 0, 'D', 12000, 96, 0, 27, 12, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101612, 18360, NULL, 0, 'D', 9000, 74, 0, 83, 10, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101613, 18361, NULL, 0, 'H', 19000, 88, 0, 85, 15, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101614, 18362, NULL, 0, 'D', 8000, 102, 0, 86, 12, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101615, 18362, NULL, 0, 'D', 14000, 126, 0, 30, 10, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101616, 18362, NULL, 0, 'A', 0, 81, 0, 43, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101617, 18363, NULL, 0, 'H', 13000, 92, 0, 132, 12, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101618, 18363, NULL, 0, 'H', 12000, 130, 0, 59, 24, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101619, 18363, NULL, 0, 'G', 150000, 166, 0, 32, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101620, 18363, NULL, 0, 'G', 100000, 30, 0, 8, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101621, 18364, NULL, 0, 'D', 14000, 162, 0, 75, 9, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101622, 18364, NULL, 0, 'G', 130000, 49, 0, 12, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101623, 18364, NULL, 0, 'A', 0, 28, 0, 39, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101624, 18365, NULL, 0, 'H', 17000, 58, 0, 141, 14, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101625, 18365, NULL, 0, 'H', 6000, 28, 0, 100, 18, 3, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101626, 18365, NULL, 0, 'R', 7000, 54, 0, 42, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101627, 18365, NULL, 0, 'G', 130000, 104, 0, 15, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101628, 18366, NULL, 0, 'H', 17000, 104, 0, 148, 16, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101629, 18366, NULL, 0, 'D', 9000, 126, 0, 89, 10, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101630, 18366, NULL, 0, 'H', 15000, 144, 0, 29, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101631, 18366, NULL, 0, 'H', 13000, 108, 0, 34, 17, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101632, 18367, NULL, 0, 'R', 2000, 62, 0, 125, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101633, 18367, NULL, 0, 'H', 21000, 162, 0, 99, 21, 11, 21, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101634, 18367, NULL, 0, 'D', 10000, 40, 0, 92, 8, 8, 10, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101635, 18367, NULL, 0, 'G', 100000, 60, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101636, 18367, NULL, 0, 'G', 150000, 50, 0, 3, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101637, 18367, NULL, 0, 'G', 150000, 138, 0, 2, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101638, 18368, NULL, 0, 'H', 13000, 50, 0, 111, 16, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101639, 18368, NULL, 0, 'H', 14000, 68, 0, 95, 12, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101640, 18368, NULL, 0, 'G', 120000, 35, 0, 16, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101641, 18368, NULL, 0, 'G', 140000, 130, 0, 15, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101642, 18369, NULL, 0, 'D', 14000, 90, 0, 66, 12, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101643, 18370, NULL, 0, 'H', 14000, 190, 0, 72, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101644, 18371, NULL, 0, 'H', 8000, 106, 0, 99, 14, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101645, 18371, NULL, 0, 'G', 130000, 149, 0, 42, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101646, 18371, NULL, 0, 'G', 190000, 148, 0, 48, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101647, 18372, NULL, 0, 'A', 0, 119, 0, 116, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101648, 18372, NULL, 0, 'R', 3000, 40, 0, 53, 4, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101649, 18372, NULL, 0, 'G', 80000, 123, 0, 50, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101650, 18372, NULL, 0, 'A', 0, 106, 0, 37, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101651, 18372, NULL, 0, 'A', 0, 119, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101652, 18373, NULL, 0, 'R', 9000, 138, 0, 120, 1, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101653, 18373, NULL, 0, 'H', 10000, 134, 0, 88, 18, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101654, 18373, NULL, 0, 'G', 110000, 79, 0, 10, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101655, 18373, NULL, 0, 'G', 160000, 66, 0, 50, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101656, 18374, NULL, 0, 'H', 15000, 174, 0, 66, 24, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101657, 18374, NULL, 0, 'C', 11000, 0, 0, 20, 2, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101658, 18375, NULL, 0, 'R', 3000, 128, 0, 116, 6, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101659, 18375, NULL, 0, 'D', 9000, 136, 0, 67, 12, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101660, 18375, NULL, 0, 'G', 70000, 86, 0, 37, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101661, 18375, NULL, 0, 'G', 100000, 191, 0, 10, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101662, 18376, NULL, 0, 'H', 6000, 84, 0, 70, 23, 3, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101663, 18376, NULL, 0, 'G', 40000, 100, 0, 42, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101664, 18376, NULL, 0, 'G', 170000, 116, 0, 6, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101665, 18377, NULL, 0, 'G', 150000, 167, 0, 106, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101666, 18377, NULL, 0, 'H', 18000, 134, 0, 63, 18, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101667, 18377, NULL, 0, 'A', 0, 77, 0, 3, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101668, 18377, NULL, 0, 'R', 8000, 72, 0, 48, 4, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101669, 18377, NULL, 0, 'D', 15000, 46, 0, 2, 12, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101670, 18378, NULL, 0, 'R', 6000, 46, 0, 137, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101671, 18378, NULL, 0, 'H', 14000, 64, 0, 82, 24, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101672, 18378, NULL, 0, 'G', 90000, 138, 0, 2, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101673, 18378, NULL, 0, 'G', 90000, 163, 0, 24, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101674, 18378, NULL, 0, 'G', 180000, 183, 0, 23, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101675, 18379, NULL, 0, 'H', 15000, 122, 0, 138, 22, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101676, 18379, NULL, 0, 'H', 15000, 106, 0, 89, 13, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101677, 18379, NULL, 0, 'A', 0, 25, 0, 49, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101678, 18379, NULL, 0, 'G', 90000, 109, 0, 14, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101679, 18379, NULL, 0, 'A', 0, 66, 0, 39, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101680, 18380, NULL, 0, 'A', 0, 125, 0, 112, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101681, 18380, NULL, 0, 'H', 16000, 188, 0, 70, 21, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101682, 18380, NULL, 0, 'G', 120000, 114, 0, 13, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101683, 18380, NULL, 0, 'G', 100000, 48, 0, 32, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101684, 18380, NULL, 0, 'A', 0, 71, 0, 31, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101685, 18381, NULL, 0, 'H', 15000, 72, 0, 70, 13, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101686, 18381, NULL, 0, 'G', 130000, 125, 0, 48, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101687, 18382, NULL, 0, 'D', 14000, 136, 0, 62, 10, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101688, 18382, NULL, 0, 'C', 5000, 0, 0, 37, 1, 4, 5, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101689, 18383, NULL, 0, 'D', 7000, 108, 0, 125, 7, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101690, 18383, NULL, 0, 'M', 11000, 66, 0, 79, 35, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101691, 18383, NULL, 0, 'G', 130000, 115, 0, 33, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101692, 18383, NULL, 0, 'G', 130000, 108, 0, 40, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101693, 18383, NULL, 0, 'G', 120000, 128, 0, 31, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101694, 18384, NULL, 0, 'M', 12000, 56, 0, 57, 47, 6, 12, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101695, 18384, NULL, 0, 'G', 190000, 134, 0, 2, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101696, 18384, NULL, 0, 'G', 180000, 183, 0, 6, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101697, 18385, NULL, 0, 'H', 14000, 140, 0, 62, 22, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101698, 18386, NULL, 0, 'D', 16000, 118, 0, 84, 11, 12, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101699, 18386, NULL, 0, 'G', 190000, 105, 0, 29, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101700, 18387, NULL, 0, 'H', 11000, 158, 0, 81, 13, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101701, 18387, NULL, 0, 'G', 120000, 145, 0, 19, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101702, 18387, NULL, 0, 'G', 60000, 105, 0, 48, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101703, 18388, NULL, 0, 'R', 11000, 110, 0, 102, 1, 8, 11, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101704, 18388, NULL, 0, 'H', 18000, 64, 0, 73, 12, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101705, 18388, NULL, 0, 'H', 8000, 32, 0, 59, 17, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101706, 18388, NULL, 0, 'R', 2000, 48, 0, 31, 2, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101707, 18388, NULL, 0, 'H', 7000, 136, 0, 8, 21, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101708, 18388, NULL, 0, 'G', 160000, 95, 0, 28, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101709, 18388, NULL, 0, 'R', 10000, 98, 0, 32, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101710, 18389, NULL, 0, 'D', 10000, 64, 0, 66, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101711, 18389, NULL, 0, 'A', 0, 61, 0, 27, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101712, 18389, NULL, 0, 'A', 0, 121, 0, 36, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101713, 18390, NULL, 0, 'A', 0, 59, 0, 98, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101714, 18390, NULL, 0, 'H', 11000, 154, 0, 36, 23, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101715, 18390, NULL, 0, 'G', 130000, 49, 0, 0, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101716, 18391, NULL, 0, 'H', 13000, 100, 0, 58, 15, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101717, 18391, NULL, 0, 'G', 100000, 136, 0, 25, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101718, 18391, NULL, 0, 'A', 0, 96, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101719, 18392, NULL, 0, 'A', 0, 77, 0, 140, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101720, 18392, NULL, 0, 'H', 11000, 102, 0, 107, 23, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101721, 18392, NULL, 0, 'A', 0, 83, 0, 55, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101722, 18392, NULL, 0, 'H', 11000, 178, 0, 85, 21, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101723, 18392, NULL, 0, 'A', 0, 56, 0, 42, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101724, 18392, NULL, 0, 'G', 160000, 173, 0, 34, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101725, 18392, NULL, 0, 'G', 130000, 147, 0, 26, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101726, 18392, NULL, 0, 'G', 170000, 49, 0, 49, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101727, 18393, NULL, 0, 'R', 5000, 100, 0, 114, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101728, 18393, NULL, 0, 'E', 15000, 100, 0, 50, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101729, 18393, NULL, 0, 'M', 15000, 84, 0, 66, 37, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101730, 18393, NULL, 0, 'G', 100000, 63, 0, 43, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101731, 18393, NULL, 0, 'H', 9000, 38, 0, 19, 24, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101732, 18393, NULL, 0, 'G', 120000, 128, 0, 50, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101733, 18393, NULL, 0, 'G', 60000, 81, 0, 4, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101734, 18394, NULL, 0, 'R', 10000, 68, 0, 80, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101735, 18394, NULL, 0, 'A', 0, 101, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101736, 18394, NULL, 0, 'G', 110000, 177, 0, 10, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101737, 18395, NULL, 0, 'R', 5000, 94, 0, 138, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101738, 18395, NULL, 0, 'H', 15000, 140, 0, 67, 20, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101739, 18395, NULL, 0, 'G', 140000, 112, 0, 38, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101740, 18395, NULL, 0, 'G', 60000, 87, 0, 39, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101741, 18395, NULL, 0, 'A', 0, 134, 0, 11, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101742, 18396, NULL, 0, 'H', 13000, 116, 0, 71, 23, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101743, 18396, NULL, 0, 'C', 10000, 0, 0, 42, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101744, 18396, NULL, 0, 'D', 10000, 54, 0, 11, 9, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101745, 18397, NULL, 0, 'R', 5000, 92, 0, 140, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101746, 18397, NULL, 0, 'R', 5000, 94, 0, 60, 4, 4, 5, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101747, 18397, NULL, 0, 'G', 80000, 129, 0, 20, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101748, 18397, NULL, 0, 'G', 150000, 59, 0, 46, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101749, 18398, NULL, 0, 'G', 130000, 25, 0, 91, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101750, 18398, NULL, 0, 'D', 11000, 94, 0, 38, 13, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101751, 18398, NULL, 0, 'G', 160000, 137, 0, 36, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101752, 18399, NULL, 0, 'D', 13000, 126, 0, 59, 12, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101753, 18399, NULL, 0, 'R', 6000, 94, 0, 29, 0, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101754, 18399, NULL, 0, 'A', 0, 113, 0, 31, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101755, 18400, NULL, 0, 'D', 6000, 40, 0, 142, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101756, 18400, NULL, 0, 'H', 10000, 122, 0, 84, 17, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101757, 18400, NULL, 0, 'C', 3000, 0, 0, 18, 4, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101758, 18400, NULL, 0, 'G', 110000, 150, 0, 44, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101759, 18401, NULL, 0, 'D', 11000, 112, 0, 116, 13, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101760, 18401, NULL, 0, 'A', 0, 37, 0, 62, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101761, 18401, NULL, 0, 'A', 0, 72, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101762, 18401, NULL, 0, 'G', 40000, 166, 0, 13, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101763, 18401, NULL, 0, 'G', 90000, 140, 0, 23, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101764, 18402, NULL, 0, 'R', 7000, 36, 0, 103, 5, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101765, 18402, NULL, 0, 'R', 11000, 70, 0, 70, 4, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101766, 18402, NULL, 0, 'G', 70000, 61, 0, 33, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101767, 18402, NULL, 0, 'C', 4000, 0, 0, 20, 1, 3, 4, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101768, 18402, NULL, 0, 'A', 0, 7, 0, 4, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101769, 18403, NULL, 0, 'M', 12000, 86, 0, 87, 51, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101770, 18403, NULL, 0, 'C', 3000, 0, 0, 3, 4, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101771, 18403, NULL, 0, 'G', 130000, 152, 0, 20, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101772, 18404, NULL, 0, 'R', 10000, 176, 0, 101, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101773, 18404, NULL, 0, 'A', 0, 157, 0, 84, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101774, 18404, NULL, 0, 'H', 13000, 174, 0, 21, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101775, 18404, NULL, 0, 'G', 120000, 176, 0, 31, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101776, 18405, NULL, 0, 'H', 21000, 94, 0, 128, 22, 11, 21, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101777, 18405, NULL, 0, 'H', 18000, 112, 0, 58, 19, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101778, 18405, NULL, 0, 'G', 100000, 163, 0, 27, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101779, 18405, NULL, 0, 'G', 170000, 91, 0, 35, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101780, 18406, NULL, 0, 'R', 4000, 96, 0, 114, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101781, 18406, NULL, 0, 'D', 9000, 96, 0, 82, 11, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101782, 18406, NULL, 0, 'A', 0, 61, 0, 94, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101783, 18406, NULL, 0, 'A', 0, 124, 0, 6, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101784, 18406, NULL, 0, 'G', 200000, 105, 0, 19, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101785, 18406, NULL, 0, 'G', 150000, 109, 0, 42, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101786, 18407, NULL, 0, 'H', 6000, 114, 0, 124, 26, 3, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101787, 18407, NULL, 0, 'M', 17000, 86, 0, 64, 50, 9, 17, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101788, 18407, NULL, 0, 'A', 0, 121, 0, 47, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101789, 18407, NULL, 0, 'G', 170000, 97, 0, 40, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101790, 18407, NULL, 0, 'G', 160000, 114, 0, 34, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101791, 18408, NULL, 0, 'R', 11000, 98, 0, 114, 2, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101792, 18408, NULL, 0, 'H', 13000, 36, 0, 80, 15, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101793, 18408, NULL, 0, 'H', 11000, 106, 0, 91, 19, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101794, 18408, NULL, 0, 'G', 110000, 96, 0, 6, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101795, 18408, NULL, 0, 'A', 0, 24, 0, 46, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101796, 18408, NULL, 0, 'C', 5000, 0, 0, 45, 6, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101797, 18409, NULL, 0, 'D', 13000, 76, 0, 92, 6, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101798, 18410, NULL, 0, 'D', 11000, 54, 0, 149, 12, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101799, 18410, NULL, 0, 'H', 15000, 134, 0, 81, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101800, 18410, NULL, 0, 'G', 140000, 107, 0, 50, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101801, 18410, NULL, 0, 'G', 50000, 105, 0, 5, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101802, 18410, NULL, 0, 'G', 100000, 90, 0, 24, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101803, 18411, NULL, 0, 'H', 14000, 108, 0, 84, 24, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101804, 18411, NULL, 0, 'G', 130000, 82, 0, 33, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101805, 18411, NULL, 0, 'G', 170000, 173, 0, 25, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101806, 18412, NULL, 0, 'R', 5000, 46, 0, 120, 0, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101807, 18412, NULL, 0, 'H', 15000, 84, 0, 50, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101808, 18412, NULL, 0, 'H', 13000, 138, 0, 92, 15, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101809, 18412, NULL, 0, 'G', 110000, 188, 0, 36, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101810, 18412, NULL, 0, 'R', 2000, 60, 0, 48, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101811, 18412, NULL, 0, 'G', 130000, 170, 0, 21, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101812, 18413, NULL, 0, 'R', 9000, 70, 0, 139, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101813, 18413, NULL, 0, 'E', 15000, 100, 0, 50, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101814, 18413, NULL, 0, 'G', 100000, 104, 0, 36, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101815, 18413, NULL, 0, 'R', 2000, 76, 0, 3, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101816, 18413, NULL, 0, 'H', 17000, 136, 0, 6, 25, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101817, 18414, NULL, 0, 'R', 10000, 120, 0, 102, 5, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101818, 18414, NULL, 0, 'D', 13000, 148, 0, 53, 7, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101819, 18414, NULL, 0, 'G', 110000, 69, 0, 9, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101820, 18414, NULL, 0, 'G', 130000, 117, 0, 39, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101821, 18415, NULL, 0, 'H', 15000, 114, 0, 121, 17, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101822, 18415, NULL, 0, 'G', 110000, 114, 0, 64, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101823, 18415, NULL, 0, 'M', 13000, 66, 0, 71, 39, 7, 13, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101824, 18415, NULL, 0, 'G', 110000, 105, 0, 18, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101825, 18415, NULL, 0, 'G', 130000, 138, 0, 32, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101826, 18415, NULL, 0, 'C', 1000, 0, 0, 12, 4, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101827, 18416, NULL, 0, 'R', 6000, 112, 0, 67, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101828, 18416, NULL, 0, 'D', 10000, 94, 0, 42, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101829, 18416, NULL, 0, 'G', 140000, 118, 0, 0, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101830, 18417, NULL, 0, 'D', 14000, 146, 0, 87, 10, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101831, 18417, NULL, 0, 'G', 160000, 174, 0, 19, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101832, 18417, NULL, 0, 'C', 9000, 0, 0, 46, 1, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101833, 18418, NULL, 0, 'D', 6000, 150, 0, 85, 13, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101834, 18418, NULL, 0, 'G', 140000, 119, 0, 48, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101835, 18419, NULL, 0, 'D', 10000, 68, 0, 132, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101836, 18419, NULL, 0, 'H', 10000, 122, 0, 89, 21, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101837, 18419, NULL, 0, 'A', 0, 67, 0, 82, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101838, 18419, NULL, 0, 'G', 140000, 148, 0, 42, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101839, 18419, NULL, 0, 'G', 110000, 77, 0, 2, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101840, 18419, NULL, 0, 'C', 10000, 0, 0, 4, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101841, 18420, NULL, 0, 'R', 4000, 90, 0, 58, 2, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101842, 18420, NULL, 0, 'H', 10000, 70, 0, 18, 14, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101843, 18420, NULL, 0, 'G', 200000, 52, 0, 15, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101844, 18421, NULL, 0, 'R', 9000, 116, 0, 129, 0, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101845, 18421, NULL, 0, 'G', 130000, 150, 0, 63, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101846, 18421, NULL, 0, 'G', 120000, 143, 0, 37, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101847, 18421, NULL, 0, 'G', 100000, 59, 0, 24, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101848, 18421, NULL, 0, 'G', 160000, 136, 0, 34, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101849, 18422, NULL, 0, 'R', 7000, 54, 0, 136, 7, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101850, 18422, NULL, 0, 'H', 12000, 54, 0, 57, 13, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101851, 18422, NULL, 0, 'D', 14000, 66, 0, 47, 12, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101852, 18422, NULL, 0, 'D', 5000, 114, 0, 33, 8, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101853, 18422, NULL, 0, 'G', 120000, 139, 0, 12, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101854, 18423, NULL, 0, 'R', 7000, 98, 0, 109, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101855, 18423, NULL, 0, 'D', 12000, 84, 0, 87, 6, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101856, 18423, NULL, 0, 'G', 120000, 147, 0, 31, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101857, 18423, NULL, 0, 'G', 120000, 183, 0, 21, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101858, 18424, NULL, 0, 'R', 11000, 70, 0, 119, 3, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101859, 18424, NULL, 0, 'E', 18000, 100, 0, 84, 100, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101860, 18424, NULL, 0, 'G', 100000, 201, 0, 18, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101861, 18424, NULL, 0, 'G', 170000, 67, 0, 30, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101862, 18425, NULL, 0, 'H', 16000, 106, 0, 85, 15, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101863, 18426, NULL, 0, 'R', 2000, 32, 0, 108, 7, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101864, 18426, NULL, 0, 'H', 11000, 136, 0, 53, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101865, 18426, NULL, 0, 'D', 12000, 74, 0, 91, 9, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101866, 18426, NULL, 0, 'A', 0, 45, 0, 4, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101867, 18426, NULL, 0, 'C', 3000, 0, 0, 6, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101868, 18426, NULL, 0, 'D', 6000, 100, 0, 18, 8, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101869, 18426, NULL, 0, 'H', 12000, 52, 0, 12, 26, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101870, 18427, NULL, 0, 'H', 13000, 90, 0, 80, 14, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101871, 18428, NULL, 0, 'D', 12000, 168, 0, 74, 11, 9, 12, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101872, 18428, NULL, 0, 'A', 0, 1, 0, 39, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101873, 18428, NULL, 0, 'A', 0, 71, 0, 31, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101874, 18429, NULL, 0, 'D', 9000, 142, 0, 70, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101875, 18429, NULL, 0, 'A', 0, 102, 0, 19, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101876, 18430, NULL, 0, 'H', 11000, 76, 0, 72, 16, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101877, 18430, NULL, 0, 'G', 150000, 169, 0, 46, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101878, 18431, NULL, 0, 'H', 11000, 118, 0, 57, 21, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101879, 18431, NULL, 0, 'A', 0, 41, 0, 41, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101880, 18432, NULL, 0, 'R', 4000, 156, 0, 117, 3, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101881, 18432, NULL, 0, 'M', 15000, 120, 0, 93, 36, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101882, 18432, NULL, 0, 'M', 16000, 132, 0, 83, 41, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101883, 18432, NULL, 0, 'G', 60000, 130, 0, 25, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101884, 18432, NULL, 0, 'G', 120000, 86, 0, 41, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101885, 18432, NULL, 0, 'G', 100000, 64, 0, 10, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101886, 18433, NULL, 0, 'H', 10000, 130, 0, 140, 12, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101887, 18433, NULL, 0, 'H', 15000, 174, 0, 64, 17, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101888, 18433, NULL, 0, 'G', 110000, 126, 0, 44, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101889, 18433, NULL, 0, 'A', 0, 86, 0, 40, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101890, 18433, NULL, 0, 'G', 140000, 109, 0, 30, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101891, 18434, NULL, 0, 'A', 0, 39, 0, 97, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101892, 18434, NULL, 0, 'R', 8000, 102, 0, 23, 2, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101893, 18435, NULL, 0, 'D', 15000, 120, 0, 53, 11, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101894, 18435, NULL, 0, 'C', 7000, 0, 0, 25, 1, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101895, 18435, NULL, 0, 'C', 4000, 0, 0, 7, 0, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101896, 18436, NULL, 0, 'R', 2000, 116, 0, 107, 2, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101897, 18436, NULL, 0, 'E', 15000, 100, 0, 83, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101898, 18436, NULL, 0, 'H', 8000, 134, 0, 91, 26, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101899, 18436, NULL, 0, 'C', 5000, 0, 0, 49, 1, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101900, 18436, NULL, 0, 'A', 0, 20, 0, 35, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101901, 18436, NULL, 0, 'G', 110000, 60, 0, 45, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101902, 18437, NULL, 0, 'H', 16000, 96, 0, 75, 18, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101903, 18438, NULL, 0, 'R', 7000, 40, 0, 126, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101904, 18438, NULL, 0, 'M', 9000, 124, 0, 76, 34, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101905, 18438, NULL, 0, 'H', 17000, 120, 0, 97, 20, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101906, 18438, NULL, 0, 'G', 130000, 89, 0, 26, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101907, 18438, NULL, 0, 'G', 130000, 105, 0, 9, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101908, 18438, NULL, 0, 'G', 90000, 177, 0, 49, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101909, 18439, NULL, 0, 'M', 9000, 102, 0, 97, 49, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101910, 18439, NULL, 0, 'A', 0, 28, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101911, 18439, NULL, 0, 'G', 140000, 193, 0, 16, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101912, 18440, NULL, 0, 'R', 6000, 114, 0, 134, 2, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101913, 18440, NULL, 0, 'R', 10000, 118, 0, 64, 1, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101914, 18440, NULL, 0, 'G', 100000, 138, 0, 21, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101915, 18440, NULL, 0, 'G', 60000, 110, 0, 50, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101916, 18440, NULL, 0, 'G', 120000, 50, 0, 2, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101917, 18441, NULL, 0, 'D', 9000, 110, 0, 129, 9, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101918, 18441, NULL, 0, 'M', 10000, 140, 0, 90, 30, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101919, 18441, NULL, 0, 'C', 8000, 0, 0, 50, 6, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101920, 18441, NULL, 0, 'C', 7000, 0, 0, 50, 3, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101921, 18442, NULL, 0, 'H', 12000, 96, 0, 87, 18, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101922, 18442, NULL, 0, 'C', 7000, 0, 0, 37, 5, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101923, 18442, NULL, 0, 'G', 90000, 184, 0, 14, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101924, 18443, NULL, 0, 'M', 13000, 156, 0, 90, 29, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101925, 18443, NULL, 0, 'R', 11000, 90, 0, 3, 6, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101926, 18444, NULL, 0, 'R', 1000, 88, 0, 148, 1, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101927, 18444, NULL, 0, 'G', 100000, 46, 0, 75, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101928, 18444, NULL, 0, 'A', 0, 91, 0, 36, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101929, 18444, NULL, 0, 'A', 0, 54, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101930, 18445, NULL, 0, 'A', 0, 136, 0, 135, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101931, 18445, NULL, 0, 'G', 120000, 175, 0, 116, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101932, 18445, NULL, 0, 'H', 15000, 186, 0, 51, 18, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101933, 18445, NULL, 0, 'E', 16000, 100, 0, 100, 100, 9, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101934, 18445, NULL, 0, 'G', 110000, 142, 0, 10, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101935, 18445, NULL, 0, 'A', 0, 56, 0, 35, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101936, 18445, NULL, 0, 'G', 80000, 82, 0, 45, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101937, 18445, NULL, 0, 'G', 110000, 109, 0, 10, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101938, 18446, NULL, 0, 'H', 14000, 124, 0, 99, 20, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101939, 18446, NULL, 0, 'G', 150000, 100, 0, 35, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101940, 18446, NULL, 0, 'A', 0, 80, 0, 27, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101941, 18447, NULL, 0, 'H', 14000, 144, 0, 87, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101942, 18447, NULL, 0, 'G', 110000, 175, 0, 35, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101943, 18447, NULL, 0, 'G', 140000, 143, 0, 45, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101944, 18448, NULL, 0, 'R', 1000, 74, 0, 132, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101945, 18448, NULL, 0, 'G', 100000, 112, 0, 132, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101946, 18448, NULL, 0, 'D', 9000, 40, 0, 69, 11, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101947, 18448, NULL, 0, 'A', 0, 104, 0, 99, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101948, 18448, NULL, 0, 'H', 14000, 150, 0, 2, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101949, 18448, NULL, 0, 'A', 0, 108, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101950, 18448, NULL, 0, 'A', 0, 88, 0, 8, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101951, 18448, NULL, 0, 'G', 80000, 92, 0, 14, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101952, 18449, NULL, 0, 'R', 6000, 78, 0, 123, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101953, 18449, NULL, 0, 'D', 10000, 140, 0, 74, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101954, 18449, NULL, 0, 'R', 1000, 76, 0, 96, 7, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101955, 18449, NULL, 0, 'G', 100000, 80, 0, 41, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101956, 18449, NULL, 0, 'D', 7000, 120, 0, 10, 9, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101957, 18449, NULL, 0, 'A', 0, 63, 0, 31, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101958, 18449, NULL, 0, 'G', 110000, 101, 0, 4, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101959, 18450, NULL, 0, 'H', 15000, 144, 0, 114, 26, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101960, 18450, NULL, 0, 'H', 6000, 60, 0, 77, 26, 3, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101961, 18450, NULL, 0, 'D', 11000, 112, 0, 76, 12, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101962, 18450, NULL, 0, 'G', 150000, 129, 0, 19, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101963, 18450, NULL, 0, 'A', 0, 73, 0, 34, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101964, 18450, NULL, 0, 'G', 70000, 178, 0, 37, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101965, 18451, NULL, 0, 'H', 12000, 120, 0, 56, 16, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101966, 18452, NULL, 0, 'H', 22000, 116, 0, 61, 23, 11, 22, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101967, 18452, NULL, 0, 'A', 0, 133, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101968, 18452, NULL, 0, 'D', 10000, 62, 0, 6, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101969, 18453, NULL, 0, 'R', 6000, 96, 0, 132, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101970, 18453, NULL, 0, 'M', 12000, 86, 0, 55, 42, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101971, 18453, NULL, 0, 'C', 3000, 0, 0, 21, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101972, 18453, NULL, 0, 'G', 140000, 38, 0, 44, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101973, 18453, NULL, 0, 'G', 140000, 140, 0, 50, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101974, 18454, NULL, 0, 'R', 9000, 40, 0, 143, 2, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101975, 18454, NULL, 0, 'R', 4000, 72, 0, 63, 0, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101976, 18454, NULL, 0, 'A', 0, 150, 0, 36, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101977, 18454, NULL, 0, 'G', 130000, 173, 0, 12, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101978, 18455, NULL, 0, 'R', 10000, 90, 0, 144, 1, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101979, 18455, NULL, 0, 'M', 10000, 38, 0, 87, 26, 5, 10, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101980, 18455, NULL, 0, 'M', 13000, 132, 0, 97, 25, 7, 13, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101981, 18455, NULL, 0, 'A', 0, 47, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101982, 18455, NULL, 0, 'C', 6000, 0, 0, 23, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101983, 18455, NULL, 0, 'C', 4000, 0, 0, 5, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101984, 18455, NULL, 0, 'G', 90000, 129, 0, 47, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101985, 18456, NULL, 0, 'D', 12000, 62, 0, 51, 8, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101986, 18456, NULL, 0, 'D', 9000, 86, 0, 26, 13, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101987, 18457, NULL, 0, 'H', 12000, 82, 0, 101, 12, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101988, 18457, NULL, 0, 'R', 8000, 98, 0, 100, 1, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101989, 18457, NULL, 0, 'G', 100000, 60, 0, 38, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101990, 18457, NULL, 0, 'C', 3000, 0, 0, 11, 1, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101991, 18458, NULL, 0, 'H', 15000, 114, 0, 100, 16, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101992, 18459, NULL, 0, 'R', 3000, 84, 0, 124, 6, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101993, 18459, NULL, 0, 'M', 17000, 142, 0, 67, 35, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101994, 18459, NULL, 0, 'C', 4000, 0, 0, 1, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101995, 18459, NULL, 0, 'G', 130000, 64, 0, 35, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101996, 18459, NULL, 0, 'G', 150000, 122, 0, 8, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101997, 18460, NULL, 0, 'D', 11000, 88, 0, 126, 11, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101998, 18460, NULL, 0, 'R', 4000, 30, 0, 79, 3, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (101999, 18460, NULL, 0, 'D', 7000, 86, 0, 53, 7, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102000, 18460, NULL, 0, 'A', 0, 157, 0, 13, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102001, 18460, NULL, 0, 'G', 130000, 164, 0, 49, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102002, 18460, NULL, 0, 'A', 0, 107, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102003, 18461, NULL, 0, 'D', 14000, 164, 0, 107, 11, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102004, 18461, NULL, 0, 'H', 12000, 148, 0, 55, 15, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102005, 18461, NULL, 0, 'G', 80000, 107, 0, 36, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102006, 18461, NULL, 0, 'G', 130000, 81, 0, 41, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102007, 18462, NULL, 0, 'R', 3000, 94, 0, 146, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102008, 18462, NULL, 0, 'M', 13000, 120, 0, 70, 28, 7, 13, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102009, 18462, NULL, 0, 'G', 100000, 63, 0, 39, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102010, 18462, NULL, 0, 'G', 130000, 42, 0, 50, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102011, 18462, NULL, 0, 'G', 110000, 90, 0, 50, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102012, 18463, NULL, 0, 'G', 190000, 105, 0, 108, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102013, 18463, NULL, 0, 'H', 14000, 134, 0, 63, 23, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102014, 18463, NULL, 0, 'H', 20000, 130, 0, 98, 24, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102015, 18463, NULL, 0, 'C', 1000, 0, 0, 31, 5, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102016, 18463, NULL, 0, 'G', 110000, 157, 0, 14, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102017, 18463, NULL, 0, 'C', 1000, 0, 0, 48, 3, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102018, 18463, NULL, 0, 'G', 70000, 32, 0, 49, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102019, 18464, NULL, 0, 'H', 8000, 154, 0, 60, 26, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102020, 18465, NULL, 0, 'D', 7000, 106, 0, 125, 9, 5, 7, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102021, 18465, NULL, 0, 'R', 7000, 130, 0, 54, 6, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102022, 18465, NULL, 0, 'H', 10000, 90, 0, 64, 17, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102023, 18465, NULL, 0, 'G', 100000, 90, 0, 43, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102024, 18465, NULL, 0, 'A', 0, 91, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102025, 18465, NULL, 0, 'R', 9000, 72, 0, 34, 4, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102026, 18465, NULL, 0, 'G', 170000, 150, 0, 13, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102027, 18466, NULL, 0, 'H', 15000, 102, 0, 76, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102028, 18466, NULL, 0, 'G', 120000, 126, 0, 43, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102029, 18466, NULL, 0, 'G', 50000, 117, 0, 19, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102030, 18467, NULL, 0, 'H', 8000, 58, 0, 137, 16, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102031, 18467, NULL, 0, 'R', 6000, 118, 0, 64, 0, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102032, 18467, NULL, 0, 'G', 150000, 177, 0, 1, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102033, 18467, NULL, 0, 'C', 4000, 0, 0, 20, 1, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102034, 18468, NULL, 0, 'A', 0, 61, 0, 120, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102035, 18468, NULL, 0, 'H', 12000, 110, 0, 78, 22, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102036, 18468, NULL, 0, 'R', 10000, 150, 0, 46, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102037, 18468, NULL, 0, 'G', 160000, 149, 0, 19, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102038, 18469, NULL, 0, 'A', 0, 114, 0, 137, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102039, 18469, NULL, 0, 'E', 15000, 100, 0, 87, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102040, 18469, NULL, 0, 'H', 14000, 76, 0, 90, 17, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102041, 18469, NULL, 0, 'G', 140000, 118, 0, 49, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102042, 18469, NULL, 0, 'R', 1000, 114, 0, 26, 6, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102043, 18469, NULL, 0, 'G', 110000, 138, 0, 50, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102044, 18470, NULL, 0, 'R', 3000, 28, 0, 126, 2, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102045, 18470, NULL, 0, 'H', 14000, 140, 0, 55, 17, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102046, 18470, NULL, 0, 'M', 11000, 122, 0, 85, 45, 6, 11, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102047, 18470, NULL, 0, 'D', 7000, 46, 0, 40, 13, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102048, 18470, NULL, 0, 'G', 150000, 99, 0, 7, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102049, 18470, NULL, 0, 'C', 5000, 0, 0, 24, 7, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102050, 18471, NULL, 0, 'H', 8000, 126, 0, 102, 13, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102051, 18471, NULL, 0, 'H', 15000, 176, 0, 90, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102052, 18471, NULL, 0, 'G', 80000, 82, 0, 15, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102053, 18471, NULL, 0, 'C', 10000, 0, 0, 17, 4, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102054, 18472, NULL, 0, 'R', 2000, 78, 0, 150, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102055, 18472, NULL, 0, 'M', 15000, 86, 0, 65, 29, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102056, 18472, NULL, 0, 'E', 18000, 100, 0, 68, 100, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102057, 18472, NULL, 0, 'G', 120000, 140, 0, 50, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102058, 18472, NULL, 0, 'A', 0, 99, 0, 16, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102059, 18472, NULL, 0, 'G', 120000, 45, 0, 10, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102060, 18473, NULL, 0, 'H', 14000, 176, 0, 114, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102061, 18473, NULL, 0, 'D', 11000, 78, 0, 74, 11, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102062, 18473, NULL, 0, 'A', 0, 75, 0, 53, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102063, 18473, NULL, 0, 'R', 1000, 112, 0, 41, 2, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102064, 18473, NULL, 0, 'D', 10000, 108, 0, 19, 10, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102065, 18473, NULL, 0, 'A', 0, 148, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102066, 18474, NULL, 0, 'R', 11000, 36, 0, 108, 1, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102067, 18474, NULL, 0, 'A', 0, 101, 0, 86, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102068, 18474, NULL, 0, 'R', 7000, 56, 0, 69, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102069, 18474, NULL, 0, 'A', 0, 122, 0, 26, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102070, 18474, NULL, 0, 'G', 140000, 158, 0, 43, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102071, 18474, NULL, 0, 'G', 140000, 86, 0, 28, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102072, 18474, NULL, 0, 'G', 130000, 100, 0, 41, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102073, 18475, NULL, 0, 'H', 12000, 160, 0, 92, 25, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102074, 18475, NULL, 0, 'D', 5000, 86, 0, 25, 10, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102075, 18476, NULL, 0, 'H', 9000, 68, 0, 75, 14, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102076, 18477, NULL, 0, 'H', 13000, 172, 0, 86, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102077, 18477, NULL, 0, 'G', 150000, 127, 0, 15, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102078, 18478, NULL, 0, 'A', 0, 81, 0, 116, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102079, 18478, NULL, 0, 'H', 15000, 192, 0, 97, 18, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102080, 18478, NULL, 0, 'R', 5000, 112, 0, 79, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102081, 18478, NULL, 0, 'G', 170000, 150, 0, 36, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102082, 18478, NULL, 0, 'G', 70000, 89, 0, 30, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102083, 18478, NULL, 0, 'A', 0, 120, 0, 18, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102084, 18479, NULL, 0, 'H', 14000, 108, 0, 117, 14, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102085, 18479, NULL, 0, 'R', 9000, 44, 0, 92, 3, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102086, 18479, NULL, 0, 'E', 14000, 100, 0, 92, 100, 9, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102087, 18479, NULL, 0, 'H', 17000, 102, 0, 41, 15, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102088, 18479, NULL, 0, 'A', 0, 118, 0, 15, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102089, 18479, NULL, 0, 'G', 100000, 100, 0, 33, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102090, 18479, NULL, 0, 'G', 60000, 108, 0, 7, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102091, 18480, NULL, 0, 'H', 14000, 112, 0, 51, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102092, 18480, NULL, 0, 'G', 80000, 86, 0, 43, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102093, 18480, NULL, 0, 'R', 8000, 92, 0, 34, 7, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102094, 18481, NULL, 0, 'H', 13000, 160, 0, 69, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102095, 18481, NULL, 0, 'C', 10000, 0, 0, 45, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102096, 18482, NULL, 0, 'H', 13000, 160, 0, 60, 23, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102097, 18482, NULL, 0, 'G', 50000, 109, 0, 1, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102098, 18482, NULL, 0, 'H', 12000, 108, 0, 11, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102099, 18483, NULL, 0, 'H', 19000, 168, 0, 88, 17, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102100, 18483, NULL, 0, 'G', 140000, 178, 0, 5, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102101, 18483, NULL, 0, 'G', 60000, 86, 0, 47, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102102, 18484, NULL, 0, 'D', 11000, 70, 0, 80, 11, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102103, 18484, NULL, 0, 'A', 0, 104, 0, 27, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102104, 18484, NULL, 0, 'G', 60000, 71, 0, 18, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102105, 18485, NULL, 0, 'H', 13000, 98, 0, 131, 17, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102106, 18485, NULL, 0, 'D', 9000, 98, 0, 94, 13, 7, 9, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102107, 18485, NULL, 0, 'G', 140000, 53, 0, 23, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102108, 18485, NULL, 0, 'G', 130000, 211, 0, 3, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102109, 18486, NULL, 0, 'R', 2000, 80, 0, 115, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102110, 18486, NULL, 0, 'A', 0, 159, 0, 70, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102111, 18486, NULL, 0, 'R', 9000, 50, 0, 32, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102112, 18486, NULL, 0, 'R', 5000, 74, 0, 38, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102113, 18486, NULL, 0, 'C', 7000, 0, 0, 31, 4, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102114, 18487, NULL, 0, 'D', 13000, 98, 0, 61, 11, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102115, 18488, NULL, 0, 'H', 10000, 78, 0, 146, 20, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102116, 18488, NULL, 0, 'D', 15000, 84, 0, 70, 9, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102117, 18488, NULL, 0, 'M', 13000, 86, 0, 75, 33, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102118, 18488, NULL, 0, 'G', 130000, 110, 0, 0, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102119, 18488, NULL, 0, 'C', 4000, 0, 0, 30, 3, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102120, 18488, NULL, 0, 'G', 110000, 96, 0, 20, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102121, 18489, NULL, 0, 'R', 8000, 46, 0, 108, 1, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102122, 18489, NULL, 0, 'G', 190000, 80, 0, 80, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102123, 18489, NULL, 0, 'A', 0, 119, 0, 44, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102124, 18489, NULL, 0, 'G', 110000, 46, 0, 29, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102125, 18490, NULL, 0, 'D', 11000, 96, 0, 125, 8, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102126, 18490, NULL, 0, 'R', 1000, 50, 0, 145, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102127, 18490, NULL, 0, 'E', 18000, 100, 0, 60, 100, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102128, 18490, NULL, 0, 'D', 10000, 114, 0, 100, 10, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102129, 18490, NULL, 0, 'A', 0, 129, 0, 19, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102130, 18490, NULL, 0, 'G', 100000, 125, 0, 0, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102131, 18490, NULL, 0, 'H', 4000, 136, 0, 33, 21, 2, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102132, 18490, NULL, 0, 'G', 110000, 99, 0, 15, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102133, 18491, NULL, 0, 'H', 11000, 112, 0, 96, 25, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102134, 18491, NULL, 0, 'G', 90000, 101, 0, 48, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102135, 18491, NULL, 0, 'G', 60000, 106, 0, 5, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102136, 18492, NULL, 0, 'H', 11000, 170, 0, 55, 18, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102137, 18492, NULL, 0, 'C', 4000, 0, 0, 8, 3, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102138, 18493, NULL, 0, 'R', 10000, 68, 0, 139, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102139, 18493, NULL, 0, 'H', 11000, 96, 0, 84, 17, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102140, 18493, NULL, 0, 'C', 11000, 0, 0, 5, 6, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102141, 18493, NULL, 0, 'A', 0, 47, 0, 37, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102142, 18494, NULL, 0, 'H', 11000, 98, 0, 52, 18, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102143, 18494, NULL, 0, 'G', 70000, 56, 0, 44, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102144, 18494, NULL, 0, 'A', 0, 73, 0, 3, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102145, 18495, NULL, 0, 'H', 11000, 94, 0, 105, 21, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102146, 18495, NULL, 0, 'H', 8000, 18, 0, 81, 13, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102147, 18495, NULL, 0, 'G', 140000, 185, 0, 7, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102148, 18495, NULL, 0, 'A', 0, 104, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102149, 18496, NULL, 0, 'G', 130000, 133, 0, 120, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102150, 18496, NULL, 0, 'H', 18000, 138, 0, 65, 23, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102151, 18496, NULL, 0, 'H', 17000, 172, 0, 62, 17, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102152, 18496, NULL, 0, 'G', 90000, 113, 0, 3, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102153, 18496, NULL, 0, 'C', 2000, 0, 0, 5, 5, 2, 2, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102154, 18496, NULL, 0, 'G', 60000, 111, 0, 46, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102155, 18496, NULL, 0, 'A', 0, 122, 0, 25, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102156, 18497, NULL, 0, 'R', 8000, 92, 0, 121, 3, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102157, 18497, NULL, 0, 'D', 5000, 46, 0, 85, 9, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102158, 18497, NULL, 0, 'C', 1000, 0, 0, 49, 3, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102159, 18497, NULL, 0, 'G', 150000, 78, 0, 21, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102160, 18498, NULL, 0, 'D', 13000, 164, 0, 84, 11, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102161, 18498, NULL, 0, 'G', 50000, 86, 0, 47, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102162, 18498, NULL, 0, 'G', 80000, 31, 0, 1, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102163, 18499, NULL, 0, 'R', 1000, 72, 0, 125, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102164, 18499, NULL, 0, 'A', 0, 109, 0, 55, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102165, 18499, NULL, 0, 'M', 12000, 134, 0, 76, 50, 6, 12, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102166, 18499, NULL, 0, 'G', 180000, 105, 0, 44, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102167, 18499, NULL, 0, 'C', 4000, 0, 0, 7, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102168, 18499, NULL, 0, 'G', 80000, 172, 0, 35, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102169, 18500, NULL, 0, 'D', 4000, 122, 0, 72, 12, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102170, 18500, NULL, 0, 'G', 120000, 86, 0, 6, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102171, 18500, NULL, 0, 'A', 0, 116, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102172, 18501, NULL, 0, 'H', 14000, 98, 0, 121, 17, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102173, 18501, NULL, 0, 'H', 7000, 44, 0, 88, 18, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102174, 18501, NULL, 0, 'H', 16000, 140, 0, 51, 14, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102175, 18501, NULL, 0, 'C', 4000, 0, 0, 45, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102176, 18501, NULL, 0, 'G', 110000, 92, 0, 44, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102177, 18501, NULL, 0, 'D', 9000, 74, 0, 10, 10, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102178, 18501, NULL, 0, 'G', 100000, 86, 0, 38, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102179, 18502, NULL, 0, 'R', 10000, 180, 0, 143, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102180, 18502, NULL, 0, 'H', 10000, 58, 0, 78, 12, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102181, 18502, NULL, 0, 'M', 12000, 68, 0, 54, 25, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102182, 18502, NULL, 0, 'A', 0, 75, 0, 49, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102183, 18502, NULL, 0, 'G', 110000, 120, 0, 47, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102184, 18502, NULL, 0, 'D', 12000, 176, 0, 2, 9, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102185, 18503, NULL, 0, 'H', 15000, 178, 0, 87, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102186, 18503, NULL, 0, 'A', 0, 37, 0, 17, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102187, 18503, NULL, 0, 'A', 0, 46, 0, 30, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102188, 18504, NULL, 0, 'R', 8000, 88, 0, 110, 0, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102189, 18504, NULL, 0, 'R', 3000, 144, 0, 129, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102190, 18504, NULL, 0, 'H', 12000, 174, 0, 78, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102191, 18504, NULL, 0, 'G', 120000, 81, 0, 53, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102192, 18504, NULL, 0, 'A', 0, 164, 0, 23, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102193, 18504, NULL, 0, 'A', 0, 98, 0, 6, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102194, 18504, NULL, 0, 'G', 100000, 120, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102195, 18504, NULL, 0, 'G', 110000, 104, 0, 11, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102196, 18505, NULL, 0, 'R', 4000, 86, 0, 127, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102197, 18505, NULL, 0, 'H', 12000, 136, 0, 85, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102198, 18505, NULL, 0, 'M', 13000, 114, 0, 80, 30, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102199, 18505, NULL, 0, 'D', 10000, 78, 0, 17, 11, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102200, 18505, NULL, 0, 'C', 6000, 0, 0, 19, 1, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102201, 18505, NULL, 0, 'G', 120000, 119, 0, 9, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102202, 18506, NULL, 0, 'R', 11000, 54, 0, 134, 7, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102203, 18506, NULL, 0, 'D', 7000, 106, 0, 93, 6, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102204, 18506, NULL, 0, 'A', 0, 127, 0, 44, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102205, 18506, NULL, 0, 'G', 90000, 178, 0, 8, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102206, 18507, NULL, 0, 'H', 15000, 92, 0, 140, 23, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102207, 18507, NULL, 0, 'M', 14000, 142, 0, 70, 38, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102208, 18507, NULL, 0, 'R', 10000, 114, 0, 40, 5, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102209, 18507, NULL, 0, 'G', 120000, 135, 0, 48, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102210, 18507, NULL, 0, 'H', 13000, 154, 0, 24, 16, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102211, 18508, NULL, 0, 'H', 13000, 124, 0, 87, 24, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102212, 18508, NULL, 0, 'G', 60000, 50, 0, 6, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102213, 18508, NULL, 0, 'A', 0, 141, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102214, 18509, NULL, 0, 'H', 11000, 92, 0, 69, 12, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102215, 18509, NULL, 0, 'G', 150000, 188, 0, 46, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102216, 18509, NULL, 0, 'R', 5000, 56, 0, 46, 6, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102217, 18510, NULL, 0, 'R', 1000, 68, 0, 123, 5, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102218, 18510, NULL, 0, 'H', 7000, 112, 0, 76, 14, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102219, 18510, NULL, 0, 'A', 0, 37, 0, 26, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102220, 18510, NULL, 0, 'G', 150000, 105, 0, 43, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102221, 18511, NULL, 0, 'R', 5000, 66, 0, 141, 7, 4, 5, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102222, 18511, NULL, 0, 'M', 8000, 76, 0, 80, 26, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102223, 18511, NULL, 0, 'C', 7000, 0, 0, 24, 6, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102224, 18511, NULL, 0, 'G', 120000, 45, 0, 1, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102225, 18511, NULL, 0, 'H', 11000, 106, 0, 42, 15, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102226, 18512, NULL, 0, 'A', 0, 46, 0, 101, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102227, 18512, NULL, 0, 'D', 8000, 148, 0, 52, 9, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102228, 18512, NULL, 0, 'H', 19000, 180, 0, 20, 12, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102229, 18512, NULL, 0, 'A', 0, 33, 0, 29, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102230, 18513, NULL, 0, 'H', 7000, 90, 0, 68, 24, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102231, 18513, NULL, 0, 'G', 130000, 164, 0, 21, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102232, 18513, NULL, 0, 'G', 140000, 63, 0, 2, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102233, 18514, NULL, 0, 'H', 9000, 84, 0, 107, 17, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102234, 18514, NULL, 0, 'H', 12000, 128, 0, 98, 24, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102235, 18514, NULL, 0, 'R', 2000, 72, 0, 29, 7, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102236, 18514, NULL, 0, 'G', 110000, 149, 0, 25, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102237, 18515, NULL, 0, 'D', 10000, 116, 0, 61, 10, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102238, 18515, NULL, 0, 'G', 90000, 187, 0, 8, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102239, 18516, NULL, 0, 'D', 8000, 54, 0, 98, 10, 6, 8, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102240, 18516, NULL, 0, 'G', 140000, 115, 0, 1, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102241, 18517, NULL, 0, 'R', 6000, 58, 0, 149, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102242, 18517, NULL, 0, 'H', 13000, 116, 0, 93, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102243, 18517, NULL, 0, 'E', 15000, 100, 0, 50, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102244, 18517, NULL, 0, 'A', 0, 100, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102245, 18517, NULL, 0, 'G', 110000, 83, 0, 15, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102246, 18517, NULL, 0, 'G', 110000, 139, 0, 21, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102247, 18518, NULL, 0, 'D', 8000, 104, 0, 114, 8, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102248, 18518, NULL, 0, 'H', 11000, 148, 0, 94, 22, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102249, 18518, NULL, 0, 'H', 8000, 64, 0, 67, 17, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102250, 18518, NULL, 0, 'G', 120000, 147, 0, 26, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102251, 18518, NULL, 0, 'G', 100000, 130, 0, 33, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102252, 18518, NULL, 0, 'G', 90000, 140, 0, 2, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102253, 18519, NULL, 0, 'D', 11000, 108, 0, 63, 6, 8, 11, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102254, 18520, NULL, 0, 'H', 10000, 80, 0, 78, 12, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102255, 18521, NULL, 0, 'H', 11000, 158, 0, 110, 21, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102256, 18521, NULL, 0, 'D', 13000, 100, 0, 99, 10, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102257, 18521, NULL, 0, 'A', 0, 107, 0, 17, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102258, 18521, NULL, 0, 'G', 150000, 85, 0, 31, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102259, 18522, NULL, 0, 'R', 4000, 32, 0, 134, 7, 3, 4, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102260, 18522, NULL, 0, 'E', 17000, 100, 0, 96, 100, 9, 17, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102261, 18522, NULL, 0, 'A', 0, 86, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102262, 18522, NULL, 0, 'G', 120000, 153, 0, 32, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102263, 18523, NULL, 0, 'A', 0, 32, 0, 78, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102264, 18523, NULL, 0, 'D', 10000, 128, 0, 9, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102265, 18523, NULL, 0, 'G', 110000, 95, 0, 43, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102266, 18524, NULL, 0, 'G', 40000, 123, 0, 150, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102267, 18524, NULL, 0, 'H', 15000, 86, 0, 78, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102268, 18524, NULL, 0, 'A', 0, 28, 0, 53, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102269, 18524, NULL, 0, 'G', 80000, 118, 0, 36, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102270, 18524, NULL, 0, 'G', 100000, 133, 0, 49, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102271, 18524, NULL, 0, 'G', 150000, 42, 0, 23, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102272, 18525, NULL, 0, 'H', 15000, 98, 0, 123, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102273, 18525, NULL, 0, 'H', 14000, 52, 0, 96, 15, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102274, 18525, NULL, 0, 'D', 10000, 82, 0, 86, 13, 8, 10, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102275, 18525, NULL, 0, 'C', 3000, 0, 0, 15, 1, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102276, 18525, NULL, 0, 'G', 180000, 83, 0, 36, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102277, 18525, NULL, 0, 'G', 160000, 103, 0, 28, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102278, 18526, NULL, 0, 'H', 11000, 120, 0, 68, 25, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102279, 18526, NULL, 0, 'G', 140000, 77, 0, 6, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102280, 18526, NULL, 0, 'R', 1000, 34, 0, 14, 5, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102281, 18527, NULL, 0, 'G', 140000, 76, 0, 86, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102282, 18527, NULL, 0, 'G', 140000, 43, 0, 45, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102283, 18527, NULL, 0, 'C', 6000, 0, 0, 15, 1, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102284, 18528, NULL, 0, 'H', 16000, 114, 0, 95, 18, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102285, 18528, NULL, 0, 'G', 180000, 160, 0, 11, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102286, 18528, NULL, 0, 'G', 150000, 85, 0, 15, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102287, 18529, NULL, 0, 'H', 15000, 128, 0, 123, 19, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102288, 18529, NULL, 0, 'D', 13000, 124, 0, 123, 6, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102289, 18529, NULL, 0, 'M', 13000, 52, 0, 85, 37, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102290, 18529, NULL, 0, 'H', 14000, 130, 0, 73, 17, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102291, 18529, NULL, 0, 'G', 50000, 133, 0, 1, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102292, 18529, NULL, 0, 'G', 100000, 119, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102293, 18529, NULL, 0, 'G', 140000, 107, 0, 13, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102294, 18529, NULL, 0, 'A', 0, 89, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102295, 18530, NULL, 0, 'H', 8000, 66, 0, 71, 15, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102296, 18530, NULL, 0, 'C', 6000, 0, 0, 38, 4, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102297, 18531, NULL, 0, 'H', 19000, 126, 0, 95, 13, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102298, 18531, NULL, 0, 'A', 0, 97, 0, 18, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102299, 18532, NULL, 0, 'R', 11000, 58, 0, 55, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102300, 18532, NULL, 0, 'G', 140000, 160, 0, 15, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102301, 18533, NULL, 0, 'R', 3000, 102, 0, 103, 6, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102302, 18533, NULL, 0, 'D', 9000, 106, 0, 50, 9, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102303, 18533, NULL, 0, 'E', 17000, 100, 0, 51, 100, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102304, 18533, NULL, 0, 'G', 130000, 94, 0, 24, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102305, 18533, NULL, 0, 'G', 110000, 109, 0, 1, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102306, 18533, NULL, 0, 'H', 8000, 130, 0, 34, 14, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102307, 18533, NULL, 0, 'G', 60000, 133, 0, 48, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102308, 18534, NULL, 0, 'D', 8000, 82, 0, 101, 11, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102309, 18534, NULL, 0, 'H', 7000, 48, 0, 73, 25, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102310, 18534, NULL, 0, 'G', 80000, 120, 0, 25, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102311, 18534, NULL, 0, 'G', 190000, 116, 0, 27, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102312, 18535, NULL, 0, 'R', 6000, 120, 0, 52, 2, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102313, 18535, NULL, 0, 'R', 1000, 58, 0, 19, 3, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102314, 18536, NULL, 0, 'H', 18000, 122, 0, 86, 24, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102315, 18537, NULL, 0, 'H', 13000, 102, 0, 51, 22, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102316, 18537, NULL, 0, 'G', 90000, 145, 0, 50, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102317, 18538, NULL, 0, 'H', 12000, 110, 0, 51, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102318, 18538, NULL, 0, 'G', 80000, 156, 0, 35, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102319, 18539, NULL, 0, 'R', 2000, 68, 0, 114, 6, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102320, 18539, NULL, 0, 'H', 15000, 98, 0, 67, 21, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102321, 18539, NULL, 0, 'R', 6000, 36, 0, 96, 2, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102322, 18539, NULL, 0, 'A', 0, 42, 0, 5, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102323, 18539, NULL, 0, 'C', 2000, 0, 0, 45, 5, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102324, 18539, NULL, 0, 'A', 0, 108, 0, 41, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102325, 18539, NULL, 0, 'C', 10000, 0, 0, 38, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102326, 18540, NULL, 0, 'R', 3000, 54, 0, 146, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102327, 18540, NULL, 0, 'D', 15000, 56, 0, 56, 6, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102328, 18540, NULL, 0, 'G', 80000, 41, 0, 46, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102329, 18540, NULL, 0, 'G', 160000, 215, 0, 34, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102330, 18540, NULL, 0, 'G', 100000, 104, 0, 26, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102331, 18541, NULL, 0, 'H', 10000, 38, 0, 148, 14, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102332, 18541, NULL, 0, 'H', 12000, 132, 0, 88, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102333, 18541, NULL, 0, 'H', 9000, 88, 0, 82, 13, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102334, 18541, NULL, 0, 'G', 90000, 113, 0, 17, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102335, 18541, NULL, 0, 'C', 5000, 0, 0, 17, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102336, 18541, NULL, 0, 'C', 6000, 0, 0, 40, 1, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102337, 18542, NULL, 0, 'R', 2000, 44, 0, 133, 1, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102338, 18542, NULL, 0, 'M', 13000, 126, 0, 74, 41, 7, 13, 0, NULL, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102339, 18542, NULL, 0, 'A', 0, 163, 0, 100, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102340, 18542, NULL, 0, 'A', 0, 78, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102341, 18542, NULL, 0, 'C', 11000, 0, 0, 49, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102342, 18542, NULL, 0, 'A', 0, 174, 0, 46, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102343, 18543, NULL, 0, 'R', 5000, 14, 0, 150, 3, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102344, 18543, NULL, 0, 'R', 1000, 34, 0, 54, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102345, 18543, NULL, 0, 'G', 200000, 119, 0, 39, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102346, 18543, NULL, 0, 'G', 80000, 96, 0, 17, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102347, 18543, NULL, 0, 'G', 160000, 155, 0, 27, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102348, 18544, NULL, 0, 'H', 16000, 106, 0, 125, 13, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102349, 18544, NULL, 0, 'A', 0, 87, 0, 82, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102350, 18544, NULL, 0, 'G', 120000, 174, 0, 34, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102351, 18544, NULL, 0, 'G', 110000, 54, 0, 32, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102352, 18545, NULL, 0, 'R', 3000, 70, 0, 111, 7, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102353, 18545, NULL, 0, 'H', 11000, 132, 0, 84, 19, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102354, 18545, NULL, 0, 'G', 50000, 53, 0, 87, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102355, 18545, NULL, 0, 'G', 130000, 62, 0, 43, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102356, 18545, NULL, 0, 'A', 0, 68, 0, 11, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102357, 18545, NULL, 0, 'G', 80000, 120, 0, 7, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102358, 18545, NULL, 0, 'R', 6000, 114, 0, 26, 4, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102359, 18546, NULL, 0, 'A', 0, 37, 0, 92, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102360, 18546, NULL, 0, 'H', 9000, 120, 0, 19, 12, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102361, 18546, NULL, 0, 'R', 4000, 48, 0, 38, 1, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102362, 18547, NULL, 0, 'A', 0, 167, 0, 50, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102363, 18547, NULL, 0, 'C', 8000, 0, 0, 18, 6, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102364, 18548, NULL, 0, 'D', 13000, 126, 0, 122, 12, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102365, 18548, NULL, 0, 'H', 9000, 128, 0, 66, 20, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102366, 18548, NULL, 0, 'A', 0, 108, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102367, 18548, NULL, 0, 'G', 140000, 98, 0, 33, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102368, 18549, NULL, 0, 'A', 0, 69, 0, 141, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102369, 18549, NULL, 0, 'H', 15000, 154, 0, 90, 19, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102370, 18549, NULL, 0, 'G', 90000, 117, 0, 97, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102371, 18549, NULL, 0, 'R', 1000, 80, 0, 12, 7, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102372, 18549, NULL, 0, 'C', 3000, 0, 0, 7, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102373, 18549, NULL, 0, 'G', 110000, 129, 0, 11, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102374, 18550, NULL, 0, 'H', 16000, 126, 0, 90, 15, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102375, 18550, NULL, 0, 'G', 140000, 69, 0, 31, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102376, 18550, NULL, 0, 'G', 90000, 132, 0, 20, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102377, 18551, NULL, 0, 'R', 7000, 56, 0, 126, 1, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102378, 18551, NULL, 0, 'G', 130000, 31, 0, 81, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102379, 18551, NULL, 0, 'D', 6000, 56, 0, 53, 13, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102380, 18551, NULL, 0, 'C', 11000, 0, 0, 49, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102381, 18551, NULL, 0, 'G', 120000, 78, 0, 32, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102382, 18551, NULL, 0, 'G', 150000, 83, 0, 38, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102383, 18552, NULL, 0, 'M', 14000, 96, 0, 93, 48, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102384, 18552, NULL, 0, 'R', 7000, 132, 0, 16, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102385, 18552, NULL, 0, 'G', 110000, 97, 0, 6, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102386, 18553, NULL, 0, 'H', 19000, 84, 0, 144, 26, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102387, 18553, NULL, 0, 'G', 120000, 100, 0, 82, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102388, 18553, NULL, 0, 'G', 130000, 69, 0, 7, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102389, 18553, NULL, 0, 'G', 130000, 103, 0, 0, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102390, 18553, NULL, 0, 'G', 120000, 162, 0, 8, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102391, 18554, NULL, 0, 'G', 130000, 114, 0, 52, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102392, 18554, NULL, 0, 'R', 1000, 100, 0, 41, 6, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102393, 18554, NULL, 0, 'C', 6000, 0, 0, 23, 3, 5, 6, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102394, 18555, NULL, 0, 'R', 1000, 6, 0, 147, 3, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102395, 18555, NULL, 0, 'D', 11000, 108, 0, 63, 7, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102396, 18555, NULL, 0, 'D', 14000, 114, 0, 6, 11, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102397, 18555, NULL, 0, 'G', 140000, 142, 0, 25, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102398, 18555, NULL, 0, 'C', 8000, 0, 0, 49, 2, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102399, 18556, NULL, 0, 'H', 14000, 170, 0, 73, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102400, 18556, NULL, 0, 'G', 40000, 131, 0, 23, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102401, 18557, NULL, 0, 'D', 15000, 120, 0, 76, 6, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102402, 18557, NULL, 0, 'G', 150000, 101, 0, 0, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102403, 18557, NULL, 0, 'G', 180000, 92, 0, 14, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102404, 18558, NULL, 0, 'H', 9000, 154, 0, 77, 13, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102405, 18558, NULL, 0, 'G', 120000, 137, 0, 35, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102406, 18559, NULL, 0, 'M', 18000, 176, 0, 91, 50, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102407, 18559, NULL, 0, 'G', 160000, 136, 0, 2, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102408, 18560, NULL, 0, 'H', 15000, 104, 0, 82, 24, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102409, 18561, NULL, 0, 'H', 11000, 184, 0, 80, 23, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102410, 18561, NULL, 0, 'D', 7000, 72, 0, 44, 13, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102411, 18561, NULL, 0, 'G', 110000, 119, 0, 49, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102412, 18562, NULL, 0, 'R', 9000, 76, 0, 132, 5, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102413, 18562, NULL, 0, 'A', 0, 82, 0, 88, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102414, 18562, NULL, 0, 'C', 6000, 0, 0, 5, 1, 5, 6, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102415, 18562, NULL, 0, 'A', 0, 77, 0, 16, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102416, 18562, NULL, 0, 'G', 160000, 137, 0, 1, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102417, 18563, NULL, 0, 'D', 12000, 78, 0, 89, 10, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102418, 18563, NULL, 0, 'G', 100000, 85, 0, 10, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102419, 18564, NULL, 0, 'H', 11000, 148, 0, 78, 25, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102420, 18564, NULL, 0, 'A', 0, 73, 0, 11, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102421, 18565, NULL, 0, 'A', 0, 96, 0, 76, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0);
INSERT INTO planets VALUES 
  (102422, 18565, NULL, 0, 'C', 8000, 0, 0, 20, 2, 6, 8, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102423, 18566, NULL, 0, 'D', 10000, 46, 0, 141, 10, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102424, 18566, NULL, 0, 'A', 0, 50, 0, 85, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102425, 18566, NULL, 0, 'R', 10000, 178, 0, 50, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102426, 18566, NULL, 0, 'G', 80000, 85, 0, 45, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102427, 18567, NULL, 0, 'H', 12000, 178, 0, 50, 24, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102428, 18567, NULL, 0, 'G', 150000, 172, 0, 44, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102429, 18567, NULL, 0, 'A', 0, 106, 0, 10, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102430, 18568, NULL, 0, 'H', 15000, 82, 0, 104, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102431, 18568, NULL, 0, 'A', 0, 53, 0, 75, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102432, 18568, NULL, 0, 'G', 150000, 117, 0, 4, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102433, 18568, NULL, 0, 'G', 90000, 117, 0, 21, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102434, 18569, NULL, 0, 'R', 10000, 110, 0, 136, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102435, 18569, NULL, 0, 'D', 10000, 120, 0, 74, 9, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102436, 18569, NULL, 0, 'D', 10000, 148, 0, 11, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102437, 18569, NULL, 0, 'G', 90000, 140, 0, 48, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102438, 18569, NULL, 0, 'C', 7000, 0, 0, 6, 5, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102439, 18570, NULL, 0, 'D', 6000, 104, 0, 75, 9, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102440, 18570, NULL, 0, 'R', 10000, 106, 0, 50, 3, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102441, 18570, NULL, 0, 'G', 100000, 132, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102442, 18571, NULL, 0, 'R', 10000, 72, 0, 139, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102443, 18571, NULL, 0, 'H', 20000, 74, 0, 84, 25, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102444, 18571, NULL, 0, 'D', 11000, 112, 0, 20, 8, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102445, 18571, NULL, 0, 'G', 120000, 113, 0, 33, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102446, 18572, NULL, 0, 'R', 11000, 64, 0, 128, 7, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102447, 18572, NULL, 0, 'M', 13000, 86, 0, 100, 42, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102448, 18572, NULL, 0, 'G', 70000, 90, 0, 11, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102449, 18572, NULL, 0, 'G', 120000, 115, 0, 34, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102450, 18573, NULL, 0, 'R', 10000, 122, 0, 111, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102451, 18573, NULL, 0, 'D', 14000, 126, 0, 88, 12, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102452, 18573, NULL, 0, 'H', 14000, 106, 0, 10, 23, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102453, 18573, NULL, 0, 'G', 80000, 115, 0, 39, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102454, 18573, NULL, 0, 'G', 60000, 113, 0, 8, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102455, 18574, NULL, 0, 'R', 11000, 76, 0, 149, 2, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102456, 18574, NULL, 0, 'G', 110000, 55, 0, 76, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102457, 18574, NULL, 0, 'H', 19000, 82, 0, 70, 13, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102458, 18574, NULL, 0, 'G', 110000, 108, 0, 34, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102459, 18574, NULL, 0, 'G', 140000, 85, 0, 1, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102460, 18574, NULL, 0, 'C', 2000, 0, 0, 27, 1, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102461, 18574, NULL, 0, 'G', 100000, 38, 0, 40, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102462, 18575, NULL, 0, 'H', 16000, 104, 0, 122, 25, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102463, 18575, NULL, 0, 'H', 13000, 100, 0, 93, 24, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102464, 18575, NULL, 0, 'G', 140000, 127, 0, 42, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102465, 18575, NULL, 0, 'G', 160000, 131, 0, 42, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102466, 18575, NULL, 0, 'D', 12000, 114, 0, 5, 6, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102467, 18576, NULL, 0, 'H', 11000, 126, 0, 141, 13, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102468, 18576, NULL, 0, 'H', 10000, 136, 0, 70, 13, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102469, 18576, NULL, 0, 'G', 120000, 118, 0, 28, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102470, 18576, NULL, 0, 'R', 9000, 64, 0, 41, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102471, 18576, NULL, 0, 'G', 90000, 195, 0, 35, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102472, 18577, NULL, 0, 'R', 6000, 114, 0, 100, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102473, 18577, NULL, 0, 'E', 15000, 100, 0, 76, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102474, 18577, NULL, 0, 'H', 13000, 174, 0, 15, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102475, 18577, NULL, 0, 'C', 1000, 0, 0, 39, 7, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102476, 18578, NULL, 0, 'M', 11000, 120, 0, 53, 34, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102477, 18578, NULL, 0, 'G', 120000, 132, 0, 12, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102478, 18578, NULL, 0, 'A', 0, 104, 0, 34, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102479, 18579, NULL, 0, 'A', 0, 62, 0, 108, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102480, 18579, NULL, 0, 'H', 16000, 80, 0, 84, 15, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102481, 18579, NULL, 0, 'E', 15000, 100, 0, 81, 100, 9, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102482, 18579, NULL, 0, 'G', 110000, 105, 0, 38, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102483, 18579, NULL, 0, 'C', 5000, 0, 0, 46, 7, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102484, 18579, NULL, 0, 'G', 150000, 123, 0, 23, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102485, 18580, NULL, 0, 'D', 8000, 72, 0, 119, 8, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102486, 18580, NULL, 0, 'H', 9000, 110, 0, 56, 26, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102487, 18580, NULL, 0, 'D', 13000, 100, 0, 96, 7, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102488, 18580, NULL, 0, 'C', 5000, 0, 0, 16, 0, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102489, 18580, NULL, 0, 'G', 100000, 116, 0, 5, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102490, 18580, NULL, 0, 'D', 16000, 130, 0, 28, 8, 12, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102491, 18581, NULL, 0, 'D', 8000, 48, 0, 139, 8, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102492, 18581, NULL, 0, 'H', 17000, 154, 0, 62, 20, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102493, 18581, NULL, 0, 'D', 4000, 58, 0, 41, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102494, 18581, NULL, 0, 'C', 8000, 0, 0, 24, 7, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102495, 18582, NULL, 0, 'R', 2000, 126, 0, 113, 3, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102496, 18582, NULL, 0, 'M', 16000, 114, 0, 61, 30, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102497, 18582, NULL, 0, 'G', 140000, 96, 0, 35, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102498, 18582, NULL, 0, 'G', 70000, 158, 0, 46, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102499, 18583, NULL, 0, 'D', 15000, 72, 0, 90, 13, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102500, 18584, NULL, 0, 'A', 0, 24, 0, 96, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102501, 18584, NULL, 0, 'H', 14000, 110, 0, 5, 20, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102502, 18584, NULL, 0, 'G', 160000, 141, 0, 42, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102503, 18585, NULL, 0, 'D', 6000, 56, 0, 75, 8, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102504, 18586, NULL, 0, 'A', 0, 45, 0, 136, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102505, 18586, NULL, 0, 'E', 17000, 100, 0, 96, 100, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102506, 18586, NULL, 0, 'G', 80000, 82, 0, 22, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102507, 18586, NULL, 0, 'G', 140000, 140, 0, 9, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102508, 18587, NULL, 0, 'H', 14000, 68, 0, 86, 26, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102509, 18588, NULL, 0, 'R', 4000, 98, 0, 117, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102510, 18588, NULL, 0, 'D', 12000, 106, 0, 68, 7, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102511, 18588, NULL, 0, 'G', 120000, 85, 0, 21, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102512, 18588, NULL, 0, 'G', 90000, 88, 0, 6, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102513, 18588, NULL, 0, 'G', 140000, 111, 0, 32, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102514, 18589, NULL, 0, 'H', 8000, 132, 0, 137, 16, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102515, 18589, NULL, 0, 'H', 13000, 96, 0, 88, 12, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102516, 18589, NULL, 0, 'R', 3000, 58, 0, 6, 6, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102517, 18589, NULL, 0, 'G', 110000, 104, 0, 1, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102518, 18590, NULL, 0, 'H', 15000, 58, 0, 50, 25, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102519, 18590, NULL, 0, 'G', 110000, 12, 0, 26, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102520, 18590, NULL, 0, 'C', 6000, 0, 0, 17, 7, 5, 6, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102521, 18591, NULL, 0, 'R', 4000, 100, 0, 59, 6, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102522, 18592, NULL, 0, 'D', 12000, 76, 0, 97, 11, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102523, 18592, NULL, 0, 'G', 90000, 86, 0, 2, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102524, 18592, NULL, 0, 'A', 0, 66, 0, 39, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102525, 18593, NULL, 0, 'H', 15000, 180, 0, 91, 16, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102526, 18593, NULL, 0, 'A', 0, 70, 0, 30, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102527, 18593, NULL, 0, 'G', 170000, 54, 0, 48, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102528, 18594, NULL, 0, 'R', 10000, 110, 0, 120, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102529, 18594, NULL, 0, 'D', 11000, 110, 0, 68, 8, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102530, 18594, NULL, 0, 'G', 100000, 196, 0, 27, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102531, 18594, NULL, 0, 'G', 100000, 115, 0, 24, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102532, 18594, NULL, 0, 'A', 0, 77, 0, 33, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102533, 18595, NULL, 0, 'R', 11000, 92, 0, 120, 0, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102534, 18595, NULL, 0, 'R', 8000, 146, 0, 75, 0, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102535, 18595, NULL, 0, 'G', 40000, 31, 0, 20, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102536, 18595, NULL, 0, 'G', 140000, 165, 0, 19, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102537, 18596, NULL, 0, 'M', 9000, 40, 0, 51, 36, 5, 9, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102538, 18596, NULL, 0, 'C', 6000, 0, 0, 4, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102539, 18596, NULL, 0, 'G', 80000, 102, 0, 23, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102540, 18597, NULL, 0, 'H', 13000, 168, 0, 81, 22, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102541, 18598, NULL, 0, 'H', 14000, 80, 0, 62, 20, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102542, 18598, NULL, 0, 'G', 70000, 151, 0, 31, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102543, 18598, NULL, 0, 'G', 150000, 60, 0, 27, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102544, 18599, NULL, 0, 'G', 90000, 149, 0, 145, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102545, 18599, NULL, 0, 'H', 12000, 86, 0, 74, 20, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102546, 18599, NULL, 0, 'G', 100000, 188, 0, 29, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102547, 18599, NULL, 0, 'G', 130000, 130, 0, 37, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102548, 18600, NULL, 0, 'A', 0, 52, 0, 76, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102549, 18600, NULL, 0, 'H', 15000, 178, 0, 19, 13, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102550, 18601, NULL, 0, 'H', 13000, 74, 0, 62, 14, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102551, 18601, NULL, 0, 'G', 120000, 197, 0, 21, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102552, 18601, NULL, 0, 'H', 12000, 106, 0, 26, 26, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102553, 18602, NULL, 0, 'R', 5000, 84, 0, 121, 0, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102554, 18602, NULL, 0, 'H', 9000, 74, 0, 84, 22, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102555, 18602, NULL, 0, 'E', 17000, 100, 0, 72, 100, 9, 17, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102556, 18602, NULL, 0, 'G', 140000, 59, 0, 47, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102557, 18602, NULL, 0, 'A', 0, 76, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102558, 18602, NULL, 0, 'G', 120000, 114, 0, 5, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102559, 18603, NULL, 0, 'H', 10000, 86, 0, 144, 20, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102560, 18603, NULL, 0, 'H', 12000, 94, 0, 65, 15, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102561, 18603, NULL, 0, 'G', 160000, 116, 0, 35, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102562, 18603, NULL, 0, 'C', 6000, 0, 0, 39, 7, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102563, 18603, NULL, 0, 'G', 100000, 106, 0, 31, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102564, 18604, NULL, 0, 'A', 0, 57, 0, 144, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102565, 18604, NULL, 0, 'H', 13000, 112, 0, 77, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102566, 18604, NULL, 0, 'D', 12000, 80, 0, 55, 8, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102567, 18604, NULL, 0, 'G', 100000, 119, 0, 20, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102568, 18604, NULL, 0, 'G', 160000, 93, 0, 29, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102569, 18604, NULL, 0, 'G', 90000, 93, 0, 28, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102570, 18605, NULL, 0, 'D', 9000, 118, 0, 60, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102571, 18605, NULL, 0, 'D', 10000, 128, 0, 22, 12, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102572, 18606, NULL, 0, 'D', 14000, 70, 0, 69, 6, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102573, 18606, NULL, 0, 'C', 2000, 0, 0, 17, 7, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102574, 18607, NULL, 0, 'D', 13000, 124, 0, 98, 13, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102575, 18607, NULL, 0, 'D', 4000, 130, 0, 25, 11, 3, 4, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102576, 18608, NULL, 0, 'R', 3000, 136, 0, 110, 5, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102577, 18608, NULL, 0, 'M', 11000, 116, 0, 67, 42, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102578, 18608, NULL, 0, 'G', 80000, 108, 0, 17, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102579, 18608, NULL, 0, 'A', 0, 36, 0, 21, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102580, 18609, NULL, 0, 'H', 11000, 62, 0, 130, 19, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102581, 18609, NULL, 0, 'H', 18000, 168, 0, 57, 17, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102582, 18609, NULL, 0, 'G', 70000, 144, 0, 18, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102583, 18609, NULL, 0, 'G', 150000, 120, 0, 29, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102584, 18610, NULL, 0, 'R', 5000, 98, 0, 127, 1, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102585, 18610, NULL, 0, 'H', 18000, 72, 0, 100, 14, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102586, 18610, NULL, 0, 'D', 14000, 174, 0, 56, 13, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102587, 18610, NULL, 0, 'C', 8000, 0, 0, 43, 4, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102588, 18610, NULL, 0, 'A', 0, 109, 0, 31, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102589, 18610, NULL, 0, 'G', 130000, 124, 0, 20, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102590, 18610, NULL, 0, 'G', 50000, 61, 0, 5, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102591, 18611, NULL, 0, 'R', 9000, 158, 0, 63, 0, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102592, 18612, NULL, 0, 'E', 16000, 100, 0, 92, 100, 9, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102593, 18612, NULL, 0, 'D', 9000, 144, 0, 44, 10, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102594, 18612, NULL, 0, 'G', 110000, 88, 0, 24, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102595, 18613, NULL, 0, 'R', 4000, 0, 0, 134, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102596, 18613, NULL, 0, 'M', 13000, 82, 0, 60, 43, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102597, 18613, NULL, 0, 'G', 100000, 20, 0, 24, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102598, 18613, NULL, 0, 'H', 16000, 108, 0, 7, 16, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102599, 18613, NULL, 0, 'G', 70000, 126, 0, 25, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102600, 18614, NULL, 0, 'M', 10000, 40, 0, 59, 44, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102601, 18614, NULL, 0, 'A', 0, 94, 0, 9, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102602, 18614, NULL, 0, 'G', 110000, 160, 0, 39, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102603, 18615, NULL, 0, 'H', 11000, 126, 0, 121, 14, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102604, 18615, NULL, 0, 'M', 16000, 92, 0, 64, 46, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102605, 18615, NULL, 0, 'M', 15000, 94, 0, 62, 27, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102606, 18615, NULL, 0, 'H', 10000, 122, 0, 36, 26, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102607, 18615, NULL, 0, 'G', 170000, 120, 0, 17, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102608, 18615, NULL, 0, 'A', 0, 48, 0, 37, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102609, 18616, NULL, 0, 'R', 9000, 98, 0, 140, 1, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102610, 18616, NULL, 0, 'H', 7000, 24, 0, 84, 13, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102611, 18616, NULL, 0, 'G', 150000, 93, 0, 3, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102612, 18616, NULL, 0, 'G', 50000, 93, 0, 22, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102613, 18617, NULL, 0, 'H', 17000, 90, 0, 147, 19, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102614, 18617, NULL, 0, 'M', 13000, 154, 0, 63, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102615, 18617, NULL, 0, 'G', 90000, 89, 0, 48, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102616, 18617, NULL, 0, 'A', 0, 84, 0, 22, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102617, 18618, NULL, 0, 'H', 20000, 102, 0, 148, 12, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102618, 18618, NULL, 0, 'M', 13000, 116, 0, 62, 50, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102619, 18618, NULL, 0, 'G', 40000, 112, 0, 0, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102620, 18618, NULL, 0, 'G', 90000, 41, 0, 7, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102621, 18618, NULL, 0, 'A', 0, 126, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102622, 18619, NULL, 0, 'H', 20000, 128, 0, 55, 18, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102623, 18619, NULL, 0, 'C', 3000, 0, 0, 9, 0, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102624, 18620, NULL, 0, 'A', 0, 128, 0, 125, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102625, 18620, NULL, 0, 'D', 8000, 34, 0, 62, 12, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102626, 18620, NULL, 0, 'G', 90000, 53, 0, 9, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102627, 18620, NULL, 0, 'G', 160000, 63, 0, 40, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102628, 18620, NULL, 0, 'A', 0, 41, 0, 17, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102629, 18621, NULL, 0, 'H', 15000, 150, 0, 82, 15, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102630, 18621, NULL, 0, 'G', 110000, 168, 0, 0, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102631, 18621, NULL, 0, 'A', 0, 26, 0, 44, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102632, 18622, NULL, 0, 'H', 8000, 88, 0, 55, 16, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102633, 18622, NULL, 0, 'R', 2000, 76, 0, 39, 2, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102634, 18623, NULL, 0, 'H', 13000, 174, 0, 122, 19, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102635, 18623, NULL, 0, 'A', 0, 143, 0, 57, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102636, 18623, NULL, 0, 'A', 0, 44, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102637, 18623, NULL, 0, 'C', 10000, 0, 0, 49, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102638, 18624, NULL, 0, 'H', 7000, 124, 0, 65, 21, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102639, 18625, NULL, 0, 'H', 18000, 82, 0, 119, 14, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102640, 18625, NULL, 0, 'A', 0, 117, 0, 54, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102641, 18625, NULL, 0, 'M', 18000, 140, 0, 71, 34, 9, 18, 0, NULL, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102642, 18625, NULL, 0, 'C', 3000, 0, 0, 15, 7, 2, 3, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102643, 18625, NULL, 0, 'A', 0, 101, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102644, 18625, NULL, 0, 'A', 0, 119, 0, 40, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102645, 18626, NULL, 0, 'H', 15000, 118, 0, 126, 14, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102646, 18626, NULL, 0, 'D', 14000, 94, 0, 72, 11, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102647, 18626, NULL, 0, 'A', 0, 66, 0, 89, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102648, 18626, NULL, 0, 'G', 90000, 78, 0, 33, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102649, 18626, NULL, 0, 'G', 110000, 113, 0, 46, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102650, 18626, NULL, 0, 'G', 150000, 134, 0, 13, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102651, 18627, NULL, 0, 'R', 6000, 126, 0, 109, 0, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102652, 18627, NULL, 0, 'D', 12000, 112, 0, 86, 11, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102653, 18627, NULL, 0, 'H', 11000, 52, 0, 56, 19, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102654, 18627, NULL, 0, 'A', 0, 59, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102655, 18627, NULL, 0, 'G', 140000, 64, 0, 29, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102656, 18627, NULL, 0, 'G', 160000, 60, 0, 36, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102657, 18627, NULL, 0, 'G', 170000, 106, 0, 33, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102658, 18628, NULL, 0, 'H', 14000, 110, 0, 108, 22, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102659, 18628, NULL, 0, 'D', 10000, 118, 0, 81, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102660, 18628, NULL, 0, 'H', 12000, 90, 0, 86, 22, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102661, 18628, NULL, 0, 'G', 120000, 127, 0, 4, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102662, 18628, NULL, 0, 'G', 90000, 91, 0, 32, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102663, 18628, NULL, 0, 'G', 120000, 119, 0, 45, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102664, 18629, NULL, 0, 'R', 9000, 100, 0, 138, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102665, 18629, NULL, 0, 'D', 12000, 74, 0, 97, 9, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102666, 18629, NULL, 0, 'G', 80000, 187, 0, 14, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102667, 18629, NULL, 0, 'C', 2000, 0, 0, 9, 4, 2, 2, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102668, 18630, NULL, 0, 'R', 6000, 104, 0, 112, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102669, 18630, NULL, 0, 'R', 7000, 74, 0, 70, 0, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102670, 18630, NULL, 0, 'G', 110000, 147, 0, 49, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102671, 18630, NULL, 0, 'G', 100000, 155, 0, 14, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102672, 18631, NULL, 0, 'D', 7000, 140, 0, 114, 11, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102673, 18631, NULL, 0, 'D', 8000, 132, 0, 81, 7, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102674, 18631, NULL, 0, 'H', 12000, 92, 0, 53, 16, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102675, 18631, NULL, 0, 'G', 100000, 135, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102676, 18631, NULL, 0, 'G', 130000, 48, 0, 21, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102677, 18631, NULL, 0, 'A', 0, 105, 0, 33, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102678, 18632, NULL, 0, 'H', 18000, 104, 0, 141, 22, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102679, 18632, NULL, 0, 'D', 11000, 104, 0, 62, 6, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102680, 18632, NULL, 0, 'G', 120000, 113, 0, 29, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102681, 18632, NULL, 0, 'A', 0, 44, 0, 35, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102682, 18633, NULL, 0, 'H', 10000, 122, 0, 135, 13, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102683, 18633, NULL, 0, 'H', 11000, 108, 0, 98, 21, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102684, 18633, NULL, 0, 'A', 0, 37, 0, 7, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102685, 18633, NULL, 0, 'C', 5000, 0, 0, 12, 6, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102686, 18634, NULL, 0, 'G', 140000, 90, 0, 133, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102687, 18634, NULL, 0, 'H', 8000, 106, 0, 72, 21, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102688, 18634, NULL, 0, 'G', 140000, 107, 0, 11, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102689, 18634, NULL, 0, 'H', 7000, 72, 0, 30, 25, 4, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102690, 18635, NULL, 0, 'R', 6000, 98, 0, 104, 5, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102691, 18635, NULL, 0, 'D', 14000, 38, 0, 59, 8, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102692, 18635, NULL, 0, 'C', 10000, 0, 0, 50, 6, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102693, 18635, NULL, 0, 'G', 140000, 133, 0, 42, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102694, 18635, NULL, 0, 'G', 110000, 130, 0, 5, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102695, 18636, NULL, 0, 'H', 10000, 154, 0, 80, 13, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102696, 18636, NULL, 0, 'H', 13000, 148, 0, 9, 23, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102697, 18636, NULL, 0, 'C', 11000, 0, 0, 25, 1, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102698, 18637, NULL, 0, 'D', 7000, 54, 0, 67, 7, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102699, 18637, NULL, 0, 'A', 0, 104, 0, 10, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102700, 18638, NULL, 0, 'D', 6000, 20, 0, 84, 7, 5, 6, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102701, 18638, NULL, 0, 'G', 160000, 114, 0, 36, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102702, 18639, NULL, 0, 'R', 6000, 86, 0, 145, 0, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102703, 18639, NULL, 0, 'D', 10000, 58, 0, 95, 11, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102704, 18639, NULL, 0, 'G', 120000, 173, 0, 10, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102705, 18639, NULL, 0, 'G', 140000, 36, 0, 10, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102706, 18640, NULL, 0, 'R', 6000, 132, 0, 129, 2, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102707, 18640, NULL, 0, 'H', 13000, 44, 0, 63, 15, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102708, 18640, NULL, 0, 'G', 120000, 124, 0, 47, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102709, 18640, NULL, 0, 'A', 0, 87, 0, 35, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102710, 18641, NULL, 0, 'G', 150000, 145, 0, 118, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102711, 18641, NULL, 0, 'R', 7000, 66, 0, 107, 5, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102712, 18641, NULL, 0, 'E', 17000, 100, 0, 86, 100, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102713, 18641, NULL, 0, 'D', 11000, 48, 0, 68, 13, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102714, 18641, NULL, 0, 'G', 140000, 63, 0, 35, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102715, 18641, NULL, 0, 'A', 0, 165, 0, 14, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102716, 18641, NULL, 0, 'G', 50000, 163, 0, 14, 0, 0, 50, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102717, 18641, NULL, 0, 'G', 100000, 131, 0, 29, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102718, 18642, NULL, 0, 'H', 12000, 76, 0, 51, 17, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102719, 18642, NULL, 0, 'G', 90000, 117, 0, 22, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102720, 18642, NULL, 0, 'D', 15000, 164, 0, 2, 9, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102721, 18643, NULL, 0, 'E', 14000, 100, 0, 92, 100, 9, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102722, 18643, NULL, 0, 'G', 180000, 79, 0, 23, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102723, 18643, NULL, 0, 'G', 130000, 125, 0, 28, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102724, 18644, NULL, 0, 'H', 14000, 94, 0, 115, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102725, 18644, NULL, 0, 'A', 0, 132, 0, 63, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102726, 18644, NULL, 0, 'C', 11000, 0, 0, 12, 4, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102727, 18644, NULL, 0, 'D', 16000, 116, 0, 6, 8, 12, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102728, 18644, NULL, 0, 'G', 140000, 53, 0, 26, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102729, 18645, NULL, 0, 'R', 8000, 86, 0, 134, 3, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102730, 18645, NULL, 0, 'D', 6000, 64, 0, 58, 13, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102731, 18645, NULL, 0, 'H', 12000, 130, 0, 39, 20, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102732, 18645, NULL, 0, 'G', 110000, 69, 0, 26, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102733, 18645, NULL, 0, 'A', 0, 126, 0, 3, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102734, 18646, NULL, 0, 'R', 9000, 88, 0, 134, 4, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102735, 18646, NULL, 0, 'R', 4000, 0, 0, 64, 7, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102736, 18646, NULL, 0, 'D', 9000, 108, 0, 83, 11, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102737, 18646, NULL, 0, 'R', 6000, 64, 0, 34, 4, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102738, 18646, NULL, 0, 'G', 120000, 150, 0, 15, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102739, 18646, NULL, 0, 'G', 40000, 117, 0, 50, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102740, 18647, NULL, 0, 'R', 1000, 84, 0, 149, 0, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102741, 18647, NULL, 0, 'H', 10000, 96, 0, 70, 25, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102742, 18647, NULL, 0, 'M', 9000, 114, 0, 58, 28, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102743, 18647, NULL, 0, 'G', 150000, 117, 0, 5, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102744, 18647, NULL, 0, 'H', 15000, 78, 0, 43, 26, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102745, 18647, NULL, 0, 'G', 160000, 89, 0, 23, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102746, 18647, NULL, 0, 'G', 160000, 190, 0, 43, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102747, 18648, NULL, 0, 'R', 8000, 134, 0, 138, 5, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102748, 18648, NULL, 0, 'A', 0, 92, 0, 51, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102749, 18648, NULL, 0, 'G', 130000, 107, 0, 49, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102750, 18648, NULL, 0, 'G', 90000, 68, 0, 16, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102751, 18649, NULL, 0, 'A', 0, 61, 0, 59, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102752, 18649, NULL, 0, 'H', 12000, 70, 0, 35, 12, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102753, 18649, NULL, 0, 'G', 140000, 106, 0, 49, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102754, 18650, NULL, 0, 'H', 18000, 170, 0, 137, 15, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102755, 18650, NULL, 0, 'M', 12000, 158, 0, 68, 51, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102756, 18650, NULL, 0, 'G', 160000, 94, 0, 14, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102757, 18650, NULL, 0, 'C', 11000, 0, 0, 35, 6, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102758, 18651, NULL, 0, 'H', 14000, 72, 0, 85, 18, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102759, 18651, NULL, 0, 'R', 11000, 74, 0, 18, 1, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102760, 18651, NULL, 0, 'G', 80000, 111, 0, 8, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102761, 18652, NULL, 0, 'R', 4000, 130, 0, 112, 3, 3, 4, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102762, 18652, NULL, 0, 'H', 12000, 44, 0, 87, 24, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102763, 18652, NULL, 0, 'A', 0, 70, 0, 37, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102764, 18652, NULL, 0, 'C', 5000, 0, 0, 5, 6, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102765, 18652, NULL, 0, 'G', 100000, 102, 0, 2, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102766, 18653, NULL, 0, 'D', 11000, 152, 0, 50, 9, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102767, 18653, NULL, 0, 'G', 100000, 102, 0, 35, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102768, 18654, NULL, 0, 'D', 10000, 152, 0, 61, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102769, 18654, NULL, 0, 'G', 80000, 199, 0, 24, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102770, 18654, NULL, 0, 'G', 150000, 144, 0, 37, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102771, 18655, NULL, 0, 'R', 5000, 104, 0, 110, 4, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102772, 18655, NULL, 0, 'H', 16000, 74, 0, 100, 14, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102773, 18655, NULL, 0, 'A', 0, 69, 0, 47, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102774, 18655, NULL, 0, 'G', 120000, 130, 0, 17, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102775, 18655, NULL, 0, 'G', 170000, 155, 0, 33, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102776, 18656, NULL, 0, 'H', 5000, 22, 0, 92, 15, 3, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102777, 18656, NULL, 0, 'G', 120000, 86, 0, 24, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102778, 18657, NULL, 0, 'D', 7000, 94, 0, 57, 9, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102779, 18657, NULL, 0, 'G', 100000, 124, 0, 32, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102780, 18658, NULL, 0, 'H', 14000, 152, 0, 116, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102781, 18658, NULL, 0, 'G', 40000, 109, 0, 51, 0, 0, 40, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102782, 18658, NULL, 0, 'A', 0, 20, 0, 89, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102783, 18658, NULL, 0, 'G', 120000, 133, 0, 18, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102784, 18658, NULL, 0, 'G', 110000, 153, 0, 41, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102785, 18658, NULL, 0, 'G', 130000, 36, 0, 6, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102786, 18659, NULL, 0, 'H', 12000, 142, 0, 90, 23, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102787, 18659, NULL, 0, 'G', 160000, 96, 0, 16, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102788, 18659, NULL, 0, 'C', 5000, 0, 0, 21, 2, 4, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102789, 18660, NULL, 0, 'H', 11000, 72, 0, 86, 24, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102790, 18660, NULL, 0, 'G', 90000, 55, 0, 9, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102791, 18660, NULL, 0, 'G', 130000, 77, 0, 19, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102792, 18661, NULL, 0, 'H', 19000, 124, 0, 129, 24, 10, 19, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102793, 18661, NULL, 0, 'H', 12000, 132, 0, 76, 13, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102794, 18661, NULL, 0, 'A', 0, 61, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102795, 18661, NULL, 0, 'C', 7000, 0, 0, 38, 6, 5, 7, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102796, 18661, NULL, 0, 'R', 9000, 80, 0, 12, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102797, 18662, NULL, 0, 'D', 11000, 112, 0, 55, 13, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102798, 18663, NULL, 0, 'H', 9000, 108, 0, 72, 15, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102799, 18663, NULL, 0, 'G', 130000, 89, 0, 35, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102800, 18663, NULL, 0, 'G', 80000, 91, 0, 10, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102801, 18664, NULL, 0, 'D', 14000, 132, 0, 91, 11, 11, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102802, 18664, NULL, 0, 'A', 0, 70, 0, 35, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102803, 18665, NULL, 0, 'D', 10000, 58, 0, 113, 12, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102804, 18665, NULL, 0, 'R', 10000, 144, 0, 95, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102805, 18665, NULL, 0, 'C', 8000, 0, 0, 26, 6, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102806, 18665, NULL, 0, 'G', 70000, 127, 0, 17, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102807, 18666, NULL, 0, 'R', 1000, 106, 0, 104, 1, 1, 1, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102808, 18666, NULL, 0, 'D', 10000, 98, 0, 66, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102809, 18666, NULL, 0, 'G', 110000, 79, 0, 25, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102810, 18666, NULL, 0, 'G', 90000, 136, 0, 4, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102811, 18667, NULL, 0, 'H', 17000, 124, 0, 63, 13, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102812, 18668, NULL, 0, 'G', 170000, 101, 0, 103, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102813, 18668, NULL, 0, 'E', 17000, 100, 0, 84, 100, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102814, 18668, NULL, 0, 'A', 0, 95, 0, 11, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102815, 18668, NULL, 0, 'G', 120000, 104, 0, 44, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102816, 18669, NULL, 0, 'H', 9000, 128, 0, 70, 26, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102817, 18669, NULL, 0, 'G', 80000, 134, 0, 23, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102818, 18670, NULL, 0, 'H', 5000, 156, 0, 148, 17, 3, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102819, 18670, NULL, 0, 'A', 0, 58, 0, 61, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102820, 18670, NULL, 0, 'G', 100000, 131, 0, 46, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102821, 18670, NULL, 0, 'G', 130000, 116, 0, 16, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102822, 18671, NULL, 0, 'R', 6000, 148, 0, 149, 6, 5, 6, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102823, 18671, NULL, 0, 'H', 12000, 92, 0, 77, 14, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102824, 18671, NULL, 0, 'C', 4000, 0, 0, 9, 4, 3, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102825, 18671, NULL, 0, 'G', 200000, 111, 0, 17, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102826, 18671, NULL, 0, 'A', 0, 79, 0, 1, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102827, 18672, NULL, 0, 'H', 18000, 174, 0, 143, 22, 9, 18, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102828, 18672, NULL, 0, 'E', 17000, 100, 0, 60, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102829, 18672, NULL, 0, 'G', 140000, 182, 0, 19, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102830, 18672, NULL, 0, 'D', 11000, 148, 0, 12, 8, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102831, 18672, NULL, 0, 'G', 110000, 151, 0, 40, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102832, 18673, NULL, 0, 'H', 14000, 40, 0, 115, 18, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102833, 18673, NULL, 0, 'E', 16000, 100, 0, 83, 100, 9, 16, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102834, 18673, NULL, 0, 'A', 0, 99, 0, 12, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102835, 18673, NULL, 0, 'D', 8000, 122, 0, 11, 13, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102836, 18674, NULL, 0, 'H', 13000, 114, 0, 141, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102837, 18674, NULL, 0, 'E', 16000, 100, 0, 81, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102838, 18674, NULL, 0, 'A', 0, 118, 0, 32, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102839, 18674, NULL, 0, 'G', 100000, 161, 0, 26, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102840, 18674, NULL, 0, 'R', 9000, 100, 0, 8, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102841, 18675, NULL, 0, 'H', 8000, 108, 0, 145, 20, 4, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102842, 18675, NULL, 0, 'R', 11000, 112, 0, 140, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102843, 18675, NULL, 0, 'A', 0, 116, 0, 88, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102844, 18675, 42, 0, 'E', 15000, 100, 0, 53, 100, 9, 15, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102845, 18675, NULL, 0, 'A', 0, 97, 0, 36, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102846, 18675, NULL, 0, 'G', 170000, 181, 0, 38, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102847, 18675, NULL, 0, 'G', 140000, 155, 0, 40, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102848, 18675, NULL, 0, 'G', 110000, 37, 0, 28, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102849, 18676, NULL, 0, 'H', 10000, 156, 0, 115, 22, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102850, 18676, NULL, 0, 'E', 17000, 100, 0, 76, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102851, 18676, NULL, 0, 'D', 11000, 54, 0, 95, 11, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102852, 18676, NULL, 0, 'G', 150000, 153, 0, 6, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102853, 18676, NULL, 0, 'G', 120000, 123, 0, 39, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102854, 18676, NULL, 0, 'G', 110000, 103, 0, 2, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102855, 18676, NULL, 0, 'G', 140000, 116, 0, 14, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102856, 18677, NULL, 0, 'H', 13000, 118, 0, 100, 12, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102857, 18677, NULL, 0, 'E', 15000, 100, 0, 79, 100, 9, 15, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102858, 18677, NULL, 0, 'G', 100000, 142, 0, 8, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102859, 18677, NULL, 0, 'C', 9000, 0, 0, 2, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102860, 18678, NULL, 0, 'H', 15000, 142, 0, 120, 24, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102861, 18678, NULL, 0, 'E', 18000, 100, 0, 56, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102862, 18678, NULL, 0, 'G', 100000, 103, 0, 29, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102863, 18678, NULL, 0, 'C', 9000, 0, 0, 17, 5, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102864, 18679, NULL, 0, 'H', 11000, 144, 0, 126, 12, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102865, 18679, NULL, 0, 'E', 18000, 100, 0, 96, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102866, 18679, NULL, 0, 'R', 11000, 70, 0, 5, 0, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102867, 18679, NULL, 0, 'G', 170000, 75, 0, 37, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102868, 18680, NULL, 0, 'R', 10000, 128, 0, 129, 0, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102869, 18680, NULL, 0, 'E', 18000, 100, 0, 79, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102870, 18680, NULL, 0, 'H', 9000, 118, 0, 64, 15, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102871, 18680, NULL, 0, 'G', 130000, 143, 0, 7, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102872, 18680, NULL, 0, 'G', 150000, 73, 0, 27, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102873, 18680, NULL, 0, 'G', 100000, 99, 0, 41, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102874, 18681, NULL, 0, 'H', 13000, 114, 0, 100, 20, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102875, 18681, NULL, 0, 'A', 0, 30, 0, 148, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102876, 18681, NULL, 0, 'E', 17000, 100, 0, 93, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102877, 18681, NULL, 0, 'A', 0, 127, 0, 100, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102878, 18681, NULL, 0, 'G', 160000, 67, 0, 17, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102879, 18681, NULL, 0, 'G', 130000, 55, 0, 13, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102880, 18681, NULL, 0, 'R', 10000, 132, 0, 49, 4, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102881, 18681, NULL, 0, 'A', 0, 140, 0, 30, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102882, 18682, NULL, 0, 'D', 11000, 118, 0, 101, 11, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102883, 18682, NULL, 0, 'E', 16000, 100, 0, 56, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102884, 18682, NULL, 0, 'H', 13000, 162, 0, 84, 22, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102885, 18682, NULL, 0, 'G', 90000, 125, 0, 35, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102886, 18682, NULL, 0, 'A', 0, 63, 0, 24, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102887, 18682, NULL, 0, 'G', 160000, 112, 0, 7, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102888, 18683, NULL, 0, 'G', 160000, 163, 0, 105, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102889, 18683, NULL, 0, 'R', 9000, 50, 0, 136, 6, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102890, 18683, NULL, 0, 'H', 4000, 34, 0, 95, 22, 2, 4, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102891, 18683, NULL, 0, 'E', 18000, 100, 0, 99, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102892, 18683, NULL, 0, 'G', 130000, 133, 0, 20, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102893, 18683, NULL, 0, 'G', 110000, 63, 0, 44, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102894, 18683, NULL, 0, 'G', 110000, 68, 0, 16, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102895, 18683, NULL, 0, 'A', 0, 113, 0, 19, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102896, 18683, NULL, 0, 'G', 100000, 144, 0, 0, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102897, 18684, NULL, 0, 'H', 15000, 188, 0, 105, 24, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102898, 18684, NULL, 0, 'E', 15000, 100, 0, 84, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102899, 18684, NULL, 0, 'G', 200000, 74, 0, 26, 0, 0, 201, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102900, 18684, NULL, 0, 'C', 8000, 0, 0, 25, 3, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102901, 18685, NULL, 0, 'H', 13000, 118, 0, 129, 21, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102902, 18685, NULL, 0, 'E', 14000, 100, 0, 77, 100, 9, 14, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102903, 18685, NULL, 0, 'A', 0, 55, 0, 39, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102904, 18685, NULL, 0, 'D', 15000, 170, 0, 39, 13, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102905, 18686, NULL, 0, 'H', 15000, 156, 0, 119, 12, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102906, 18686, NULL, 0, 'A', 0, 109, 0, 69, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102907, 18686, NULL, 0, 'E', 16000, 100, 0, 82, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102908, 18686, NULL, 0, 'A', 0, 140, 0, 19, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102909, 18686, NULL, 0, 'A', 0, 45, 0, 26, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102910, 18686, NULL, 0, 'R', 10000, 70, 0, 9, 3, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102911, 18687, NULL, 0, 'G', 120000, 164, 0, 118, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102912, 18687, NULL, 0, 'D', 13000, 128, 0, 95, 9, 10, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102913, 18687, NULL, 0, 'E', 16000, 100, 0, 87, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102914, 18687, NULL, 0, 'G', 120000, 97, 0, 44, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102915, 18687, NULL, 0, 'H', 13000, 190, 0, 27, 18, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102916, 18687, NULL, 0, 'G', 150000, 125, 0, 16, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102917, 18688, NULL, 0, 'R', 8000, 94, 0, 138, 1, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102918, 18688, NULL, 0, 'E', 14000, 100, 0, 97, 100, 9, 14, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102919, 18688, NULL, 0, 'G', 90000, 40, 0, 21, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102920, 18688, NULL, 0, 'H', 15000, 178, 0, 34, 21, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102921, 18689, NULL, 0, 'H', 17000, 114, 0, 105, 15, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102922, 18689, NULL, 0, 'E', 17000, 100, 0, 83, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102923, 18689, NULL, 0, 'A', 0, 40, 0, 8, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102924, 18689, NULL, 0, 'D', 11000, 102, 0, 20, 12, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102925, 18689, NULL, 0, 'A', 0, 56, 0, 24, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102926, 18690, NULL, 0, 'H', 13000, 176, 0, 150, 20, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102927, 18690, NULL, 0, 'E', 16000, 100, 0, 100, 100, 9, 16, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102928, 18690, NULL, 0, 'G', 80000, 141, 0, 99, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102929, 18690, NULL, 0, 'G', 150000, 61, 0, 41, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102930, 18690, NULL, 0, 'G', 30000, 151, 0, 47, 0, 0, 30, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102931, 18690, NULL, 0, 'R', 11000, 52, 0, 38, 3, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102932, 18691, NULL, 0, 'H', 11000, 50, 0, 143, 15, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102933, 18691, NULL, 0, 'D', 12000, 176, 0, 51, 12, 9, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102934, 18691, NULL, 0, 'E', 15000, 100, 0, 87, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102935, 18691, NULL, 0, 'A', 0, 44, 0, 49, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102936, 18691, NULL, 0, 'G', 130000, 123, 0, 10, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102937, 18691, NULL, 0, 'G', 110000, 50, 0, 9, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102938, 18692, NULL, 0, 'H', 12000, 162, 0, 149, 13, 6, 12, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102939, 18692, NULL, 0, 'E', 17000, 100, 0, 63, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102940, 18692, NULL, 0, 'D', 8000, 108, 0, 86, 7, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102941, 18692, NULL, 0, 'A', 0, 97, 0, 44, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102942, 18692, NULL, 0, 'G', 160000, 128, 0, 33, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102943, 18692, NULL, 0, 'G', 80000, 96, 0, 46, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102944, 18693, NULL, 0, 'R', 8000, 124, 0, 145, 6, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102945, 18693, NULL, 0, 'H', 14000, 134, 0, 74, 16, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102946, 18693, NULL, 0, 'E', 18000, 100, 0, 87, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102947, 18693, NULL, 0, 'G', 190000, 22, 0, 38, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102948, 18693, NULL, 0, 'G', 120000, 145, 0, 15, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102949, 18693, NULL, 0, 'G', 90000, 144, 0, 47, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102950, 18694, NULL, 0, 'H', 13000, 84, 0, 148, 26, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102951, 18694, NULL, 0, 'E', 16000, 100, 0, 80, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102952, 18694, NULL, 0, 'D', 11000, 164, 0, 19, 12, 8, 11, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102953, 18694, NULL, 0, 'G', 100000, 157, 0, 36, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102954, 18694, NULL, 0, 'G', 140000, 76, 0, 21, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102955, 18695, NULL, 0, 'H', 15000, 60, 0, 150, 13, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102956, 18695, NULL, 0, 'E', 14000, 100, 0, 55, 100, 9, 14, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102957, 18695, NULL, 0, 'D', 15000, 144, 0, 7, 11, 11, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102958, 18695, NULL, 0, 'G', 120000, 198, 0, 32, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102959, 18696, NULL, 0, 'R', 8000, 98, 0, 130, 4, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102960, 18696, NULL, 0, 'E', 15000, 100, 0, 87, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102961, 18696, NULL, 0, 'H', 16000, 164, 0, 34, 14, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102962, 18696, NULL, 0, 'G', 110000, 141, 0, 15, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102963, 18697, NULL, 0, 'D', 9000, 72, 0, 136, 12, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102964, 18697, NULL, 0, 'E', 16000, 100, 0, 68, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102965, 18697, NULL, 0, 'H', 9000, 64, 0, 98, 12, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102966, 18697, NULL, 0, 'G', 100000, 187, 0, 37, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102967, 18697, NULL, 0, 'G', 70000, 86, 0, 28, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102968, 18697, NULL, 0, 'A', 0, 73, 0, 29, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102969, 18698, NULL, 0, 'H', 16000, 162, 0, 103, 13, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102970, 18698, NULL, 0, 'E', 15000, 100, 0, 57, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102971, 18698, NULL, 0, 'R', 11000, 108, 0, 95, 5, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102972, 18698, NULL, 0, 'G', 150000, 37, 0, 19, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102973, 18698, NULL, 0, 'G', 90000, 42, 0, 38, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102974, 18698, NULL, 0, 'G', 160000, 161, 0, 6, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102975, 18698, NULL, 0, 'G', 110000, 150, 0, 11, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102976, 18699, NULL, 0, 'R', 8000, 14, 0, 131, 5, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102977, 18699, NULL, 0, 'E', 15000, 100, 0, 50, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102978, 18699, NULL, 0, 'A', 0, 68, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102979, 18699, NULL, 0, 'H', 11000, 116, 0, 34, 20, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102980, 18699, NULL, 0, 'G', 130000, 174, 0, 40, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102981, 18700, NULL, 0, 'H', 17000, 90, 0, 119, 21, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102982, 18700, NULL, 0, 'E', 17000, 100, 0, 95, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102983, 18700, NULL, 0, 'G', 150000, 146, 0, 23, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102984, 18700, NULL, 0, 'R', 10000, 140, 0, 0, 7, 8, 10, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102985, 18701, NULL, 0, 'H', 5000, 78, 0, 116, 17, 3, 5, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102986, 18701, NULL, 0, 'E', 18000, 100, 0, 71, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102987, 18701, NULL, 0, 'R', 8000, 144, 0, 79, 4, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102988, 18701, NULL, 0, 'G', 60000, 116, 0, 30, 0, 0, 60, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102989, 18701, NULL, 0, 'G', 100000, 148, 0, 2, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102990, 18701, NULL, 0, 'G', 130000, 118, 0, 31, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102991, 18702, NULL, 0, 'R', 10000, 124, 0, 135, 4, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102992, 18702, NULL, 0, 'H', 16000, 162, 0, 63, 23, 8, 16, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102993, 18702, NULL, 0, 'E', 16000, 100, 0, 97, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102994, 18702, NULL, 0, 'G', 120000, 85, 0, 48, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102995, 18702, NULL, 0, 'G', 160000, 96, 0, 12, 0, 0, 161, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102996, 18702, NULL, 0, 'A', 0, 66, 0, 28, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102997, 18703, NULL, 0, 'H', 9000, 56, 0, 129, 25, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102998, 18703, NULL, 0, 'E', 17000, 100, 0, 54, 100, 9, 17, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (102999, 18703, NULL, 0, 'D', 10000, 84, 0, 48, 13, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103000, 18703, NULL, 0, 'G', 130000, 118, 0, 16, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103001, 18703, NULL, 0, 'G', 140000, 91, 0, 14, 0, 0, 141, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103002, 18704, NULL, 0, 'R', 10000, 100, 0, 114, 1, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103003, 18704, NULL, 0, 'E', 14000, 100, 0, 72, 100, 9, 14, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103004, 18704, NULL, 0, 'H', 14000, 174, 0, 38, 24, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103005, 18704, NULL, 0, 'G', 30000, 52, 0, 5, 0, 0, 30, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103006, 18705, NULL, 0, 'A', 0, 58, 0, 143, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103007, 18705, NULL, 0, 'H', 20000, 172, 0, 68, 17, 10, 20, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103008, 18705, NULL, 0, 'E', 14000, 100, 0, 96, 100, 9, 14, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103009, 18705, NULL, 0, 'G', 150000, 155, 0, 0, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103010, 18705, NULL, 0, 'D', 11000, 76, 0, 10, 10, 8, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103011, 18705, NULL, 0, 'G', 120000, 109, 0, 6, 0, 0, 121, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103012, 18706, NULL, 0, 'R', 10000, 26, 0, 106, 2, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103013, 18706, NULL, 0, 'H', 14000, 118, 0, 100, 13, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103014, 18706, NULL, 0, 'E', 17000, 100, 0, 74, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103015, 18706, NULL, 0, 'G', 180000, 120, 0, 25, 0, 0, 181, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103016, 18706, NULL, 0, 'A', 0, 89, 0, 48, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103017, 18706, NULL, 0, 'G', 90000, 161, 0, 21, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103018, 18707, NULL, 0, 'H', 13000, 86, 0, 102, 20, 7, 13, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103019, 18707, NULL, 0, 'E', 17000, 100, 0, 84, 100, 9, 17, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103020, 18707, NULL, 0, 'C', 10000, 0, 0, 47, 5, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103021, 18707, NULL, 0, 'G', 100000, 44, 0, 17, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103022, 18708, NULL, 0, 'H', 15000, 154, 0, 144, 20, 8, 15, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103023, 18708, NULL, 0, 'D', 9000, 64, 0, 97, 7, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103024, 18708, NULL, 0, 'E', 18000, 100, 0, 86, 100, 9, 18, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103025, 18708, NULL, 0, 'G', 190000, 97, 0, 36, 0, 0, 191, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103026, 18708, NULL, 0, 'G', 90000, 113, 0, 8, 0, 0, 90, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103027, 18708, NULL, 0, 'G', 30000, 175, 0, 8, 0, 0, 30, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103028, 18709, NULL, 0, 'R', 10000, 108, 0, 132, 7, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103029, 18709, NULL, 0, 'H', 11000, 78, 0, 75, 12, 6, 11, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103030, 18709, NULL, 0, 'E', 15000, 100, 0, 88, 100, 9, 15, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103031, 18709, NULL, 0, 'G', 70000, 205, 0, 31, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103032, 18709, NULL, 0, 'G', 130000, 133, 0, 11, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103033, 18709, NULL, 0, 'G', 100000, 85, 0, 14, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103034, 18709, NULL, 0, 'G', 130000, 150, 0, 45, 0, 0, 131, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103035, 18710, NULL, 0, 'H', 17000, 96, 0, 123, 21, 9, 17, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103036, 18710, NULL, 0, 'E', 14000, 100, 0, 55, 100, 9, 14, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103037, 18710, NULL, 0, 'C', 9000, 0, 0, 12, 5, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103038, 18710, NULL, 0, 'G', 100000, 103, 0, 1, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103039, 18711, NULL, 0, 'H', 9000, 88, 0, 143, 16, 5, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103040, 18711, NULL, 0, 'D', 8000, 42, 0, 51, 6, 6, 8, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103041, 18711, NULL, 0, 'E', 15000, 100, 0, 86, 100, 9, 15, 1, NULL, NULL, 9000, 1000, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 100, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103042, 18711, NULL, 0, 'G', 150000, 71, 0, 15, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103043, 18711, NULL, 0, 'G', 100000, 154, 0, 41, 0, 0, 101, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103044, 18711, NULL, 0, 'G', 170000, 139, 0, 18, 0, 0, 171, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103045, 18712, NULL, 0, 'R', 9000, 94, 0, 110, 0, 7, 9, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103046, 18712, NULL, 0, 'H', 10000, 132, 0, 80, 13, 5, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103047, 18712, NULL, 0, 'E', 16000, 100, 0, 53, 100, 9, 16, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103048, 18712, NULL, 0, 'G', 150000, 96, 0, 39, 0, 0, 151, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103049, 18712, NULL, 0, 'G', 70000, 176, 0, 8, 0, 0, 70, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103050, 18712, NULL, 0, 'G', 80000, 111, 0, 23, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103051, 18713, NULL, 0, 'D', 10000, 118, 0, 143, 11, 8, 10, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103052, 18713, NULL, 0, 'E', 17000, 100, 0, 64, 100, 9, 17, 1, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103053, 18713, NULL, 0, 'H', 14000, 138, 0, 25, 19, 7, 14, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103054, 18713, NULL, 0, 'G', 110000, 78, 0, 28, 0, 0, 111, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0),
  (103055, 18713, NULL, 0, 'G', 80000, 77, 0, 8, 0, 0, 80, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 10, 0, 0, 0, 0, 75, 1, 100.00, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 1.00, 0, 0, 0);

-- 
-- ����� ������ ��� ������� players
--
INSERT INTO players VALUES 
  (42, 1, 51, 0, 0, 1, NULL, 1.00, 1.00, 0, 1, 0.00, 0, 0.00, NULL);

-- 
-- ����� ������ ��� ������� playerstratres
--
-- ������� fox_ospace.playerstratres �� �������� ������

-- 
-- ����� ������ ��� ������� players_techs
--
INSERT INTO players_techs VALUES 
  (627, 42, 1000, 3, 0),
  (628, 42, 1100, 3, 1),
  (629, 42, 1101, 3, 1),
  (630, 42, 1102, 3, 1),
  (631, 42, 1104, 3, 1),
  (632, 42, 1105, 1, 0),
  (633, 42, 1106, 3, 1),
  (634, 42, 1111, 1, 0),
  (635, 42, 1400, 1, 0),
  (636, 42, 1401, 1, 0),
  (637, 42, 1402, 1, 0),
  (638, 42, 1403, 1, 0),
  (639, 42, 1500, 1, 0),
  (640, 42, 1510, 1, 0),
  (641, 42, 1803, 3, 1),
  (642, 42, 2400, 1, 0),
  (643, 42, 2401, 1, 0),
  (644, 42, 9004, 1, 0),
  (645, 42, 9005, 1, 0);

-- 
-- ����� ������ ��� ������� prodqueue
--
-- ������� fox_ospace.prodqueue �� �������� ������

-- 
-- ����� ������ ��� ������� rsrchqueue
--
-- ������� fox_ospace.rsrchqueue �� �������� ������

-- 
-- ����� ������ ��� ������� shipredirections
--
-- ������� fox_ospace.shipredirections �� �������� ������

-- 
-- ����� ������ ��� ������� ships
--
INSERT INTO ships VALUES 
  (19, 14, 69, 15.0000, 0.0000, 0.0000),
  (20, 14, 69, 15.0000, 0.0000, 0.0000),
  (21, 14, 70, 15.0000, 0.0000, 0.0000),
  (22, 14, 70, 15.0000, 0.0000, 0.0000),
  (23, 14, 72, 51.0000, 0.0000, 0.0000);

-- 
-- ����� ������ ��� ������� ship_designs
--
INSERT INTO ship_designs VALUES 
  (71, 42, 'Bomber'),
  (72, 42, 'Colony Ship'),
  (70, 42, 'Fighter'),
  (69, 42, 'Scout');

-- 
-- ����� ������ ��� ������� ship_designs_equipment
--
INSERT INTO ship_designs_equipment VALUES 
  (69, 635, 1, 1, 0),
  (69, 637, 1, 0, 1),
  (69, 636, 3, 0, 0),
  (69, 638, 1, 0, 0),
  (70, 635, 1, 1, 0),
  (70, 637, 1, 0, 1),
  (70, 636, 3, 0, 0),
  (70, 639, 1, 0, 0),
  (71, 635, 1, 1, 0),
  (71, 637, 1, 0, 1),
  (71, 636, 3, 0, 0),
  (71, 640, 1, 0, 0),
  (72, 643, 1, 1, 0),
  (72, 637, 1, 0, 1),
  (72, 636, 4, 0, 0),
  (72, 642, 1, 0, 0);

-- 
-- ����� ������ ��� ������� startingpos
--
-- ������� fox_ospace.startingpos �� �������� ������

-- 
-- ����� ������ ��� ������� structures
--
INSERT INTO structures VALUES 
  (188, 1111, 102844, 0, 42, 600, 1, 0),
  (189, 1104, 102844, 1, 42, 200, 1, 0),
  (190, 1104, 102844, 2, 42, 200, 1, 0),
  (191, 1104, 102844, 3, 42, 200, 1, 0),
  (192, 9004, 102844, 4, 42, 450, 1, 0),
  (193, 9004, 102844, 5, 42, 450, 1, 0),
  (194, 9005, 102844, 6, 42, 450, 1, 0),
  (195, 1105, 102844, 7, 42, 150, 1, 0);

-- 
-- ����� ������ ��� ������� systems
--
INSERT INTO systems VALUES 
  (18199, 51, -47, -21, 'mM', 0, 100, 0, 0),
  (18200, 51, -46, -42, 'mG', 8, 100, 0, 0),
  (18201, 51, -44, -63, 'mM', 1, 100, 0, 0),
  (18202, 51, -13, -63, 'mM', 7, 100, 0, 0),
  (18203, 51, 19, -53, 'mM', 9, 100, 0, 0),
  (18204, 51, 37, -57, 'mF', 1, 100, 0, 0),
  (18205, 51, 60, -27, 'mM', 3, 100, 0, 0),
  (18206, 51, 68, -17, 'mM', 4, 100, 0, 0),
  (18207, 51, 63, 22, 'mM', 2, 100, 0, 0),
  (18208, 51, 55, 42, 'mM', 6, 100, 0, 0),
  (18209, 51, 46, 59, 'mG', 8, 100, 0, 0),
  (18210, 51, 9, 56, 'mM', 2, 100, 0, 0),
  (18211, 51, -13, 50, 'mG', 0, 100, 0, 0),
  (18212, 51, -34, 48, 'mM', 7, 100, 0, 0),
  (18213, 51, -57, 53, 'mK', 5, 100, 0, 0),
  (18214, 51, -48, 18, 'mM', 1, 100, 0, 0),
  (18215, 51, 29, -89, 'mM', 2, 100, 0, 0),
  (18216, 51, 63, -71, 'mK', 0, 100, 0, 0),
  (18217, 51, 84, -35, 'mK', 2, 100, 0, 0),
  (18218, 51, 77, -17, 'mM', 3, 100, 0, 0),
  (18219, 51, 108, 17, 'mK', 10, 100, 0, 0),
  (18220, 51, 85, 48, 'mA', 8, 100, 0, 0),
  (18221, 51, 47, 76, 'mK', 7, 100, 0, 0),
  (18222, 51, 15, 91, 'mK', 1, 100, 0, 0),
  (18223, 51, -14, 83, 'mG', 9, 100, 0, 0),
  (18224, 51, -52, 83, 'mK', 9, 100, 0, 0),
  (18225, 51, -59, 56, 'mM', 3, 100, 0, 0),
  (18226, 51, -95, 36, 'mK', 6, 100, 0, 0),
  (18227, 51, -102, 8, 'mG', 2, 100, 0, 0),
  (18228, 51, -94, -56, 'mM', 0, 100, 0, 0),
  (18229, 51, -79, -69, 'mG', 4, 100, 0, 0),
  (18230, 51, -20, -77, 'mM', 1, 100, 0, 0),
  (18231, 51, -12, -93, 'mK', 3, 100, 0, 0),
  (18232, 51, -106, 61, 'mM', 7, 100, 0, 0),
  (18233, 51, -127, 47, 'mM', 5, 100, 0, 0),
  (18234, 51, -125, -4, 'mM', 6, 100, 0, 0),
  (18235, 51, -118, -29, 'mG', 6, 100, 0, 0),
  (18236, 51, -115, -71, 'mM', 9, 100, 0, 0),
  (18237, 51, -80, -77, 'mM', 8, 100, 0, 0),
  (18238, 51, -58, -103, 'mK', 6, 100, 0, 0),
  (18239, 51, -17, -110, 'mF', 2, 100, 0, 0),
  (18240, 51, -8, -125, 'mM', 6, 100, 0, 0),
  (18241, 51, 24, -111, 'mM', 8, 100, 0, 0),
  (18242, 51, 62, -102, 'mK', 9, 100, 0, 0),
  (18243, 51, 101, -86, 'mF', 5, 100, 0, 0),
  (18244, 51, 125, -65, 'mK', 10, 100, 0, 0),
  (18245, 51, 115, -12, 'mK', 3, 100, 0, 0),
  (18246, 51, 137, 11, 'mK', 3, 100, 0, 0),
  (18247, 51, 127, 53, 'mF', 2, 100, 0, 0),
  (18248, 51, 104, 76, 'mF', 7, 100, 0, 0),
  (18249, 51, 86, 113, 'mM', 2, 100, 0, 0),
  (18250, 51, 37, 126, 'gM', 0, 100, 0, 0),
  (18251, 51, 13, 121, 'mM', 5, 100, 0, 0),
  (18252, 51, -41, 102, 'mM', 6, 100, 0, 0),
  (18253, 51, -65, 107, 'mM', 3, 100, 0, 0),
  (18254, 51, -132, 75, 'mM', 9, 100, 0, 0),
  (18255, 51, -144, 37, 'mM', 3, 100, 0, 0),
  (18256, 51, -151, -12, 'mM', 2, 100, 0, 0),
  (18257, 51, -135, -46, 'mG', 9, 100, 0, 0),
  (18258, 51, -135, -69, 'mG', 4, 100, 0, 0),
  (18259, 51, -101, -107, 'mM', 7, 100, 0, 0),
  (18260, 51, -83, -133, 'mG', 8, 100, 0, 0),
  (18261, 51, -63, -138, 'mM', 10, 100, 0, 0),
  (18262, 51, -8, -153, 'mM', 7, 100, 0, 0),
  (18263, 51, 23, -162, 'mM', 7, 100, 0, 0),
  (18264, 51, 48, -142, 'mM', 2, 100, 0, 0),
  (18265, 51, 84, -117, 'mF', 0, 100, 0, 0),
  (18266, 51, 112, -103, 'mM', 1, 100, 0, 0),
  (18267, 51, 154, -54, 'mM', 7, 100, 0, 0),
  (18268, 51, 162, -28, 'mG', 2, 100, 0, 0),
  (18269, 51, 151, -7, 'mM', 9, 100, 0, 0),
  (18270, 51, 136, 54, 'mM', 10, 100, 0, 0),
  (18271, 51, 126, 83, 'mK', 2, 100, 0, 0),
  (18272, 51, 101, 123, 'mK', 2, 100, 0, 0),
  (18273, 51, 65, 127, 'mK', 4, 100, 0, 0),
  (18274, 51, 48, 142, 'mK', 0, 100, 0, 0),
  (18275, 51, 22, 145, 'mM', 1, 100, 0, 0),
  (18276, 51, -25, 156, 'mK', 8, 100, 0, 0),
  (18277, 51, -46, 140, 'mM', 6, 100, 0, 0),
  (18278, 51, -105, 113, 'mG', 9, 100, 0, 0),
  (18279, 51, 175, 83, 'mF', 7, 100, 0, 0),
  (18280, 51, 166, 99, 'mF', 7, 100, 0, 0),
  (18281, 51, 141, 127, 'mM', 2, 100, 0, 0),
  (18282, 51, 83, 144, 'mM', 10, 100, 0, 0),
  (18283, 51, 51, 167, 'mM', 5, 100, 0, 0),
  (18284, 51, 38, 190, 'mK', 10, 100, 0, 0),
  (18285, 51, -19, 176, 'mM', 3, 100, 0, 0),
  (18286, 51, -33, 179, 'mK', 9, 100, 0, 0),
  (18287, 51, -59, 158, 'mF', 8, 100, 0, 0),
  (18288, 51, -105, 128, 'mK', 1, 100, 0, 0),
  (18289, 51, -122, 124, 'mK', 3, 100, 0, 0),
  (18290, 51, -165, 96, 'mM', 0, 100, 0, 0),
  (18291, 51, -163, 51, 'dF', 1, 100, 0, 0),
  (18292, 51, -165, 27, 'mG', 6, 100, 0, 0),
  (18293, 51, -195, -18, 'mM', 0, 100, 0, 0),
  (18294, 51, -176, -42, 'mM', 2, 100, 0, 0),
  (18295, 51, -144, -89, 'mM', 4, 100, 0, 0),
  (18296, 51, -122, -113, 'mK', 5, 100, 0, 0),
  (18297, 51, -103, -146, 'mK', 3, 100, 0, 0),
  (18298, 51, -90, -138, 'mK', 10, 100, 0, 0),
  (18299, 51, -45, -164, 'mM', 5, 100, 0, 0),
  (18300, 51, -2, -198, 'mM', 7, 100, 0, 0),
  (18301, 51, 33, -176, 'mK', 2, 100, 0, 0),
  (18302, 51, 57, -177, 'mF', 7, 100, 0, 0),
  (18303, 51, 87, -143, 'mM', 1, 100, 0, 0),
  (18304, 51, 107, -130, 'mM', 4, 100, 0, 0),
  (18305, 51, 124, -110, 'dA', 8, 100, 0, 0),
  (18306, 51, 183, -76, 'mK', 10, 100, 0, 0),
  (18307, 51, 163, -40, 'mK', 7, 100, 0, 0),
  (18308, 51, 194, -22, 'mM', 3, 100, 0, 0),
  (18309, 51, 181, 27, 'mM', 0, 100, 0, 0),
  (18310, 51, -34, -213, 'mM', 7, 100, 0, 0),
  (18311, 51, -8, -229, 'mK', 9, 100, 0, 0),
  (18312, 51, 57, -207, 'mM', 8, 100, 0, 0),
  (18313, 51, 83, -192, 'mM', 4, 100, 0, 0),
  (18314, 51, 109, -174, 'mK', 2, 100, 0, 0),
  (18315, 51, 155, -128, 'mM', 10, 100, 0, 0),
  (18316, 51, 168, -119, 'mK', 2, 100, 0, 0),
  (18317, 51, 195, -55, 'mM', 7, 100, 0, 0),
  (18318, 51, 210, -19, 'mF', 0, 100, 0, 0),
  (18319, 51, 225, 29, 'mM', 6, 100, 0, 0),
  (18320, 51, 229, 55, 'mG', 1, 100, 0, 0),
  (18321, 51, 174, 105, 'mK', 1, 100, 0, 0),
  (18322, 51, 144, 142, 'mK', 4, 100, 0, 0),
  (18323, 51, 138, 179, 'mM', 8, 100, 0, 0),
  (18324, 51, 68, 194, 'mM', 1, 100, 0, 0),
  (18325, 51, 31, 199, 'mK', 6, 100, 0, 0),
  (18326, 51, -5, 212, 'mM', 3, 100, 0, 0),
  (18327, 51, -72, 218, 'mM', 5, 100, 0, 0),
  (18328, 51, -111, 191, 'dF', 5, 100, 0, 0),
  (18329, 51, -139, 168, 'mM', 6, 100, 0, 0),
  (18330, 51, -189, 132, 'mG', 8, 100, 0, 0),
  (18331, 51, -204, 89, 'mK', 10, 100, 0, 0),
  (18332, 51, -199, 50, 'mK', 3, 100, 0, 0),
  (18333, 51, -232, -5, 'mF', 8, 100, 0, 0),
  (18334, 51, -206, -18, 'mG', 6, 100, 0, 0),
  (18335, 51, -215, -69, 'mK', 9, 100, 0, 0),
  (18336, 51, -177, -129, 'mM', 10, 100, 0, 0),
  (18337, 51, -145, -164, 'mG', 8, 100, 0, 0),
  (18338, 51, -98, -178, 'mM', 0, 100, 0, 0),
  (18339, 51, 97, 233, 'mM', 3, 100, 0, 0),
  (18340, 51, 49, 247, 'dK', 2, 100, 0, 0),
  (18341, 51, -8, 250, 'mK', 3, 100, 0, 0),
  (18342, 51, -23, 249, 'mG', 9, 100, 0, 0),
  (18343, 51, -78, 228, 'mM', 0, 100, 0, 0),
  (18344, 51, -122, 203, 'mK', 1, 100, 0, 0),
  (18345, 51, -176, 186, 'mM', 5, 100, 0, 0),
  (18346, 51, -213, 136, 'mK', 0, 100, 0, 0),
  (18347, 51, -216, 100, 'mK', 4, 100, 0, 0),
  (18348, 51, -248, 58, 'mK', 8, 100, 0, 0),
  (18349, 51, -246, 10, 'mK', 1, 100, 0, 0),
  (18350, 51, -256, -28, 'mK', 7, 100, 0, 0),
  (18351, 51, -231, -72, 'mG', 3, 100, 0, 0),
  (18352, 51, -208, -122, 'mK', 3, 100, 0, 0),
  (18353, 51, -180, -166, 'mK', 2, 100, 0, 0),
  (18354, 51, -153, -196, 'mG', 8, 100, 0, 0),
  (18355, 51, -100, -216, 'mM', 2, 100, 0, 0),
  (18356, 51, -77, -246, 'mM', 4, 100, 0, 0),
  (18357, 51, -31, -241, 'mA', 3, 100, 0, 0),
  (18358, 51, 39, -243, 'mG', 0, 100, 0, 0),
  (18359, 51, 93, -240, 'mM', 4, 100, 0, 0),
  (18360, 51, 111, -208, 'mM', 7, 100, 0, 0),
  (18361, 51, 161, -202, 'mM', 9, 100, 0, 0),
  (18362, 51, 191, -153, 'mM', 10, 100, 0, 0),
  (18363, 51, 232, -96, 'mK', 3, 100, 0, 0),
  (18364, 51, 251, -50, 'mK', 2, 100, 0, 0),
  (18365, 51, 250, -39, 'mM', 10, 100, 0, 0),
  (18366, 51, 245, 14, 'mF', 10, 100, 0, 0),
  (18367, 51, 221, 87, 'dF', 6, 100, 0, 0),
  (18368, 51, 226, 105, 'mM', 6, 100, 0, 0),
  (18369, 51, 191, 145, 'mM', 1, 100, 0, 0),
  (18370, 51, 161, 194, 'mM', 5, 100, 0, 0),
  (18371, 51, 17, -286, 'mM', 8, 100, 0, 0),
  (18372, 51, 76, -255, 'mK', 7, 100, 0, 0),
  (18373, 51, 119, -261, 'mK', 10, 100, 0, 0),
  (18374, 51, 140, -237, 'dK', 7, 100, 0, 0),
  (18375, 51, 189, -217, 'mM', 3, 100, 0, 0),
  (18376, 51, 225, -150, 'mK', 7, 100, 0, 0),
  (18377, 51, 251, -154, 'mG', 2, 100, 0, 0),
  (18378, 51, 250, -97, 'dK', 8, 100, 0, 0),
  (18379, 51, 278, -18, 'dA', 0, 100, 0, 0),
  (18380, 51, 291, 31, 'mG', 4, 100, 0, 0),
  (18381, 51, 264, 51, 'dA', 10, 100, 0, 0),
  (18382, 51, 269, 96, 'dK', 7, 100, 0, 0),
  (18383, 51, 252, 151, 'mK', 2, 100, 0, 0),
  (18384, 51, 202, 163, 'mK', 6, 100, 0, 0),
  (18385, 51, 160, 226, 'mM', 9, 100, 0, 0),
  (18386, 51, 146, 216, 'mM', 7, 100, 0, 0),
  (18387, 51, 104, 242, 'mM', 6, 100, 0, 0),
  (18388, 51, 59, 265, 'mF', 3, 100, 0, 0),
  (18389, 51, -10, 269, 'mK', 6, 100, 0, 0),
  (18390, 51, -37, 256, 'mM', 1, 100, 0, 0),
  (18391, 51, -88, 257, 'mM', 9, 100, 0, 0),
  (18392, 51, -129, 241, 'mF', 1, 100, 0, 0),
  (18393, 51, -171, 207, 'mF', 6, 100, 0, 0),
  (18394, 51, -197, 195, 'mM', 3, 100, 0, 0),
  (18395, 51, -235, 147, 'mF', 6, 100, 0, 0),
  (18396, 51, -238, 113, 'mK', 5, 100, 0, 0),
  (18397, 51, -261, 78, 'mF', 9, 100, 0, 0),
  (18398, 51, -272, 22, 'mM', 3, 100, 0, 0),
  (18399, 51, -270, -44, 'mM', 8, 100, 0, 0),
  (18400, 51, -271, -59, 'mK', 2, 100, 0, 0),
  (18401, 51, -243, -117, 'mG', 6, 100, 0, 0),
  (18402, 51, -220, -187, 'dK', 9, 100, 0, 0),
  (18403, 51, -179, -203, 'mK', 3, 100, 0, 0),
  (18404, 51, -145, -234, 'mM', 3, 100, 0, 0),
  (18405, 51, -123, -229, 'mG', 7, 100, 0, 0),
  (18406, 51, -89, -270, 'dF', 4, 100, 0, 0),
  (18407, 51, -203, 238, 'mK', 0, 100, 0, 0),
  (18408, 51, -213, 210, 'dF', 4, 100, 0, 0),
  (18409, 51, -273, 136, 'mM', 5, 100, 0, 0),
  (18410, 51, -297, 95, 'dK', 1, 100, 0, 0),
  (18411, 51, -288, 76, 'mM', 5, 100, 0, 0),
  (18412, 51, -295, -8, 'mB', 5, 100, 0, 0),
  (18413, 51, -302, -50, 'mG', 1, 100, 0, 0),
  (18414, 51, -300, -87, 'mK', 0, 100, 0, 0),
  (18415, 51, -271, -144, 'mF', 6, 100, 0, 0),
  (18416, 51, -242, -193, 'mK', 3, 100, 0, 0),
  (18417, 51, -177, -241, 'mM', 7, 100, 0, 0),
  (18418, 51, -155, -262, 'mM', 4, 100, 0, 0),
  (18419, 51, -94, -294, 'dF', 9, 100, 0, 0),
  (18420, 51, -34, -313, 'mM', 3, 100, 0, 0),
  (18421, 51, 7, -296, 'mF', 0, 100, 0, 0),
  (18422, 51, 49, -311, 'dA', 6, 100, 0, 0),
  (18423, 51, 83, -298, 'mK', 9, 100, 0, 0),
  (18424, 51, 133, -283, 'mK', 1, 100, 0, 0),
  (18425, 51, 192, -243, 'mM', 8, 100, 0, 0),
  (18426, 51, 228, -191, 'mG', 9, 100, 0, 0),
  (18427, 51, 266, -156, 'mM', 7, 100, 0, 0),
  (18428, 51, 292, -112, 'mK', 5, 100, 0, 0),
  (18429, 51, 300, -66, 'mM', 10, 100, 0, 0),
  (18430, 51, 313, -22, 'mM', 7, 100, 0, 0),
  (18431, 51, 296, 71, 'mA', 4, 100, 0, 0),
  (18432, 51, 289, 87, 'mF', 4, 100, 0, 0),
  (18433, 51, 272, 127, 'mG', 8, 100, 0, 0),
  (18434, 51, 249, 187, 'mM', 7, 100, 0, 0),
  (18435, 51, 208, 216, 'mK', 0, 100, 0, 0),
  (18436, 51, 159, 257, 'mK', 4, 100, 0, 0),
  (18437, 51, 89, 281, 'mM', 0, 100, 0, 0),
  (18438, 51, 70, 290, 'mF', 1, 100, 0, 0),
  (18439, 51, 22, 296, 'mK', 10, 100, 0, 0),
  (18440, 51, -71, 306, 'mF', 2, 100, 0, 0),
  (18441, 51, -82, 290, 'mF', 8, 100, 0, 0),
  (18442, 51, -258, 220, 'mK', 3, 100, 0, 0),
  (18443, 51, -286, 174, 'mK', 10, 100, 0, 0),
  (18444, 51, -313, 131, 'mK', 8, 100, 0, 0),
  (18445, 51, -311, 94, 'mF', 2, 100, 0, 0),
  (18446, 51, -331, 32, 'gK', 3, 100, 0, 0),
  (18447, 51, -323, -23, 'mM', 0, 100, 0, 0),
  (18448, 51, -323, -102, 'mG', 8, 100, 0, 0),
  (18449, 51, -312, -122, 'mK', 1, 100, 0, 0),
  (18450, 51, -270, -180, 'mK', 1, 100, 0, 0),
  (18451, 51, -253, -204, 'mM', 9, 100, 0, 0),
  (18452, 51, -207, -253, 'mM', 7, 100, 0, 0),
  (18453, 51, -178, -287, 'mG', 3, 100, 0, 0),
  (18454, 51, -97, -304, 'mK', 0, 100, 0, 0),
  (18455, 51, -54, -325, 'mG', 1, 100, 0, 0),
  (18456, 51, -20, -335, 'mM', 4, 100, 0, 0),
  (18457, 51, 25, -339, 'mK', 3, 100, 0, 0),
  (18458, 51, 95, -316, 'mM', 7, 100, 0, 0),
  (18459, 51, 149, -286, 'mG', 5, 100, 0, 0),
  (18460, 51, 187, -260, 'mF', 10, 100, 0, 0),
  (18461, 51, 220, -238, 'mG', 6, 100, 0, 0),
  (18462, 51, 273, -205, 'mG', 3, 100, 0, 0),
  (18463, 51, 290, -157, 'mF', 6, 100, 0, 0),
  (18464, 51, 300, -119, 'mM', 9, 100, 0, 0),
  (18465, 51, 324, -40, 'mK', 1, 100, 0, 0),
  (18466, 51, 335, -8, 'mM', 0, 100, 0, 0),
  (18467, 51, 336, 56, 'mF', 8, 100, 0, 0),
  (18468, 51, 308, 116, 'mM', 1, 100, 0, 0),
  (18469, 51, 282, 168, 'mF', 7, 100, 0, 0),
  (18470, 51, 266, 196, 'mG', 4, 100, 0, 0),
  (18471, 51, 248, 219, 'mM', 0, 100, 0, 0),
  (18472, 51, 173, 275, 'mG', 1, 100, 0, 0),
  (18473, 51, 148, 309, 'mK', 10, 100, 0, 0),
  (18474, 51, 91, 331, 'mG', 1, 100, 0, 0),
  (18475, 51, 30, 319, 'dA', 6, 100, 0, 0),
  (18476, 51, -4, 338, 'mM', 5, 100, 0, 0),
  (18477, 51, -40, 335, 'mM', 5, 100, 0, 0),
  (18478, 51, -94, 323, 'dG', 5, 100, 0, 0),
  (18479, 51, -165, 295, 'mF', 10, 100, 0, 0),
  (18480, 51, -209, 256, 'mM', 0, 100, 0, 0),
  (18481, 51, -305, 166, 'mM', 2, 100, 0, 0),
  (18482, 51, -337, 100, 'mK', 10, 100, 0, 0),
  (18483, 51, -362, 35, 'mM', 1, 100, 0, 0),
  (18484, 51, -361, -22, 'mM', 9, 100, 0, 0),
  (18485, 51, -354, -77, 'mM', 5, 100, 0, 0),
  (18486, 51, -346, -131, 'dA', 6, 100, 0, 0),
  (18487, 51, -327, -131, 'mM', 9, 100, 0, 0),
  (18488, 51, -300, -175, 'mF', 2, 100, 0, 0),
  (18489, 51, -279, -224, 'mK', 8, 100, 0, 0),
  (18490, 51, -227, -274, 'mF', 10, 100, 0, 0),
  (18491, 51, -174, -306, 'mM', 3, 100, 0, 0),
  (18492, 51, -130, -332, 'mK', 7, 100, 0, 0),
  (18493, 51, -107, -353, 'mM', 4, 100, 0, 0),
  (18494, 51, -49, -364, 'mM', 9, 100, 0, 0),
  (18495, 51, 16, -344, 'dA', 3, 100, 0, 0),
  (18496, 51, 77, -345, 'mK', 6, 100, 0, 0),
  (18497, 51, 121, -346, 'mK', 1, 100, 0, 0),
  (18498, 51, 180, -305, 'mM', 4, 100, 0, 0),
  (18499, 51, 234, -274, 'mK', 5, 100, 0, 0),
  (18500, 51, 230, -256, 'mM', 10, 100, 0, 0),
  (18501, 51, 299, -188, 'dF', 2, 100, 0, 0),
  (18502, 51, 323, -170, 'mF', 8, 100, 0, 0),
  (18503, 51, 340, -109, 'mM', 0, 100, 0, 0),
  (18504, 51, 354, -73, 'dG', 10, 100, 0, 0),
  (18505, 51, 368, -15, 'mF', 2, 100, 0, 0),
  (18506, 51, 344, 51, 'mM', 7, 100, 0, 0),
  (18507, 51, 329, 109, 'mF', 0, 100, 0, 0),
  (18508, 51, 328, 123, 'mM', 2, 100, 0, 0),
  (18509, 51, 317, 182, 'mM', 6, 100, 0, 0),
  (18510, 51, 278, 225, 'mG', 5, 100, 0, 0),
  (18511, 51, 244, 280, 'mG', 1, 100, 0, 0),
  (18512, 51, 182, 311, 'mF', 0, 100, 0, 0),
  (18513, 51, 162, 313, 'mK', 6, 100, 0, 0),
  (18514, 51, 111, 335, 'mB', 1, 100, 0, 0),
  (18515, 51, 37, 345, 'mM', 5, 100, 0, 0),
  (18516, 51, -2, 369, 'mK', 0, 100, 0, 0),
  (18517, 51, -44, 342, 'mK', 7, 100, 0, 0),
  (18518, 51, -93, 356, 'mF', 4, 100, 0, 0),
  (18519, 51, -170, 331, 'mM', 8, 100, 0, 0),
  (18520, 51, -215, 286, 'dA', 8, 100, 0, 0),
  (18521, 51, -243, 263, 'mM', 10, 100, 0, 0),
  (18522, 51, -296, 221, 'mG', 9, 100, 0, 0),
  (18523, 51, 148, -360, 'mM', 5, 100, 0, 0),
  (18524, 51, 212, -341, 'dA', 4, 100, 0, 0),
  (18525, 51, 253, -293, 'mK', 0, 100, 0, 0),
  (18526, 51, 294, -260, 'mM', 0, 100, 0, 0),
  (18527, 51, 315, -253, 'mM', 0, 100, 0, 0),
  (18528, 51, 348, -166, 'mM', 3, 100, 0, 0),
  (18529, 51, 375, -139, 'mF', 9, 100, 0, 0),
  (18530, 51, 380, -75, 'mM', 6, 100, 0, 0),
  (18531, 51, 378, -15, 'mA', 4, 100, 0, 0),
  (18532, 51, 399, 34, 'mM', 5, 100, 0, 0),
  (18533, 51, 395, 75, 'mG', 3, 100, 0, 0),
  (18534, 51, 362, 105, 'mM', 0, 100, 0, 0),
  (18535, 51, 345, 193, 'mM', 7, 100, 0, 0),
  (18536, 51, 330, 215, 'mM', 9, 100, 0, 0),
  (18537, 51, 317, 255, 'mM', 7, 100, 0, 0),
  (18538, 51, 250, 296, 'mK', 1, 100, 0, 0),
  (18539, 51, 194, 336, 'dF', 4, 100, 0, 0),
  (18540, 51, 176, 341, 'mF', 10, 100, 0, 0),
  (18541, 51, 141, 375, 'dG', 3, 100, 0, 0),
  (18542, 51, 49, 381, 'mG', 7, 100, 0, 0),
  (18543, 51, 32, 383, 'dF', 1, 100, 0, 0),
  (18544, 51, -57, 378, 'mK', 7, 100, 0, 0),
  (18545, 51, -94, 394, 'mK', 7, 100, 0, 0),
  (18546, 51, -129, 359, 'mM', 6, 100, 0, 0),
  (18547, 51, -169, 336, 'mM', 9, 100, 0, 0),
  (18548, 51, -224, 328, 'dG', 9, 100, 0, 0),
  (18549, 51, -273, 282, 'dF', 0, 100, 0, 0),
  (18550, 51, -309, 217, 'mM', 4, 100, 0, 0),
  (18551, 51, -326, 206, 'mG', 1, 100, 0, 0),
  (18552, 51, -370, 136, 'mK', 0, 100, 0, 0),
  (18553, 51, -366, 103, 'mG', 2, 100, 0, 0),
  (18554, 51, -371, 56, 'mK', 10, 100, 0, 0),
  (18555, 51, -377, 0, 'mG', 3, 100, 0, 0),
  (18556, 51, -406, -41, 'mM', 3, 100, 0, 0),
  (18557, 51, -357, -122, 'mM', 9, 100, 0, 0),
  (18558, 51, -351, -138, 'mM', 5, 100, 0, 0),
  (18559, 51, -338, -204, 'mK', 6, 100, 0, 0),
  (18560, 51, -297, -246, 'mM', 9, 100, 0, 0),
  (18561, 51, -268, -285, 'mM', 2, 100, 0, 0),
  (18562, 51, -217, -344, 'mK', 5, 100, 0, 0),
  (18563, 51, -171, -359, 'mM', 6, 100, 0, 0),
  (18564, 51, -148, -347, 'mM', 8, 100, 0, 0),
  (18565, 51, -65, -395, 'mM', 10, 100, 0, 0),
  (18566, 51, -20, -388, 'mM', 5, 100, 0, 0),
  (18567, 51, 11, -385, 'mM', 5, 100, 0, 0),
  (18568, 51, 67, -383, 'mF', 5, 100, 0, 0),
  (18569, 51, 419, -72, 'mK', 9, 100, 0, 0),
  (18570, 51, 438, -38, 'mK', 9, 100, 0, 0),
  (18571, 51, 438, 25, 'dA', 8, 100, 0, 0),
  (18572, 51, 410, 82, 'mK', 2, 100, 0, 0),
  (18573, 51, 411, 149, 'mK', 1, 100, 0, 0),
  (18574, 51, 374, 175, 'mG', 10, 100, 0, 0),
  (18575, 51, 369, 215, 'mK', 2, 100, 0, 0),
  (18576, 51, 317, 266, 'mF', 3, 100, 0, 0),
  (18577, 51, 311, 304, 'mK', 6, 100, 0, 0),
  (18578, 51, 260, 334, 'mK', 2, 100, 0, 0),
  (18579, 51, 185, 382, 'mG', 10, 100, 0, 0),
  (18580, 51, 143, 386, 'mK', 9, 100, 0, 0),
  (18581, 51, 79, 405, 'dA', 4, 100, 0, 0),
  (18582, 51, 66, 412, 'mK', 8, 100, 0, 0),
  (18583, 51, 13, 420, 'mM', 0, 100, 0, 0),
  (18584, 51, -67, 435, 'mM', 4, 100, 0, 0),
  (18585, 51, -96, 399, 'mK', 1, 100, 0, 0),
  (18586, 51, -176, 401, 'mG', 6, 100, 0, 0),
  (18587, 51, -230, 374, 'mM', 7, 100, 0, 0),
  (18588, 51, -246, 339, 'mF', 6, 100, 0, 0),
  (18589, 51, -300, 301, 'mK', 3, 100, 0, 0),
  (18590, 51, -344, 268, 'mM', 0, 100, 0, 0),
  (18591, 51, -335, 240, 'mM', 5, 100, 0, 0),
  (18592, 51, -393, 180, 'mM', 5, 100, 0, 0),
  (18593, 51, -393, 136, 'mK', 5, 100, 0, 0),
  (18594, 51, -415, 70, 'mG', 5, 100, 0, 0),
  (18595, 51, -412, 14, 'dA', 5, 100, 0, 0),
  (18596, 51, -425, -48, 'mK', 3, 100, 0, 0),
  (18597, 51, -417, -78, 'mM', 2, 100, 0, 0),
  (18598, 51, -401, -139, 'mM', 0, 100, 0, 0),
  (18599, 51, -386, -192, 'mM', 0, 100, 0, 0),
  (18600, 51, -382, -211, 'mM', 5, 100, 0, 0),
  (18601, 51, -315, -274, 'mM', 10, 100, 0, 0),
  (18602, 51, -283, -317, 'mF', 6, 100, 0, 0),
  (18603, 51, -244, -361, 'mF', 1, 100, 0, 0),
  (18604, 51, -194, -362, 'mK', 3, 100, 0, 0),
  (18605, 51, -185, -397, 'mK', 5, 100, 0, 0),
  (18606, 51, -125, -413, 'mM', 5, 100, 0, 0),
  (18607, 51, -36, -418, 'mM', 5, 100, 0, 0),
  (18608, 51, 2, -427, 'mK', 2, 100, 0, 0),
  (18609, 51, 63, -416, 'mK', 0, 100, 0, 0),
  (18610, 51, 104, -410, 'mF', 6, 100, 0, 0),
  (18611, 51, 178, -401, 'mM', 2, 100, 0, 0),
  (18612, 51, 183, -387, 'mK', 4, 100, 0, 0),
  (18613, 51, 235, -367, 'mF', 10, 100, 0, 0),
  (18614, 51, 295, -293, 'mK', 2, 100, 0, 0),
  (18615, 51, 343, -274, 'mF', 3, 100, 0, 0),
  (18616, 51, 348, -219, 'mF', 8, 100, 0, 0),
  (18617, 51, 382, -191, 'mK', 6, 100, 0, 0),
  (18618, 51, 396, -160, 'mK', 9, 100, 0, 0),
  (18619, 51, 388, -234, 'mM', 10, 100, 0, 0),
  (18620, 51, 427, -178, 'dG', 10, 100, 0, 0),
  (18621, 51, 449, -123, 'mM', 9, 100, 0, 0),
  (18622, 51, 436, -76, 'mM', 6, 100, 0, 0),
  (18623, 51, 454, -22, 'mM', 7, 100, 0, 0),
  (18624, 51, 443, 60, 'dB', 10, 100, 0, 0),
  (18625, 51, 441, 87, 'mK', 9, 100, 0, 0),
  (18626, 51, 437, 126, 'mK', 4, 100, 0, 0),
  (18627, 51, 408, 186, 'mG', 3, 100, 0, 0),
  (18628, 51, 389, 231, 'mG', 5, 100, 0, 0),
  (18629, 51, 374, 276, 'dB', 2, 100, 0, 0),
  (18630, 51, 295, 332, 'mM', 9, 100, 0, 0),
  (18631, 51, 279, 360, 'mK', 2, 100, 0, 0),
  (18632, 51, 251, 386, 'mG', 9, 100, 0, 0),
  (18633, 51, 189, 422, 'mG', 7, 100, 0, 0),
  (18634, 51, 152, 441, 'mM', 10, 100, 0, 0),
  (18635, 51, 90, 433, 'mK', 1, 100, 0, 0),
  (18636, 51, 16, 448, 'mO', 9, 100, 0, 0),
  (18637, 51, -3, 452, 'mK', 8, 100, 0, 0),
  (18638, 51, -59, 445, 'mM', 0, 100, 0, 0),
  (18639, 51, -113, 427, 'dK', 7, 100, 0, 0),
  (18640, 51, -175, 430, 'mM', 5, 100, 0, 0),
  (18641, 51, -244, 371, 'mF', 0, 100, 0, 0),
  (18642, 51, -283, 345, 'mM', 5, 100, 0, 0),
  (18643, 51, -304, 347, 'mK', 4, 100, 0, 0),
  (18644, 51, -352, 267, 'mG', 5, 100, 0, 0),
  (18645, 51, -385, 244, 'mF', 3, 100, 0, 0),
  (18646, 51, -402, 213, 'mF', 7, 100, 0, 0),
  (18647, 51, -424, 148, 'mK', 0, 100, 0, 0),
  (18648, 51, -432, 111, 'mM', 6, 100, 0, 0),
  (18649, 51, -441, 22, 'mM', 8, 100, 0, 0),
  (18650, 51, -443, -4, 'mK', 9, 100, 0, 0),
  (18651, 51, -453, -83, 'mK', 1, 100, 0, 0),
  (18652, 51, -441, -113, 'mK', 7, 100, 0, 0),
  (18653, 51, -432, -162, 'mK', 0, 100, 0, 0),
  (18654, 51, -415, -200, 'mM', 1, 100, 0, 0),
  (18655, 51, -383, -249, 'dA', 3, 100, 0, 0),
  (18656, 51, -319, -316, 'mM', 8, 100, 0, 0),
  (18657, 51, -281, -342, 'mM', 0, 100, 0, 0),
  (18658, 51, -246, -378, 'mK', 7, 100, 0, 0),
  (18659, 51, -194, -408, 'mK', 9, 100, 0, 0),
  (18660, 51, -155, -424, 'mM', 1, 100, 0, 0),
  (18661, 51, -118, -440, 'dK', 9, 100, 0, 0),
  (18662, 51, -75, -446, 'mM', 0, 100, 0, 0),
  (18663, 51, 16, -448, 'mK', 5, 100, 0, 0),
  (18664, 51, 31, -465, 'mK', 2, 100, 0, 0),
  (18665, 51, 96, -451, 'mM', 6, 100, 0, 0),
  (18666, 51, 132, -426, 'mF', 3, 100, 0, 0),
  (18667, 51, 192, -419, 'mB', 8, 100, 0, 0),
  (18668, 51, 253, -387, 'mK', 8, 100, 0, 0),
  (18669, 51, 276, -353, 'mM', 7, 100, 0, 0),
  (18670, 51, 324, -315, 'mK', 6, 100, 0, 0),
  (18671, 51, 349, -288, 'dF', 7, 100, 0, 0),
  (18672, 51, 327, 178, 'mK', 2, 100, 0, 0),
  (18673, 51, 411, 261, 'mK', 9, 100, 0, 0),
  (18674, 51, 495, 345, 'mG', 10, 100, 0, 0),
  (18675, 51, 220, 281, 'mG', 6, 100, 0, 0),
  (18676, 51, 303, 364, 'mF', 6, 100, 0, 0),
  (18677, 51, 387, 448, 'mK', 3, 100, 0, 0),
  (18678, 51, 297, 553, 'mG', 1, 100, 0, 0),
  (18679, 51, 381, 637, 'mG', 4, 100, 0, 0),
  (18680, 51, 464, 720, 'mF', 6, 100, 0, 0),
  (18681, 51, 54, 452, 'mF', 9, 100, 0, 0),
  (18682, 51, 138, 535, 'mG', 6, 100, 0, 0),
  (18683, 51, 222, 619, 'mG', 10, 100, 0, 0),
  (18684, 51, -98, 359, 'mK', 9, 100, 0, 0),
  (18685, 51, -15, 443, 'mK', 4, 100, 0, 0),
  (18686, 51, 69, 526, 'mG', 5, 100, 0, 0),
  (18687, 51, -256, 200, 'mK', 1, 100, 0, 0),
  (18688, 51, -172, 284, 'mF', 1, 100, 0, 0),
  (18689, 51, -88, 368, 'mG', 2, 100, 0, 0),
  (18690, 51, -182, 173, 'mK', 2, 100, 0, 0),
  (18691, 51, -98, 256, 'mK', 2, 100, 0, 0),
  (18692, 51, -14, 340, 'mG', 4, 100, 0, 0),
  (18693, 51, -114, 46, 'mG', 3, 100, 0, 0),
  (18694, 51, -30, 130, 'mK', 6, 100, 0, 0),
  (18695, 51, 54, 214, 'mF', 7, 100, 0, 0),
  (18696, 51, -153, -211, 'mK', 4, 100, 0, 0),
  (18697, 51, -69, -128, 'mK', 3, 100, 0, 0),
  (18698, 51, 15, -44, 'mF', 9, 100, 0, 0),
  (18699, 51, -43, -289, 'mK', 0, 100, 0, 0),
  (18700, 51, 41, -205, 'mF', 0, 100, 0, 0),
  (18701, 51, 125, -121, 'mK', 10, 100, 0, 0),
  (18702, 51, 152, -236, 'mG', 0, 100, 0, 0),
  (18703, 51, 235, -153, 'mK', 3, 100, 0, 0),
  (18704, 51, 319, -69, 'mF', 8, 100, 0, 0),
  (18705, 51, 296, -188, 'mF', 6, 100, 0, 0),
  (18706, 51, 379, -105, 'mK', 8, 100, 0, 0),
  (18707, 51, 463, -21, 'mK', 4, 100, 0, 0),
  (18708, 51, 516, 54, 'mG', 5, 100, 0, 0),
  (18709, 51, 600, 138, 'mG', 9, 100, 0, 0),
  (18710, 51, 683, 222, 'mG', 7, 100, 0, 0),
  (18711, 51, 407, 84, 'mK', 4, 100, 0, 0),
  (18712, 51, 491, 167, 'mG', 5, 100, 0, 0),
  (18713, 51, 575, 251, 'mK', 1, 100, 0, 0);

-- 
-- ��������� ������� ������
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;